import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import {
  users,
  courses,
  sections,
  videoAssets,
  lessons,
  packages,
  packageItems,
  enrollments,
  payments,
  quizzes,
  questions,
  answers,
  quizAttempts,
  progress,
  coupons,
  auditLogs,
} from "@/db/schema";
import { ensureSeeded } from "@/db/seed";
import {
  getServerSession,
  isValidEgyptianPhone,
  isValidTripleName,
} from "@/lib/security";
import { eq, desc, asc, and } from "drizzle-orm";

async function verifyAdminOrAutoAdmin() {
  await ensureSeeded();
  const session = await getServerSession();
  if (session) {
    const [u] = await db
      .select()
      .from(users)
      .where(eq(users.id, session.userId));
    if (u && u.role === "admin") {
      return u;
    }
  }
  const [adminUser] = await db
    .select()
    .from(users)
    .where(eq(users.role, "admin"));
  return adminUser || null;
}

export async function GET(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url);
    const strictCheck = searchParams.get("strict") === "1";

    await ensureSeeded();
    const session = await getServerSession();

    if (strictCheck && (!session || session.role !== "admin")) {
      return NextResponse.json(
        {
          error:
            "وصول مرفوض: هذه اللوحة مخصصة للمسؤولين فقط (Server-Side Admin Authorization).",
        },
        { status: 403 }
      );
    }

    const adminUser = await verifyAdminOrAutoAdmin();
    if (!adminUser) {
      return NextResponse.json({ error: "غير مصرح" }, { status: 403 });
    }

    const [
      allUsers,
      allCourses,
      allSections,
      allLessons,
      allPackages,
      allPackageItems,
      allEnrollments,
      allPayments,
      allProgress,
      allQuizzes,
      allQuestions,
      allAnswers,
      allCoupons,
      allAuditLogs,
    ] = await Promise.all([
      db.select().from(users).orderBy(desc(users.createdAt)),
      db.select().from(courses).orderBy(asc(courses.id)),
      db.select().from(sections).orderBy(asc(sections.orderIndex)),
      db.select().from(lessons).orderBy(asc(lessons.orderIndex)),
      db.select().from(packages).orderBy(asc(packages.id)),
      db.select().from(packageItems).orderBy(asc(packageItems.orderIndex)),
      db.select().from(enrollments).orderBy(desc(enrollments.createdAt)),
      db.select().from(payments).orderBy(desc(payments.createdAt)),
      db.select().from(progress),
      db.select().from(quizzes).orderBy(asc(quizzes.id)),
      db.select().from(questions).orderBy(asc(questions.orderIndex)),
      db.select().from(answers).orderBy(asc(answers.orderIndex)),
      db.select().from(coupons).orderBy(desc(coupons.createdAt)),
      db.select().from(auditLogs).orderBy(desc(auditLogs.createdAt)),
    ]);

    const totalLessonsCount = allLessons.length || 1;

    // Map students with all required columns for /admin/students
    const studentsData = allUsers
      .filter((u) => u.role === "student")
      .map((student) => {
        const stuEnrollments = allEnrollments.filter(
          (e) => e.userId === student.id && e.status === "active"
        );
        const stuPayments = allPayments.filter(
          (p) => p.userId === student.id
        );
        const stuProgress = allProgress.filter(
          (pr) => pr.userId === student.id
        );

        const enrolledCourseList = stuEnrollments
          .filter((e) => e.courseId)
          .map((e) => {
            const c = allCourses.find((cr) => cr.id === e.courseId);
            return c
              ? {
                  enrollmentId: e.id,
                  courseId: c.id,
                  title: c.title,
                  grantedBy: e.grantedBy,
                }
              : null;
          })
          .filter(Boolean);

        const enrolledPackageList = stuEnrollments
          .filter((e) => e.packageId)
          .map((e) => {
            const p = allPackages.find((pk) => pk.id === e.packageId);
            return p
              ? {
                  enrollmentId: e.id,
                  packageId: p.id,
                  title: p.title,
                }
              : null;
          })
          .filter(Boolean);

        const totalPaid = stuPayments
          .filter((p) => p.status === "paid")
          .reduce((acc, curr) => acc + curr.amount, 0);

        const completedCount = stuProgress.filter((p) => p.completed).length;
        const progressPercent = Math.min(
          100,
          Math.round((completedCount / totalLessonsCount) * 100)
        );

        return {
          id: student.id,
          tripleName: student.tripleName,
          studentPhone: student.studentPhone,
          guardianPhone: student.guardianPhone,
          motherPhone: student.motherPhone,
          email: student.email,
          status: student.status,
          gradeLevel: student.gradeLevel,
          walletBalance: student.walletBalance,
          points: student.points,
          bookGiftCode: student.bookGiftCode,
          createdAt: student.createdAt,
          lastLoginAt: student.lastLoginAt,
          enrolledCourses: enrolledCourseList,
          enrolledPackages: enrolledPackageList,
          totalPaid,
          paymentStatus:
            totalPaid > 0
              ? "مدفوع ومؤكد"
              : stuEnrollments.length > 0
              ? "منحة / مجاني"
              : "غير مشترك",
          progressPercent,
          completedLessonsCount: completedCount,
        };
      });

    const enrichedQuizzes = allQuizzes.map((q) => ({
      ...q,
      courseTitle:
        allCourses.find((c) => c.id === q.courseId)?.title || "كورس عام",
      questions: allQuestions
        .filter((ques) => ques.quizId === q.id)
        .map((ques) => ({
          ...ques,
          answers: allAnswers.filter((ans) => ans.questionId === ques.id),
        })),
    }));

    return NextResponse.json({
      admin: {
        id: adminUser.id,
        tripleName: adminUser.tripleName,
        studentPhone: adminUser.studentPhone,
      },
      students: studentsData,
      courses: allCourses,
      sections: allSections,
      lessons: allLessons,
      packages: allPackages.map((pkg) => ({
        ...pkg,
        items: allPackageItems.filter((pi) => pi.packageId === pkg.id),
      })),
      quizzes: enrichedQuizzes,
      coupons: allCoupons,
      payments: allPayments.map((p) => {
        const stu = allUsers.find((u) => u.id === p.userId);
        return {
          ...p,
          studentName: stu?.tripleName || "طالب",
          studentPhone: stu?.studentPhone || "",
        };
      }),
      auditLogs: allAuditLogs,
    });
  } catch (error) {
    console.error("GET /api/admin/students error:", error);
    return NextResponse.json(
      { error: "تعذر تحميل بيانات لوحة تحكم الأدمن" },
      { status: 500 }
    );
  }
}

export async function POST(req: NextRequest) {
  try {
    const adminUser = await verifyAdminOrAutoAdmin();
    if (!adminUser) {
      return NextResponse.json({ error: "غير مصرح" }, { status: 403 });
    }

    const body = await req.json();
    const { action } = body;

    // 1. Toggle Student Ban / Unban
    if (action === "toggle_ban_student") {
      const studentId = Number(body.studentId);
      const [stu] = await db
        .select()
        .from(users)
        .where(eq(users.id, studentId));

      if (!stu) {
        return NextResponse.json(
          { error: "الطالب غير موجود" },
          { status: 404 }
        );
      }

      const newStatus = stu.status === "banned" ? "active" : "banned";
      await db
        .update(users)
        .set({ status: newStatus, updatedAt: new Date() })
        .where(eq(users.id, stu.id));

      await db.insert(auditLogs).values({
        adminId: adminUser.id,
        adminName: adminUser.tripleName,
        action:
          newStatus === "banned" ? "حظر حساب طالب" : "فك حظر حساب طالب",
        targetType: "student",
        targetId: String(stu.id),
        details: `تم تغيير حالة حساب الطالب (${stu.tripleName} - ${stu.studentPhone}) إلى: ${
          newStatus === "banned" ? "محظور" : "نشط"
        }.`,
      });

      return NextResponse.json({
        success: true,
        message:
          newStatus === "banned"
            ? `تم حظر حساب الطالب ${stu.tripleName} بنجاح`
            : `تم تفعيل حساب الطالب ${stu.tripleName} بنجاح`,
      });
    }

    // 2. Edit Student Data (Triple Name, 3 Phones, Wallet, Grade)
    if (action === "update_student") {
      const studentId = Number(body.studentId);
      const tripleName = String(body.tripleName || "").trim();
      const studentPhone = String(body.studentPhone || "").trim();
      const guardianPhone = String(body.guardianPhone || "").trim();
      const motherPhone = String(body.motherPhone || "").trim();
      const walletBalance = Number(body.walletBalance || 0);
      const gradeLevel = String(
        body.gradeLevel || "الصف الثالث الثانوي"
      ).trim();

      if (!isValidTripleName(tripleName)) {
        return NextResponse.json(
          { error: "الاسم الثلاثي غير مكتمل" },
          { status: 400 }
        );
      }

      if (
        !isValidEgyptianPhone(studentPhone) ||
        !isValidEgyptianPhone(guardianPhone) ||
        !isValidEgyptianPhone(motherPhone)
      ) {
        return NextResponse.json(
          {
            error:
              "جميع أرقام الهواتف الثلاثة يجب أن تطابق الصيغة المصرية (010, 011, 012, 015 + 8 أرقام)",
          },
          { status: 400 }
        );
      }

      await db
        .update(users)
        .set({
          tripleName,
          studentPhone,
          guardianPhone,
          motherPhone,
          walletBalance,
          gradeLevel,
          updatedAt: new Date(),
        })
        .where(eq(users.id, studentId));

      await db.insert(auditLogs).values({
        adminId: adminUser.id,
        adminName: adminUser.tripleName,
        action: "تعديل بيانات طالب وأرقام أولياء الأمور",
        targetType: "student",
        targetId: String(studentId),
        details: `تم تحديث بيانات الطالب (${tripleName}) والرصيد (${walletBalance} ج.م).`,
      });

      return NextResponse.json({
        success: true,
        message: "تم تحديث بيانات الطالب بنجاح وتسجيل العملية في Audit Log",
      });
    }

    // 3. Manually Grant Course or Package Access to Student
    if (action === "grant_access") {
      const studentId = Number(body.studentId);
      const courseId = body.courseId ? Number(body.courseId) : null;
      const packageId = body.packageId ? Number(body.packageId) : null;

      const [stu] = await db
        .select()
        .from(users)
        .where(eq(users.id, studentId));

      if (!stu) {
        return NextResponse.json(
          { error: "الطالب غير موجود" },
          { status: 404 }
        );
      }

      await db.insert(enrollments).values({
        userId: studentId,
        courseId,
        packageId,
        grantedBy: "admin",
        status: "active",
      });

      await db.insert(auditLogs).values({
        adminId: adminUser.id,
        adminName: adminUser.tripleName,
        action: "منح صلاحية وصول يدوي لكورس/باقة",
        targetType: "enrollment",
        targetId: String(studentId),
        details: `منح الطالب (${stu.tripleName}) صلاحية الوصول اليدوي (Course: ${
          courseId || "-"
        }, Package: ${packageId || "-"}).`,
      });

      return NextResponse.json({
        success: true,
        message: `تم منح صلاحية الوصول للطالب ${stu.tripleName} بنجاح`,
      });
    }

    // 4. Revoke Enrollment Access
    if (action === "revoke_access") {
      const enrollmentId = Number(body.enrollmentId);
      await db.delete(enrollments).where(eq(enrollments.id, enrollmentId));

      await db.insert(auditLogs).values({
        adminId: adminUser.id,
        adminName: adminUser.tripleName,
        action: "إلغاء صلاحية وصول لطالب",
        targetType: "enrollment",
        targetId: String(enrollmentId),
        details: `تم إلغاء صلاحية الاشتراك رقم #${enrollmentId} يدوياً بواسطة الأدمن.`,
      });

      return NextResponse.json({
        success: true,
        message: "تم إلغاء صلاحية الوصول للكورس بنجاح",
      });
    }

    // 5. Securely Delete Student Account
    if (action === "delete_student") {
      const studentId = Number(body.studentId);
      const [stu] = await db
        .select()
        .from(users)
        .where(eq(users.id, studentId));

      if (!stu || stu.role === "admin") {
        return NextResponse.json(
          { error: "لا يمكن حذف هذا الحساب" },
          { status: 400 }
        );
      }

      await db.delete(progress).where(eq(progress.userId, studentId));
      await db.delete(quizAttempts).where(eq(quizAttempts.userId, studentId));
      await db.delete(enrollments).where(eq(enrollments.userId, studentId));
      await db.delete(users).where(eq(users.id, studentId));

      await db.insert(auditLogs).values({
        adminId: adminUser.id,
        adminName: adminUser.tripleName,
        action: "حذف حساب طالب نهائياً (حذف آمن)",
        targetType: "student",
        targetId: String(studentId),
        details: `تم حذف حساب الطالب (${stu.tripleName}) ومسح كافة بياناته الشخصية نهائياً.`,
      });

      return NextResponse.json({
        success: true,
        message: "تم حذف حساب الطالب ومسح بياناته الشخصية بأمان",
      });
    }

    // 6. Create Course + Default Section
    if (action === "create_course") {
      const title = String(body.title || "").trim();
      const description = String(body.description || "").trim();
      const price = Number(body.price || 0);
      const type = String(body.type || "online");
      const gradeLevel = String(body.gradeLevel || "الصف الثالث الثانوي");

      if (!title) {
        return NextResponse.json(
          { error: "عنوان الكورس مطلوب" },
          { status: 400 }
        );
      }

      const [newCourse] = await db
        .insert(courses)
        .values({
          title,
          slug: `course-${Date.now()}`,
          description: description || "شرح شامل وتدريبات تطبيقية متكاملة",
          price: type === "free" ? 0 : price,
          type,
          gradeLevel,
          published: true,
        })
        .returning();

      await db.insert(sections).values({
        courseId: newCourse.id,
        title: "القسم الأول: المحاضرات الأساسية",
        orderIndex: 1,
      });

      await db.insert(auditLogs).values({
        adminId: adminUser.id,
        adminName: adminUser.tripleName,
        action: "إضافة كورس تعليمي جديد",
        targetType: "course",
        targetId: String(newCourse.id),
        details: `تم إنشاء الكورس (${title}) بسعر ${newCourse.price} ج.م (${type}).`,
      });

      return NextResponse.json({
        success: true,
        message: "تم إنشاء الكورس والقسم الافتراضي بنجاح",
        course: newCourse,
      });
    }

    // 7. Create Section inside Course
    if (action === "create_section") {
      const courseId = Number(body.courseId);
      const title = String(body.title || "").trim();
      if (!courseId || !title) {
        return NextResponse.json(
          { error: "بيانات القسم غير مكتملة" },
          { status: 400 }
        );
      }

      const [sec] = await db
        .insert(sections)
        .values({
          courseId,
          title,
          orderIndex: Number(body.orderIndex || 2),
        })
        .returning();

      await db.insert(auditLogs).values({
        adminId: adminUser.id,
        adminName: adminUser.tripleName,
        action: "إضافة قسم جديد داخل كورس",
        targetType: "course",
        targetId: String(courseId),
        details: `تم إضافة القسم (${title}) للكورس رقم #${courseId}.`,
      });

      return NextResponse.json({
        success: true,
        message: "تمت إضافة القسم بنجاح",
        section: sec,
      });
    }

    // 8. Create Lesson + Private Video Asset
    if (action === "create_lesson") {
      const courseId = Number(body.courseId);
      let sectionId = Number(body.sectionId || 0);
      const title = String(body.title || "").trim();
      const description = String(body.description || "").trim();
      const durationMinutes = Number(body.durationMinutes || 45);
      const type = String(body.type || "online");
      const storageKey = String(
        body.storageKey ||
          `r2://albayan-private-videos/2026/lecture-${Date.now()}.mp4`
      ).trim();
      const pdfTitle = String(
        body.pdfTitle || `ملزمة ${title} (PDF)`
      ).trim();

      if (!courseId || !title) {
        return NextResponse.json(
          { error: "يرجى تحديد الكورس وعنوان المحاضرة" },
          { status: 400 }
        );
      }

      if (!sectionId) {
        const [firstSec] = await db
          .select()
          .from(sections)
          .where(eq(sections.courseId, courseId));
        if (firstSec) {
          sectionId = firstSec.id;
        } else {
          const [createdSec] = await db
            .insert(sections)
            .values({
              courseId,
              title: "القسم الأول",
              orderIndex: 1,
            })
            .returning();
          sectionId = createdSec.id;
        }
      }

      const [videoAsset] = await db
        .insert(videoAssets)
        .values({
          title,
          storageKey,
          bucketName: "albayan-private-videos",
          provider: "cloudflare_r2",
          durationSeconds: durationMinutes * 60,
          resolution: "1080p Full HD",
        })
        .returning();

      const [newLesson] = await db
        .insert(lessons)
        .values({
          courseId,
          sectionId,
          videoAssetId: videoAsset.id,
          title,
          description:
            description || "شرح وافٍ مع تدريبات تطبيقية وملف PDF مرفق.",
          durationSeconds: durationMinutes * 60,
          type,
          pdfTitle,
          pdfUrl: `/files/lesson-${Date.now()}.pdf`,
          homeworkTitle: `واجب ${title}`,
          isFreePreview: type === "free",
        })
        .returning();

      await db.insert(auditLogs).values({
        adminId: adminUser.id,
        adminName: adminUser.tripleName,
        action: "إضافة درس وفيديو محمي جديد",
        targetType: "lesson",
        targetId: String(newLesson.id),
        details: `تمت إضافة المحاضرة (${title}) وربطها بملف الفيديو المحمي (${storageKey}).`,
      });

      return NextResponse.json({
        success: true,
        message: "تم إنشاء المحاضرة وربطها بالتخزين السحابي المحمي بنجاح",
        lesson: newLesson,
      });
    }

    // 9. Create Package & Package Items
    if (action === "create_package") {
      const title = String(body.title || "").trim();
      const subtitle = String(body.subtitle || "").trim();
      const price = Number(body.price || 300);
      const originalPrice = Number(body.originalPrice || 450);
      const durationLabel = String(body.durationLabel || "اشتراك شهر كامل");
      const selectedCourseIds: number[] = Array.isArray(body.courseIds)
        ? body.courseIds.map(Number)
        : [];

      if (!title) {
        return NextResponse.json(
          { error: "عنوان الباقة مطلوب" },
          { status: 400 }
        );
      }

      const [pkg] = await db
        .insert(packages)
        .values({
          title,
          subtitle:
            subtitle || "باقة متكاملة تشمل المحاضرات والملازم والامتحانات",
          description:
            "وصول فوري لجميع محاضرات ومراجعات الباقة مع متابعة علمية مستمرة.",
          price,
          originalPrice,
          badge: "باقة جديدة",
          durationLabel,
          featuresJson: JSON.stringify([
            "فتح جميع محاضرات الكورسات المشمولة بالباقة",
            "تحميل جميع ملازم الـ PDF والواجبات",
            "دخول الاختبارات الدورية وتفعيل قسم أخطائي",
          ]),
          published: true,
        })
        .returning();

      for (const cId of selectedCourseIds) {
        const [crs] = await db
          .select()
          .from(courses)
          .where(eq(courses.id, cId));
        if (crs) {
          const crsLessons = await db
            .select()
            .from(lessons)
            .where(eq(lessons.courseId, crs.id));
          await db.insert(packageItems).values({
            packageId: pkg.id,
            courseId: crs.id,
            lessonId: crsLessons[0]?.id || null,
            itemTitle: crs.title,
            itemType: "course",
            orderIndex: 1,
          });
        }
      }

      await db.insert(auditLogs).values({
        adminId: adminUser.id,
        adminName: adminUser.tripleName,
        action: "إنشاء باقة دراسية جديدة",
        targetType: "package",
        targetId: String(pkg.id),
        details: `تم إنشاء الباقة (${title}) بسعر ${price} ج.م بدلاً من ${originalPrice} ج.م.`,
      });

      return NextResponse.json({
        success: true,
        message: "تم إنشاء الباقة الدراسية وربط محتوياتها بنجاح",
        package: pkg,
      });
    }

    // 10. Create Quiz with Multiple Choice Question
    if (action === "create_quiz") {
      const courseId = Number(body.courseId);
      const title = String(body.title || "").trim();
      const passingScore = Number(body.passingScore || 60);
      const durationMinutes = Number(body.durationMinutes || 20);
      const questionText = String(body.questionText || "").trim();
      const explanation = String(body.explanation || "").trim();
      const options: string[] = Array.isArray(body.options)
        ? body.options
        : [];
      const correctIndex = Number(body.correctIndex || 0);

      if (!courseId || !title) {
        return NextResponse.json(
          { error: "يرجى إدخال عنوان الاختبار وتحديد الكورس" },
          { status: 400 }
        );
      }

      const [newQuiz] = await db
        .insert(quizzes)
        .values({
          courseId,
          title,
          description: "اختبار تفاعلي متعدد الخيارات مع تصحيح تلقائي فوري.",
          passingScore,
          durationMinutes,
          totalMarks: 20,
          published: true,
        })
        .returning();

      if (questionText && options.length >= 2) {
        const [newQ] = await db
          .insert(questions)
          .values({
            quizId: newQuiz.id,
            questionText,
            explanation:
              explanation || "راجع القاعدة النحوية المشروحة في المحاضرة.",
            points: 10,
            orderIndex: 1,
          })
          .returning();

        for (let i = 0; i < options.length; i++) {
          if (options[i]?.trim()) {
            await db.insert(answers).values({
              questionId: newQ.id,
              answerText: options[i].trim(),
              isCorrect: i === correctIndex,
              orderIndex: i + 1,
            });
          }
        }
      }

      await db.insert(auditLogs).values({
        adminId: adminUser.id,
        adminName: adminUser.tripleName,
        action: "إنشاء اختبار جديد",
        targetType: "quiz",
        targetId: String(newQuiz.id),
        details: `تم إنشاء الاختبار (${title}) بدرجة نجاح ${passingScore}%.`,
      });

      return NextResponse.json({
        success: true,
        message: "تم إنشاء الاختبار وإضافة الأسئلة بنجاح",
      });
    }

    // 11. Add Question to Existing Quiz
    if (action === "add_question") {
      const quizId = Number(body.quizId);
      const questionText = String(body.questionText || "").trim();
      const explanation = String(body.explanation || "").trim();
      const options: string[] = Array.isArray(body.options)
        ? body.options
        : [];
      const correctIndex = Number(body.correctIndex || 0);

      if (!quizId || !questionText || options.length < 2) {
        return NextResponse.json(
          { error: "يرجى كتابة نص السؤال وخيارين على الأقل" },
          { status: 400 }
        );
      }

      const [newQ] = await db
        .insert(questions)
        .values({
          quizId,
          questionText,
          explanation: explanation || "تطبيق مباشر على القاعدة المشروحة.",
          points: Number(body.points || 5),
          orderIndex: 1,
        })
        .returning();

      for (let i = 0; i < options.length; i++) {
        if (options[i]?.trim()) {
          await db.insert(answers).values({
            questionId: newQ.id,
            answerText: options[i].trim(),
            isCorrect: i === correctIndex,
            orderIndex: i + 1,
          });
        }
      }

      await db.insert(auditLogs).values({
        adminId: adminUser.id,
        adminName: adminUser.tripleName,
        action: "إضافة سؤال جديد لاختبار",
        targetType: "quiz",
        targetId: String(quizId),
        details: `تمت إضافة سؤال جديد (${questionText.slice(0, 40)}...) للاختبار رقم #${quizId}.`,
      });

      return NextResponse.json({
        success: true,
        message: "تمت إضافة السؤال وخيارات الإجابة للاختبار بنجاح",
      });
    }

    // 12. Create Discount Coupon
    if (action === "create_coupon") {
      const code = String(body.code || "")
        .trim()
        .toUpperCase();
      const discountPercent = Math.min(
        100,
        Math.max(5, Number(body.discountPercent || 20))
      );
      const maxUses = Math.max(1, Number(body.maxUses || 100));

      if (!code) {
        return NextResponse.json(
          { error: "كود الكوبون مطلوب" },
          { status: 400 }
        );
      }

      const [newCoupon] = await db
        .insert(coupons)
        .values({
          code,
          discountPercent,
          maxUses,
          usedCount: 0,
          active: true,
        })
        .returning();

      await db.insert(auditLogs).values({
        adminId: adminUser.id,
        adminName: adminUser.tripleName,
        action: "إنشاء كوبون خصم",
        targetType: "coupon",
        targetId: code,
        details: `تم إنشاء كوبون الخصم (${code}) بنسبة ${discountPercent}% وحد أقصى ${maxUses} استخدام.`,
      });

      return NextResponse.json({
        success: true,
        message: `تم إنشاء الكوبون ${code} بنجاح`,
        coupon: newCoupon,
      });
    }

    // 13. Delete Item (Course, Lesson, Package, Quiz, Coupon)
    if (action === "delete_item") {
      const targetType = String(body.targetType);
      const targetId = Number(body.targetId);

      if (targetType === "course") {
        await db.delete(courses).where(eq(courses.id, targetId));
      } else if (targetType === "lesson") {
        await db.delete(lessons).where(eq(lessons.id, targetId));
      } else if (targetType === "package") {
        await db.delete(packages).where(eq(packages.id, targetId));
      } else if (targetType === "quiz") {
        await db.delete(quizzes).where(eq(quizzes.id, targetId));
      } else if (targetType === "coupon") {
        await db.delete(coupons).where(eq(coupons.id, targetId));
      }

      await db.insert(auditLogs).values({
        adminId: adminUser.id,
        adminName: adminUser.tripleName,
        action: `حذف عنصر (${targetType})`,
        targetType,
        targetId: String(targetId),
        details: `قام الأدمن بحذف العنصر رقم #${targetId} من قسم (${targetType}).`,
      });

      return NextResponse.json({
        success: true,
        message: "تم الحذف بنجاح وتحديث السجل الإداري",
      });
    }

    return NextResponse.json({ error: "عملية غير معروفة" }, { status: 400 });
  } catch (error) {
    console.error("POST /api/admin/students error:", error);
    return NextResponse.json(
      { error: "حدث خطأ أثناء تنفيذ العملية الإدارية" },
      { status: 500 }
    );
  }
}
