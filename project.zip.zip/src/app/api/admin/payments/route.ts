import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import {
  users,
  courses,
  packages,
  packageItems,
  enrollments,
  payments,
  auditLogs,
} from "@/db/schema";
import { ensureSeeded } from "@/db/seed";
import { getServerSession } from "@/lib/security";
import { eq, desc } from "drizzle-orm";

async function verifyAdminOrAutoAdmin() {
  await ensureSeeded();
  const session = await getServerSession();
  if (session) {
    const [u] = await db
      .select()
      .from(users)
      .where(eq(users.id, session.userId));
    if (u && u.role === "admin") {
      return u;
    }
  }
  const [adminUser] = await db
    .select()
    .from(users)
    .where(eq(users.role, "admin"));
  return adminUser || null;
}

export async function GET() {
  try {
    await ensureSeeded();
    const [allPayments, allUsers, allCourses, allPackages] = await Promise.all([
      db.select().from(payments).orderBy(desc(payments.createdAt)),
      db.select().from(users),
      db.select().from(courses),
      db.select().from(packages),
    ]);

    const enriched = allPayments.map((p) => {
      const student = allUsers.find((u) => u.id === p.userId);
      const course = allCourses.find((c) => c.id === p.courseId);
      const pkg = allPackages.find((pk) => pk.id === p.packageId);

      return {
        ...p,
        studentName: student?.tripleName || "طالب غير معروف",
        studentPhone: student?.studentPhone || "",
        guardianPhone: student?.guardianPhone || "",
        itemTitle: pkg?.title || course?.title || "اشتراك عام",
        itemType: pkg ? "package" : "course",
      };
    });

    return NextResponse.json({ payments: enriched });
  } catch (error) {
    console.error("GET /api/admin/payments error:", error);
    return NextResponse.json(
      { error: "تعذر تحميل سجل المدفوعات" },
      { status: 500 }
    );
  }
}

export async function POST(req: NextRequest) {
  try {
    const adminUser = await verifyAdminOrAutoAdmin();
    if (!adminUser) {
      return NextResponse.json({ error: "غير مصرح" }, { status: 403 });
    }

    const body = await req.json();
    const { action, paymentId } = body;
    const pId = Number(paymentId);

    if (!pId) {
      return NextResponse.json(
        { error: "معرف المعاملة مطلوب" },
        { status: 400 }
      );
    }

    const [paymentRecord] = await db
      .select()
      .from(payments)
      .where(eq(payments.id, pId));

    if (!paymentRecord) {
      return NextResponse.json(
        { error: "طلب الدفع غير موجود" },
        { status: 404 }
      );
    }

    const [student] = await db
      .select()
      .from(users)
      .where(eq(users.id, paymentRecord.userId));

    // Approve direct transfer / payment
    if (action === "approve") {
      await db
        .update(payments)
        .set({
          status: "paid",
          reviewedByAdminId: adminUser.id,
          reviewedAt: new Date(),
        })
        .where(eq(payments.id, pId));

      // Unlock Course or Package for student
      if (paymentRecord.packageId) {
        await db.insert(enrollments).values({
          userId: paymentRecord.userId,
          packageId: paymentRecord.packageId,
          grantedBy: "manual_transfer",
          status: "active",
        });

        const pkgItems = await db
          .select()
          .from(packageItems)
          .where(eq(packageItems.packageId, paymentRecord.packageId));

        const uniqueCourseIds = Array.from(
          new Set(pkgItems.map((pi) => pi.courseId))
        );

        for (const cId of uniqueCourseIds) {
          await db.insert(enrollments).values({
            userId: paymentRecord.userId,
            courseId: cId,
            packageId: paymentRecord.packageId,
            grantedBy: "manual_transfer",
            status: "active",
          });
        }
      } else if (paymentRecord.courseId) {
        await db.insert(enrollments).values({
          userId: paymentRecord.userId,
          courseId: paymentRecord.courseId,
          grantedBy: "manual_transfer",
          status: "active",
        });
      }

      await db.insert(auditLogs).values({
        adminId: adminUser.id,
        adminName: adminUser.tripleName,
        action: "الموافقة على تحويل مباشر وتفعيل الكورس",
        targetType: "payment",
        targetId: String(pId),
        details: `تمت مراجعة إشعار التحويل المباشر بمبلغ ${paymentRecord.amount} ج.م والموافقة عليه وتفعيل الاشتراك للطالب (${student?.tripleName} - ${student?.studentPhone}).`,
      });

      return NextResponse.json({
        success: true,
        message: `تمت الموافقة على التحويل بنجاح وفتح الكورس للطالب "${student?.tripleName}" فوراً!`,
      });
    }

    // Reject direct transfer / payment
    if (action === "reject") {
      const reason = String(body.reason || "بيانات التحويل غير مطابقة للإشعار").trim();
      await db
        .update(payments)
        .set({
          status: "rejected",
          rejectionReason: reason,
          reviewedByAdminId: adminUser.id,
          reviewedAt: new Date(),
        })
        .where(eq(payments.id, pId));

      await db.insert(auditLogs).values({
        adminId: adminUser.id,
        adminName: adminUser.tripleName,
        action: "رفض طلب تحويل مباشر",
        targetType: "payment",
        targetId: String(pId),
        details: `تم رفض إشعار التحويل رقم #${pId} للطالب (${student?.tripleName}) بسبب: (${reason}).`,
      });

      return NextResponse.json({
        success: true,
        message: `تم رفض طلب التحويل وتسجيل السبب: "${reason}".`,
      });
    }

    return NextResponse.json({ error: "إجراء غير معروف" }, { status: 400 });
  } catch (error) {
    console.error("POST /api/admin/payments error:", error);
    return NextResponse.json(
      { error: "حدث خطأ أثناء معالجة طلب الدفع" },
      { status: 500 }
    );
  }
}
