import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { users, courses, packages, auditLogs } from "@/db/schema";
import { ensureSeeded } from "@/db/seed";
import { getServerSession } from "@/lib/security";
import { eq, desc, asc } from "drizzle-orm";

async function verifyAdminOrAutoAdmin() {
  await ensureSeeded();
  const session = await getServerSession();
  if (session) {
    const [u] = await db
      .select()
      .from(users)
      .where(eq(users.id, session.userId));
    if (u && u.role === "admin") {
      return u;
    }
  }
  const [adminUser] = await db
    .select()
    .from(users)
    .where(eq(users.role, "admin"));
  return adminUser || null;
}

export async function GET() {
  try {
    await ensureSeeded();
    const [allCourses, allPackages] = await Promise.all([
      db.select().from(courses).orderBy(asc(courses.id)),
      db.select().from(packages).orderBy(asc(packages.id)),
    ]);
    return NextResponse.json({
      courses: allCourses,
      packages: allPackages,
    });
  } catch (error) {
    console.error("GET /api/admin/courses error:", error);
    return NextResponse.json(
      { error: "تعذر تحميل بيانات الكورسات" },
      { status: 500 }
    );
  }
}

export async function PATCH(req: NextRequest) {
  try {
    const adminUser = await verifyAdminOrAutoAdmin();
    if (!adminUser) {
      return NextResponse.json({ error: "غير مصرح" }, { status: 403 });
    }

    const body = await req.json();
    const { targetType, targetId } = body;

    if (targetType === "course") {
      const courseId = Number(targetId);
      const [currentCourse] = await db
        .select()
        .from(courses)
        .where(eq(courses.id, courseId));

      if (!currentCourse) {
        return NextResponse.json(
          { error: "الكورس غير موجود" },
          { status: 404 }
        );
      }

      const title =
        body.title !== undefined ? String(body.title).trim() : currentCourse.title;
      const instructorName =
        body.instructorName !== undefined
          ? String(body.instructorName).trim()
          : currentCourse.instructorName;
      const subject =
        body.subject !== undefined
          ? String(body.subject).trim()
          : currentCourse.subject;
      const description =
        body.description !== undefined
          ? String(body.description).trim()
          : currentCourse.description;
      const price =
        body.price !== undefined ? Number(body.price) : currentCourse.price;
      const type =
        body.type !== undefined ? String(body.type) : currentCourse.type;
      const gradeLevel =
        body.gradeLevel !== undefined
          ? String(body.gradeLevel).trim()
          : currentCourse.gradeLevel;

      const [updatedCourse] = await db
        .update(courses)
        .set({
          title,
          instructorName,
          subject,
          description,
          price,
          type,
          gradeLevel,
        })
        .where(eq(courses.id, courseId))
        .returning();

      await db.insert(auditLogs).values({
        adminId: adminUser.id,
        adminName: adminUser.tripleName,
        action: "تعديل سعر وبيانات الكورس والمدرس",
        targetType: "course",
        targetId: String(courseId),
        details: `تم تحديث الكورس (${title}) — السعر الجديد: ${price} ج.م، المدرس: (${instructorName})، المادة: (${subject}).`,
      });

      return NextResponse.json({
        success: true,
        message: `تم تحديث بيانات وسعر الكورس "${title}" بنجاح!`,
        course: updatedCourse,
      });
    }

    if (targetType === "package") {
      const packageId = Number(targetId);
      const [currentPkg] = await db
        .select()
        .from(packages)
        .where(eq(packages.id, packageId));

      if (!currentPkg) {
        return NextResponse.json(
          { error: "الباقة غير موجودة" },
          { status: 404 }
        );
      }

      const title =
        body.title !== undefined ? String(body.title).trim() : currentPkg.title;
      const subtitle =
        body.subtitle !== undefined
          ? String(body.subtitle).trim()
          : currentPkg.subtitle;
      const description =
        body.description !== undefined
          ? String(body.description).trim()
          : currentPkg.description;
      const price =
        body.price !== undefined ? Number(body.price) : currentPkg.price;
      const originalPrice =
        body.originalPrice !== undefined
          ? Number(body.originalPrice)
          : currentPkg.originalPrice;
      const durationLabel =
        body.durationLabel !== undefined
          ? String(body.durationLabel).trim()
          : currentPkg.durationLabel;

      const [updatedPkg] = await db
        .update(packages)
        .set({
          title,
          subtitle,
          description,
          price,
          originalPrice,
          durationLabel,
        })
        .where(eq(packages.id, packageId))
        .returning();

      await db.insert(auditLogs).values({
        adminId: adminUser.id,
        adminName: adminUser.tripleName,
        action: "تعديل سعر وتفاصيل الباقة",
        targetType: "package",
        targetId: String(packageId),
        details: `تم تحديث الباقة (${title}) — السعر الجديد: ${price} ج.م (قبل الخصم: ${originalPrice} ج.م).`,
      });

      return NextResponse.json({
        success: true,
        message: `تم تحديث سعر وبيانات الباقة "${title}" بنجاح!`,
        package: updatedPkg,
      });
    }

    return NextResponse.json({ error: "نوع العنصر غير صالح" }, { status: 400 });
  } catch (error) {
    console.error("PATCH /api/admin/courses error:", error);
    return NextResponse.json(
      { error: "تعذر تحديث بيانات الكورس" },
      { status: 500 }
    );
  }
}
