import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { users, platformSettings, auditLogs } from "@/db/schema";
import { ensureSeeded } from "@/db/seed";
import { getServerSession } from "@/lib/security";
import { eq } from "drizzle-orm";

async function verifyAdminOrAutoAdmin() {
  await ensureSeeded();
  const session = await getServerSession();
  if (session) {
    const [u] = await db
      .select()
      .from(users)
      .where(eq(users.id, session.userId));
    if (u && u.role === "admin") {
      return u;
    }
  }
  const [adminUser] = await db
    .select()
    .from(users)
    .where(eq(users.role, "admin"));
  return adminUser || null;
}

export async function GET() {
  try {
    await ensureSeeded();
    const [settings] = await db.select().from(platformSettings);
    return NextResponse.json({
      settings: settings || {
        vodafoneCashNumber: "01023316767",
        instapayAddress: "albayan@instapay",
        instapayName: "أ.د. محمود الشافعي (البيان التعليمية)",
        supportPhone: "01023316767",
        transferInstructions:
          "يرجى التحويل على رقم فودافون كاش أو معرف InstaPay الموضحين، ثم كتابة رقم المحفظة المحول منها ورفع صورة الإشعار للموافقة وتفعيل الكورس فوراً.",
      },
    });
  } catch (error) {
    console.error("GET /api/admin/settings error:", error);
    return NextResponse.json(
      { error: "تعذر تحميل إعدادات المنصة" },
      { status: 500 }
    );
  }
}

export async function POST(req: NextRequest) {
  try {
    const adminUser = await verifyAdminOrAutoAdmin();
    if (!adminUser) {
      return NextResponse.json({ error: "غير مصرح" }, { status: 403 });
    }

    const body = await req.json();
    const vodafoneCashNumber = String(body.vodafoneCashNumber || "01023316767").trim();
    const instapayAddress = String(body.instapayAddress || "albayan@instapay").trim();
    const instapayName = String(body.instapayName || "أ.د. محمود الشافعي").trim();
    const supportPhone = String(body.supportPhone || "01023316767").trim();
    const transferInstructions = String(body.transferInstructions || "").trim();

    const [existing] = await db.select().from(platformSettings);
    let updated;

    if (existing) {
      const [up] = await db
        .update(platformSettings)
        .set({
          vodafoneCashNumber,
          instapayAddress,
          instapayName,
          supportPhone,
          transferInstructions,
          updatedAt: new Date(),
        })
        .where(eq(platformSettings.id, existing.id))
        .returning();
      updated = up;
    } else {
      const [ins] = await db
        .insert(platformSettings)
        .values({
          vodafoneCashNumber,
          instapayAddress,
          instapayName,
          supportPhone,
          transferInstructions,
        })
        .returning();
      updated = ins;
    }

    await db.insert(auditLogs).values({
      adminId: adminUser.id,
      adminName: adminUser.tripleName,
      action: "تحديث إعدادات الدفع المباشر والـ InstaPay",
      targetType: "settings",
      targetId: String(updated.id),
      details: `تم تحديث رقم فودافون كاش إلى (${vodafoneCashNumber}) ومعرف InstaPay إلى (${instapayAddress}).`,
    });

    return NextResponse.json({
      success: true,
      message: "تم تحديث إعدادات الدفع المباشر بنجاح وتوثيق العملية في سجل التدقيق",
      settings: updated,
    });
  } catch (error) {
    console.error("POST /api/admin/settings error:", error);
    return NextResponse.json(
      { error: "تعذر حفظ إعدادات المنصة" },
      { status: 500 }
    );
  }
}
