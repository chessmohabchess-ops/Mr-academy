import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import {
  users,
  enrollments,
  progress,
  quizAttempts,
  payments,
  couponRedemptions,
  auditLogs,
} from "@/db/schema";
import {
  getServerSession,
  isValidEgyptianPhone,
  isValidTripleName,
  hashPassword,
  sanitizeUserForStudent,
} from "@/lib/security";
import { eq } from "drizzle-orm";

export async function PATCH(req: NextRequest) {
  try {
    const session = await getServerSession();
    if (!session) {
      return NextResponse.json({ error: "غير مصرح" }, { status: 401 });
    }

    const body = await req.json();
    const [current] = await db
      .select()
      .from(users)
      .where(eq(users.id, session.userId));

    if (!current) {
      return NextResponse.json({ error: "المستخدم غير موجود" }, { status: 404 });
    }

    const tripleName = body.tripleName
      ? String(body.tripleName).trim()
      : current.tripleName;
    const guardianPhone = body.guardianPhone
      ? String(body.guardianPhone).trim()
      : current.guardianPhone;
    const motherPhone = body.motherPhone
      ? String(body.motherPhone).trim()
      : current.motherPhone;
    const email =
      body.email !== undefined ? String(body.email).trim() : current.email;
    const gradeLevel = body.gradeLevel
      ? String(body.gradeLevel).trim()
      : current.gradeLevel;

    if (!isValidTripleName(tripleName)) {
      return NextResponse.json(
        { error: "يجب إدخال الاسم الثلاثي كاملاً" },
        { status: 400 }
      );
    }

    if (!isValidEgyptianPhone(guardianPhone) || !isValidEgyptianPhone(motherPhone)) {
      return NextResponse.json(
        {
          error:
            "يجب أن تكون أرقام ولي الأمر والأم بصيغة مصرية صحيحة (010, 011, 012, 015 + 8 أرقام).",
        },
        { status: 400 }
      );
    }

    let newPasswordHash = current.passwordHash;
    if (body.newPassword && String(body.newPassword).trim().length >= 6) {
      newPasswordHash = await hashPassword(String(body.newPassword).trim());
    }

    const [updated] = await db
      .update(users)
      .set({
        tripleName,
        guardianPhone,
        motherPhone,
        email,
        gradeLevel,
        passwordHash: newPasswordHash,
        updatedAt: new Date(),
      })
      .where(eq(users.id, current.id))
      .returning();

    return NextResponse.json({
      success: true,
      message: "تم تحديث بيانات الملف الشخصي بنجاح",
      user: sanitizeUserForStudent(updated, true),
    });
  } catch (error) {
    console.error("PATCH /api/profile error:", error);
    return NextResponse.json(
      { error: "تعذر تحديث الملف الشخصي" },
      { status: 500 }
    );
  }
}

export async function DELETE() {
  try {
    const session = await getServerSession();
    if (!session) {
      return NextResponse.json({ error: "غير مصرح" }, { status: 401 });
    }

    const [current] = await db
      .select()
      .from(users)
      .where(eq(users.id, session.userId));

    if (!current) {
      return NextResponse.json({ error: "الحساب غير موجود" }, { status: 404 });
    }

    if (current.role === "admin") {
      return NextResponse.json(
        { error: "لا يمكن حذف الحساب الإداري الرئيسي للمنصة" },
        { status: 400 }
      );
    }

    // Secure Data Deletion Policy: Purge all personal & behavioral records
    await db.delete(progress).where(eq(progress.userId, current.id));
    await db.delete(quizAttempts).where(eq(quizAttempts.userId, current.id));
    await db.delete(enrollments).where(eq(enrollments.userId, current.id));
    await db
      .delete(couponRedemptions)
      .where(eq(couponRedemptions.userId, current.id));
    await db.delete(payments).where(eq(payments.userId, current.id));
    await db.delete(users).where(eq(users.id, current.id));

    await db.insert(auditLogs).values({
      adminId: null,
      adminName: "نظام الحذف الآمن (الخصوصية)",
      action: "حذف حساب طالب نهائياً ومسح البيانات الشخصية",
      targetType: "student",
      targetId: String(current.id),
      details:
        "تم تنفيذ سياسة الحذف الآمن للبيانات الشخصية ومسح كافة سجلات الهاتف والتقدم بناءً على طلب صاحب الحساب.",
      ipAddress: "127.0.0.1",
    });

    const response = NextResponse.json({
      success: true,
      message:
        "تم حذف حسابك ومسح كافة بياناتك الشخصية وأرقام الهواتف نهائياً بأمان.",
    });

    response.cookies.delete("albayan_session");
    return response;
  } catch (error) {
    console.error("DELETE /api/profile error:", error);
    return NextResponse.json(
      { error: "تعذر حذف الحساب" },
      { status: 500 }
    );
  }
}
