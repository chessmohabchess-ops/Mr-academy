import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { users, lessons, progress } from "@/db/schema";
import { getServerSession } from "@/lib/security";
import { eq, and } from "drizzle-orm";

export async function POST(req: NextRequest) {
  try {
    const session = await getServerSession();
    const body = await req.json();
    const lessonId = Number(body.lessonId);
    const watchedSeconds = Math.max(0, Math.floor(Number(body.watchedSeconds || 0)));
    const forceCompleted = Boolean(body.completed);

    if (!lessonId) {
      return NextResponse.json(
        { error: "معرف الدرس مطلوب" },
        { status: 400 }
      );
    }

    let userId = session?.userId;
    if (!userId) {
      const [defaultStudent] = await db
        .select()
        .from(users)
        .where(eq(users.studentPhone, "01012345678"));
      userId = defaultStudent?.id;
    }

    if (!userId) {
      return NextResponse.json({ error: "غير مصرح" }, { status: 401 });
    }

    const [lesson] = await db
      .select()
      .from(lessons)
      .where(eq(lessons.id, lessonId));

    if (!lesson) {
      return NextResponse.json({ error: "الدرس غير موجود" }, { status: 404 });
    }

    const clampedWatched = Math.min(watchedSeconds, lesson.durationSeconds);
    const isCompleted =
      forceCompleted || clampedWatched >= Math.floor(lesson.durationSeconds * 0.92);

    const [existing] = await db
      .select()
      .from(progress)
      .where(
        and(eq(progress.userId, userId), eq(progress.lessonId, lesson.id))
      );

    let updatedRecord;
    let bonusAwarded = false;

    if (existing) {
      const newlyCompleted = isCompleted && !existing.completed;
      const [updated] = await db
        .update(progress)
        .set({
          watchedSeconds: isCompleted ? lesson.durationSeconds : clampedWatched,
          completed: isCompleted || existing.completed,
          lastWatchedAt: new Date(),
          updatedAt: new Date(),
        })
        .where(eq(progress.id, existing.id))
        .returning();
      updatedRecord = updated;

      if (newlyCompleted) {
        const [u] = await db.select().from(users).where(eq(users.id, userId));
        if (u) {
          await db
            .update(users)
            .set({ points: u.points + 50 })
            .where(eq(users.id, userId));
          bonusAwarded = true;
        }
      }
    } else {
      const [inserted] = await db
        .insert(progress)
        .values({
          userId,
          lessonId: lesson.id,
          courseId: lesson.courseId,
          watchedSeconds: isCompleted ? lesson.durationSeconds : clampedWatched,
          durationSeconds: lesson.durationSeconds,
          completed: isCompleted,
        })
        .returning();
      updatedRecord = inserted;

      if (isCompleted) {
        const [u] = await db.select().from(users).where(eq(users.id, userId));
        if (u) {
          await db
            .update(users)
            .set({ points: u.points + 50 })
            .where(eq(users.id, userId));
          bonusAwarded = true;
        }
      }
    }

    return NextResponse.json({
      success: true,
      progress: updatedRecord,
      bonusAwarded,
    });
  } catch (error) {
    console.error("POST /api/progress error:", error);
    return NextResponse.json(
      { error: "تعذر حفظ تقدم المشاهدة" },
      { status: 500 }
    );
  }
}
