import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { payments, enrollments } from "@/db/schema";
import { verifyPaymobHmac } from "@/lib/security";
import { eq } from "drizzle-orm";

export async function POST(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url);
    const body = await req.json();

    const receivedHmac =
      searchParams.get("hmac") ||
      req.headers.get("x-paymob-hmac") ||
      body.hmac ||
      "";

    const payload = {
      amountCents: Number(body.amount_cents || 0),
      currency: String(body.currency || "EGP"),
      orderId: String(body.order_id || ""),
      transactionId: String(body.transaction_id || ""),
      success: Boolean(body.success),
      userId: Number(body.user_id || 0),
    };

    const isValid = verifyPaymobHmac(payload, receivedHmac);
    if (!isValid) {
      return NextResponse.json(
        { error: "Invalid Paymob HMAC Signature", verified: false },
        { status: 401 }
      );
    }

    if (payload.success) {
      const [existingPayment] = await db
        .select()
        .from(payments)
        .where(eq(payments.paymobOrderId, payload.orderId));

      if (existingPayment) {
        await db
          .update(payments)
          .set({ status: "paid", hmacVerified: true })
          .where(eq(payments.id, existingPayment.id));

        if (existingPayment.courseId || existingPayment.packageId) {
          await db.insert(enrollments).values({
            userId: existingPayment.userId,
            courseId: existingPayment.courseId,
            packageId: existingPayment.packageId,
            grantedBy: "payment",
            status: "active",
          });
        }
      }
    }

    return NextResponse.json({
      received: true,
      hmacVerified: true,
      orderId: payload.orderId,
    });
  } catch (error) {
    console.error("POST /api/payments/webhook error:", error);
    return NextResponse.json(
      { error: "Webhook processing failed" },
      { status: 500 }
    );
  }
}
