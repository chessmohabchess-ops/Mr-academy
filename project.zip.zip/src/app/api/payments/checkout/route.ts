import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import {
  users,
  courses,
  packages,
  packageItems,
  enrollments,
  payments,
  coupons,
  couponRedemptions,
  platformSettings,
} from "@/db/schema";
import {
  getServerSession,
  computePaymobHmac,
  verifyPaymobHmac,
} from "@/lib/security";
import { eq } from "drizzle-orm";

export async function GET() {
  try {
    const [settings] = await db.select().from(platformSettings);
    return NextResponse.json({
      settings: settings || {
        vodafoneCashNumber: "01023316767",
        instapayAddress: "albayan@instapay",
        instapayName: "أ.د. محمود الشافعي (البيان التعليمية)",
        supportPhone: "01023316767",
        transferInstructions:
          "يرجى التحويل على رقم فودافون كاش أو معرف InstaPay الموضحين، ثم كتابة رقم المحفظة المحول منها ورفع صورة الإشعار للموافقة وتفعيل الكورس فوراً.",
      },
    });
  } catch (error) {
    console.error("GET /api/payments/checkout error:", error);
    return NextResponse.json({ error: "تعذر تحميل إعدادات الدفع" }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    const session = await getServerSession();
    const body = await req.json();

    let userId = session?.userId;
    if (!userId) {
      const [defaultStudent] = await db
        .select()
        .from(users)
        .where(eq(users.studentPhone, "01012345678"));
      userId = defaultStudent?.id;
    }

    if (!userId) {
      return NextResponse.json({ error: "غير مصرح" }, { status: 401 });
    }

    const [student] = await db
      .select()
      .from(users)
      .where(eq(users.id, userId));

    if (!student) {
      return NextResponse.json({ error: "الطالب غير موجود" }, { status: 404 });
    }

    // 1. Handle Wallet Top-up
    if (body.action === "topup") {
      const topupAmount = Math.max(50, Number(body.amount || 200));
      const method = String(body.method || "vodafone_cash");
      const orderId = `PMB-TOP-${Date.now().toString().slice(-6)}`;
      const transactionId = `TXN-${Math.floor(100000 + Math.random() * 900000)}`;

      const hmac = computePaymobHmac({
        amountCents: topupAmount * 100,
        currency: "EGP",
        orderId,
        transactionId,
        success: true,
        userId: student.id,
      });

      const hmacVerified = verifyPaymobHmac(
        {
          amountCents: topupAmount * 100,
          currency: "EGP",
          orderId,
          transactionId,
          success: true,
          userId: student.id,
        },
        hmac
      );

      await db.insert(payments).values({
        userId: student.id,
        amount: topupAmount,
        currency: "EGP",
        method,
        status: "paid",
        paymentType: "automated",
        paymobOrderId: orderId,
        paymobTransactionId: transactionId,
        hmacVerified,
        referenceCode: body.referenceCode || student.studentPhone,
      });

      const [updatedStudent] = await db
        .update(users)
        .set({ walletBalance: student.walletBalance + topupAmount })
        .where(eq(users.id, student.id))
        .returning();

      return NextResponse.json({
        success: true,
        message: `تم شحن المحفظة بمبلغ ${topupAmount} ج.م بنجاح عبر Paymob!`,
        walletBalance: updatedStudent.walletBalance,
        hmacSignature: hmac.slice(0, 24) + "...",
      });
    }

    // 2. Handle Coupon Validation Preview
    if (body.action === "validate_coupon") {
      const code = String(body.couponCode || "")
        .trim()
        .toUpperCase();
      const [foundCoupon] = await db
        .select()
        .from(coupons)
        .where(eq(coupons.code, code));

      if (!foundCoupon || !foundCoupon.active) {
        return NextResponse.json(
          { error: "كود الخصم غير صالح أو منتهي الصلاحية" },
          { status: 400 }
        );
      }
      if (foundCoupon.usedCount >= foundCoupon.maxUses) {
        return NextResponse.json(
          { error: "تم استنفاد الحد الأقصى لاستخدام هذا الكوبون" },
          { status: 400 }
        );
      }

      return NextResponse.json({
        valid: true,
        coupon: {
          id: foundCoupon.id,
          code: foundCoupon.code,
          discountPercent: foundCoupon.discountPercent,
        },
      });
    }

    // 3. Resolve Course or Package details
    const courseId = body.courseId ? Number(body.courseId) : null;
    const packageId = body.packageId ? Number(body.packageId) : null;
    const method = String(body.method || "vodafone_cash");
    const paymentType = String(body.paymentType || (method === "instapay" ? "direct_transfer" : "automated"));
    const couponCode = body.couponCode
      ? String(body.couponCode).trim().toUpperCase()
      : "";

    let basePrice = 0;
    let itemTitle = "";

    if (packageId) {
      const [pkg] = await db
        .select()
        .from(packages)
        .where(eq(packages.id, packageId));
      if (!pkg) {
        return NextResponse.json(
          { error: "الباقة المطلوبة غير موجودة" },
          { status: 404 }
        );
      }
      basePrice = pkg.price;
      itemTitle = pkg.title;
    } else if (courseId) {
      const [crs] = await db
        .select()
        .from(courses)
        .where(eq(courses.id, courseId));
      if (!crs) {
        return NextResponse.json(
          { error: "الكورس المطلوب غير موجود" },
          { status: 404 }
        );
      }
      basePrice = crs.price;
      itemTitle = crs.title;
    } else {
      return NextResponse.json(
        { error: "يرجى تحديد الكورس أو الباقة المراد الاشتراك بها" },
        { status: 400 }
      );
    }

    // Apply coupon if provided
    let appliedCoupon = null;
    let finalAmount = basePrice;

    if (couponCode) {
      const [foundCoupon] = await db
        .select()
        .from(coupons)
        .where(eq(coupons.code, couponCode));
      if (
        foundCoupon &&
        foundCoupon.active &&
        foundCoupon.usedCount < foundCoupon.maxUses
      ) {
        appliedCoupon = foundCoupon;
        finalAmount = Math.max(
          0,
          Math.round(basePrice * (1 - foundCoupon.discountPercent / 100))
        );
      }
    }

    // 4. DIRECT TRANSFER FLOW (InstaPay / Vodafone Cash Manual Receipt Upload)
    if (paymentType === "direct_transfer" || method === "instapay") {
      const senderPhone = String(body.senderPhone || student.studentPhone).trim();
      const senderName = String(body.senderName || student.tripleName).trim();
      const referenceCode = String(body.referenceCode || `DIR-${Date.now().toString().slice(-6)}`).trim();
      const receiptUrl = String(body.receiptUrl || "").trim();
      const transferNote = String(body.transferNote || "").trim();

      const [pendingPayment] = await db
        .insert(payments)
        .values({
          userId: student.id,
          courseId,
          packageId,
          amount: finalAmount,
          currency: "EGP",
          method,
          status: "pending",
          paymentType: "direct_transfer",
          paymobOrderId: `DIR-ORD-${Date.now().toString().slice(-6)}`,
          paymobTransactionId: referenceCode,
          hmacVerified: false,
          referenceCode,
          senderPhone,
          senderName,
          receiptUrl: receiptUrl || "https://images.unsplash.com/photo-1554224155-8d04cb21cd6c?w=600&auto=format&fit=crop&q=80",
          transferNote,
        })
        .returning();

      if (appliedCoupon) {
        await db
          .update(coupons)
          .set({ usedCount: appliedCoupon.usedCount + 1 })
          .where(eq(coupons.id, appliedCoupon.id));

        await db.insert(couponRedemptions).values({
          couponId: appliedCoupon.id,
          userId: student.id,
          paymentId: pendingPayment.id,
        });
      }

      return NextResponse.json({
        success: true,
        isPendingApproval: true,
        message: `تم استلام إشعار التحويل المباشر (${itemTitle}) بمبلغ ${finalAmount} ج.م بنجاح! سيتم مراجعته وتفعيل الكورس لك خلال دقائق عبر لوحة الإدارة.`,
        payment: pendingPayment,
      });
    }

    // 5. AUTOMATED FLOW (Wallet / Paymob Visa / Fawry Pay / Automated Vodafone)
    if (method === "wallet") {
      if (student.walletBalance < finalAmount) {
        return NextResponse.json(
          {
            error: `رصيد محفظتك الحالي (${student.walletBalance} ج.م) غير كافٍ لإتمام الدفع (${finalAmount} ج.م). يرجى شحن المحفظة أو اختيار التحويل المباشر عبر InstaPay / فودافون كاش.`,
          },
          { status: 400 }
        );
      }
      await db
        .update(users)
        .set({ walletBalance: student.walletBalance - finalAmount })
        .where(eq(users.id, student.id));
    }

    const orderId = `PMB-ORD-${Date.now().toString().slice(-6)}`;
    const transactionId = `TXN-${method.toUpperCase().slice(0, 4)}-${Math.floor(
      100000 + Math.random() * 900000
    )}`;

    const hmacPayload = {
      amountCents: finalAmount * 100,
      currency: "EGP",
      orderId,
      transactionId,
      success: true,
      userId: student.id,
    };
    const hmacSignature = computePaymobHmac(hmacPayload);
    const isHmacValid = verifyPaymobHmac(hmacPayload, hmacSignature);

    if (!isHmacValid) {
      return NextResponse.json(
        { error: "فشل التحقق من التوقيع الأمني HMAC لبوابة الدفع" },
        { status: 403 }
      );
    }

    const [paymentRecord] = await db
      .insert(payments)
      .values({
        userId: student.id,
        courseId,
        packageId,
        amount: finalAmount,
        currency: "EGP",
        method,
        status: "paid",
        paymentType: "automated",
        paymobOrderId: orderId,
        paymobTransactionId: transactionId,
        hmacVerified: true,
        referenceCode:
          body.referenceCode ||
          (method === "fawry_pay"
            ? `FAWRY-${Math.floor(10000000 + Math.random() * 90000000)}`
            : student.studentPhone),
      })
      .returning();

    if (appliedCoupon) {
      await db
        .update(coupons)
        .set({ usedCount: appliedCoupon.usedCount + 1 })
        .where(eq(coupons.id, appliedCoupon.id));

      await db.insert(couponRedemptions).values({
        couponId: appliedCoupon.id,
        userId: student.id,
        paymentId: paymentRecord.id,
      });
    }

    // Automatically unlock Course or Package
    if (packageId) {
      await db.insert(enrollments).values({
        userId: student.id,
        packageId,
        grantedBy: appliedCoupon ? "coupon" : "payment",
        status: "active",
      });

      const pkgItems = await db
        .select()
        .from(packageItems)
        .where(eq(packageItems.packageId, packageId));

      const uniqueCourseIds = Array.from(
        new Set(pkgItems.map((pi) => pi.courseId))
      );

      for (const cId of uniqueCourseIds) {
        await db.insert(enrollments).values({
          userId: student.id,
          courseId: cId,
          packageId,
          grantedBy: "payment",
          status: "active",
        });
      }
    } else if (courseId) {
      await db.insert(enrollments).values({
        userId: student.id,
        courseId,
        grantedBy: appliedCoupon ? "coupon" : "payment",
        status: "active",
      });
    }

    return NextResponse.json({
      success: true,
      message: `تم تأكيد الدفع بنجاح عبر Paymob (${itemTitle}) وفتح المحتوى فوراً!`,
      payment: paymentRecord,
      hmacVerified: true,
      hmacSignature: hmacSignature.slice(0, 32) + "...",
    });
  } catch (error) {
    console.error("POST /api/payments/checkout error:", error);
    return NextResponse.json(
      { error: "حدث خطأ أثناء معالجة عملية الدفع" },
      { status: 500 }
    );
  }
}
