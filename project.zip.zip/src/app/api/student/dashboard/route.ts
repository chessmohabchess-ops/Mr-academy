import { NextResponse } from "next/server";
import { db } from "@/db";
import {
  users,
  courses,
  sections,
  lessons,
  packages,
  packageItems,
  enrollments,
  payments,
  quizzes,
  questions,
  answers,
  quizAttempts,
  progress,
  coupons,
  platformSettings,
} from "@/db/schema";
import { ensureSeeded } from "@/db/seed";
import { getServerSession, sanitizeUserForStudent } from "@/lib/security";
import { eq, desc, asc } from "drizzle-orm";

export async function GET() {
  try {
    await ensureSeeded();
    const session = await getServerSession();

    let currentUser = null;
    if (session) {
      const [found] = await db
        .select()
        .from(users)
        .where(eq(users.id, session.userId));
      if (found) currentUser = found;
    }

    if (!currentUser) {
      const [defaultStudent] = await db
        .select()
        .from(users)
        .where(eq(users.studentPhone, "01012345678"));
      currentUser = defaultStudent;
    }

    if (!currentUser) {
      return NextResponse.json({ error: "غير مصرح" }, { status: 401 });
    }

    const [
      allCourses,
      allSections,
      allLessons,
      allPackages,
      allPackageItems,
      userEnrollments,
      userPayments,
      userProgress,
      allQuizzes,
      allQuestions,
      allAnswers,
      userAttempts,
      activeCoupons,
      [settings],
    ] = await Promise.all([
      db.select().from(courses).orderBy(asc(courses.id)),
      db.select().from(sections).orderBy(asc(sections.orderIndex)),
      db.select().from(lessons).orderBy(asc(lessons.orderIndex)),
      db.select().from(packages).orderBy(asc(packages.id)),
      db.select().from(packageItems).orderBy(asc(packageItems.orderIndex)),
      db
        .select()
        .from(enrollments)
        .where(eq(enrollments.userId, currentUser.id)),
      db
        .select()
        .from(payments)
        .where(eq(payments.userId, currentUser.id))
        .orderBy(desc(payments.createdAt)),
      db
        .select()
        .from(progress)
        .where(eq(progress.userId, currentUser.id))
        .orderBy(desc(progress.updatedAt)),
      db.select().from(quizzes).orderBy(asc(quizzes.id)),
      db.select().from(questions).orderBy(asc(questions.orderIndex)),
      db.select().from(answers).orderBy(asc(answers.orderIndex)),
      db
        .select()
        .from(quizAttempts)
        .where(eq(quizAttempts.userId, currentUser.id))
        .orderBy(desc(quizAttempts.completedAt)),
      db.select().from(coupons).where(eq(coupons.active, true)),
      db.select().from(platformSettings),
    ]);

    const activeCourseIds = new Set(
      userEnrollments
        .filter((e) => e.status === "active" && e.courseId)
        .map((e) => e.courseId as number)
    );

    const activePackageIds = new Set(
      userEnrollments
        .filter((e) => e.status === "active" && e.packageId)
        .map((e) => e.packageId as number)
    );

    for (const item of allPackageItems) {
      if (activePackageIds.has(item.packageId)) {
        activeCourseIds.add(item.courseId);
      }
    }

    const progressByLessonId = new Map(
      userProgress.map((p) => [p.lessonId, p])
    );

    // Paywall Enforcement: Lock all lessons by default unless free or enrolled
    const enrichedLessons = allLessons.map((lesson) => {
      const prog = progressByLessonId.get(lesson.id);
      const isPurchased =
        lesson.isFreePreview ||
        lesson.type === "free" ||
        activeCourseIds.has(lesson.courseId) ||
        currentUser.role === "admin";

      const courseObj = allCourses.find((c) => c.id === lesson.courseId);
      const sectionObj = allSections.find((s) => s.id === lesson.sectionId);

      return {
        ...lesson,
        courseTitle: courseObj?.title || "",
        coursePrice: courseObj?.price || 0,
        instructorName: courseObj?.instructorName || "أ.د. محمود الشافعي",
        sectionTitle: sectionObj?.title || "",
        isUnlocked: Boolean(isPurchased),
        watchedSeconds: prog?.watchedSeconds || 0,
        completed: prog?.completed || false,
        progressPercent: prog
          ? Math.min(
              100,
              Math.round((prog.watchedSeconds / lesson.durationSeconds) * 100)
            )
          : 0,
      };
    });

    const totalLessonsCount = enrichedLessons.length;
    const completedLessonsCount = enrichedLessons.filter(
      (l) => l.completed
    ).length;
    const inProgressLessonsCount = enrichedLessons.filter(
      (l) => !l.completed && l.watchedSeconds > 0
    ).length;
    const notStartedLessonsCount = Math.max(
      0,
      totalLessonsCount - completedLessonsCount - inProgressLessonsCount
    );
    const overallCompletionPercent =
      totalLessonsCount > 0
        ? Math.round((completedLessonsCount / totalLessonsCount) * 100)
        : 0;

    const continueWatching = enrichedLessons.filter(
      (l) => l.watchedSeconds > 0 && !l.completed && l.isUnlocked
    );

    const enrichedPackages = allPackages.map((pkg) => {
      const items = allPackageItems
        .filter((pi) => pi.packageId === pkg.id)
        .map((pi) => {
          const lesson = enrichedLessons.find((l) => l.id === pi.lessonId);
          const course = allCourses.find((c) => c.id === pi.courseId);
          return {
            ...pi,
            courseTitle: course?.title || "",
            lessonStatus: lesson?.completed
              ? "completed"
              : lesson && lesson.watchedSeconds > 0
              ? "in_progress"
              : lesson?.isUnlocked
              ? "unlocked"
              : "locked",
            durationSeconds: lesson?.durationSeconds || 2700,
            progressPercent: lesson?.progressPercent || 0,
          };
        });

      const isSubscribed =
        activePackageIds.has(pkg.id) ||
        (items.length > 0 && items.every((it) => activeCourseIds.has(it.courseId)));

      let features: string[] = [];
      try {
        features = JSON.parse(pkg.featuresJson);
      } catch {
        features = [];
      }

      return {
        ...pkg,
        features,
        items,
        isSubscribed,
      };
    });

    const enrichedQuizzes = allQuizzes.map((q) => {
      const qQuestions = allQuestions
        .filter((ques) => ques.quizId === q.id)
        .map((ques) => ({
          id: ques.id,
          quizId: ques.quizId,
          questionText: ques.questionText,
          points: ques.points,
          orderIndex: ques.orderIndex,
          answers: allAnswers
            .filter((ans) => ans.questionId === ques.id)
            .map((ans) => ({
              id: ans.id,
              questionId: ans.questionId,
              answerText: ans.answerText,
              orderIndex: ans.orderIndex,
            })),
        }));

      const attempts = userAttempts.filter((att) => att.quizId === q.id);
      const bestAttempt =
        attempts.length > 0
          ? attempts.reduce((prev, curr) =>
              curr.percentage > prev.percentage ? curr : prev
            )
          : null;

      return {
        ...q,
        questionsCount: qQuestions.length,
        questions: qQuestions,
        attemptsCount: attempts.length,
        bestAttempt,
      };
    });

    const mistakesBank: Array<{
      attemptId: number;
      quizId: number;
      quizTitle: string;
      questionId: number;
      questionText: string;
      selectedAnswer: string;
      correctAnswer: string;
      explanation: string;
      completedAt: Date;
    }> = [];

    for (const att of userAttempts) {
      try {
        const parsed = JSON.parse(att.answersJson) as Array<{
          questionId: number;
          questionText: string;
          selectedAnswer: string;
          correctAnswer: string;
          isCorrect: boolean;
          explanation: string;
          quizTitle?: string;
        }>;
        const quizObj = allQuizzes.find((qz) => qz.id === att.quizId);
        for (const item of parsed) {
          if (!item.isCorrect) {
            mistakesBank.push({
              attemptId: att.id,
              quizId: att.quizId,
              quizTitle: item.quizTitle || quizObj?.title || "اختبار",
              questionId: item.questionId,
              questionText: item.questionText,
              selectedAnswer: item.selectedAnswer,
              correctAnswer: item.correctAnswer,
              explanation: item.explanation,
              completedAt: att.completedAt,
            });
          }
        }
      } catch {
        // ignore
      }
    }

    return NextResponse.json({
      student: sanitizeUserForStudent(currentUser, true),
      settings: settings || {
        vodafoneCashNumber: "01023316767",
        instapayAddress: "albayan@instapay",
        instapayName: "أ.د. محمود الشافعي",
        supportPhone: "01023316767",
      },
      stats: {
        walletBalance: currentUser.walletBalance,
        points: currentUser.points,
        bookGiftCode: currentUser.bookGiftCode,
        totalLessonsCount,
        completedLessonsCount,
        inProgressLessonsCount,
        notStartedLessonsCount,
        overallCompletionPercent,
      },
      courses: allCourses.map((c) => ({
        ...c,
        isEnrolled:
          c.type === "free" ||
          activeCourseIds.has(c.id) ||
          currentUser.role === "admin",
      })),
      sections: allSections,
      lessons: enrichedLessons,
      continueWatching,
      packages: enrichedPackages,
      quizzes: enrichedQuizzes,
      quizAttempts: userAttempts.map((att) => {
        const qz = allQuizzes.find((q) => q.id === att.quizId);
        return {
          ...att,
          quizTitle: qz?.title || "اختبار",
          passingScore: qz?.passingScore || 60,
        };
      }),
      mistakesBank,
      payments: userPayments,
      availableCoupons: activeCoupons.map((c) => ({
        code: c.code,
        discountPercent: c.discountPercent,
      })),
    });
  } catch (error) {
    console.error("GET /api/student/dashboard error:", error);
    return NextResponse.json(
      { error: "تعذر تحميل بيانات لوحة الطالب" },
      { status: 500 }
    );
  }
}
