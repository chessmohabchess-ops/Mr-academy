import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import {
  users,
  quizzes,
  questions,
  answers,
  quizAttempts,
} from "@/db/schema";
import { getServerSession } from "@/lib/security";
import { eq, asc } from "drizzle-orm";

export async function POST(req: NextRequest) {
  try {
    const session = await getServerSession();
    const body = await req.json();
    const quizId = Number(body.quizId);
    const submittedAnswers: Record<string, number> = body.answers || {};

    if (!quizId) {
      return NextResponse.json(
        { error: "معرف الاختبار مطلوب" },
        { status: 400 }
      );
    }

    let userId = session?.userId;
    if (!userId) {
      const [defaultStudent] = await db
        .select()
        .from(users)
        .where(eq(users.studentPhone, "01012345678"));
      userId = defaultStudent?.id;
    }

    if (!userId) {
      return NextResponse.json({ error: "غير مصرح" }, { status: 401 });
    }

    const [quiz] = await db
      .select()
      .from(quizzes)
      .where(eq(quizzes.id, quizId));

    if (!quiz) {
      return NextResponse.json(
        { error: "الاختبار غير موجود" },
        { status: 404 }
      );
    }

    const quizQuestions = await db
      .select()
      .from(questions)
      .where(eq(questions.quizId, quiz.id))
      .orderBy(asc(questions.orderIndex));

    const allAnswers = await db.select().from(answers);

    let earnedScore = 0;
    let totalPossibleMarks = 0;
    const detailedBreakdown = [];

    for (const q of quizQuestions) {
      totalPossibleMarks += q.points;
      const qAnswers = allAnswers.filter((a) => a.questionId === q.id);
      const correctAns = qAnswers.find((a) => a.isCorrect);
      const selectedAnsId = Number(submittedAnswers[String(q.id)]);
      const selectedAns = qAnswers.find((a) => a.id === selectedAnsId);

      const isCorrect = Boolean(
        selectedAns && correctAns && selectedAns.id === correctAns.id
      );

      if (isCorrect) {
        earnedScore += q.points;
      }

      detailedBreakdown.push({
        questionId: q.id,
        questionText: q.questionText,
        selectedAnswer: selectedAns?.answerText || "لم تتم الإجابة",
        correctAnswer: correctAns?.answerText || "",
        isCorrect,
        explanation: q.explanation,
        points: q.points,
        quizTitle: quiz.title,
      });
    }

    const finalTotalMarks = totalPossibleMarks || quiz.totalMarks || 20;
    const percentage = Math.round((earnedScore / finalTotalMarks) * 100);
    const passed = percentage >= quiz.passingScore;

    const [attempt] = await db
      .insert(quizAttempts)
      .values({
        quizId: quiz.id,
        userId,
        score: earnedScore,
        totalMarks: finalTotalMarks,
        percentage,
        passed,
        answersJson: JSON.stringify(detailedBreakdown),
      })
      .returning();

    // Award points to student
    const [u] = await db.select().from(users).where(eq(users.id, userId));
    if (u) {
      const pointsToAdd = passed ? 100 : 30;
      await db
        .update(users)
        .set({ points: u.points + pointsToAdd })
        .where(eq(users.id, userId));
    }

    return NextResponse.json({
      success: true,
      attempt: {
        ...attempt,
        quizTitle: quiz.title,
        passingScore: quiz.passingScore,
        breakdown: detailedBreakdown,
      },
    });
  } catch (error) {
    console.error("POST /api/quizzes/submit error:", error);
    return NextResponse.json(
      { error: "تعذر تصحيح الاختبار وحفظ النتيجة" },
      { status: 500 }
    );
  }
}
