import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { users, enrollments, courses } from "@/db/schema";
import { ensureSeeded } from "@/db/seed";
import {
  isValidEgyptianPhone,
  isValidTripleName,
  hashPassword,
  verifyPassword,
  createSessionToken,
  getServerSession,
  sanitizeUserForStudent,
} from "@/lib/security";
import { eq } from "drizzle-orm";

export async function GET() {
  try {
    await ensureSeeded();
    const session = await getServerSession();

    let currentUser = null;
    if (session) {
      const [found] = await db
        .select()
        .from(users)
        .where(eq(users.id, session.userId));
      if (found && found.status !== "banned") {
        currentUser = found;
      }
    }

    // If no active session cookie yet, default to the main seeded student for immediate interactive preview
    if (!currentUser) {
      const [defaultStudent] = await db
        .select()
        .from(users)
        .where(eq(users.studentPhone, "01012345678"));
      currentUser = defaultStudent || null;
    }

    if (!currentUser) {
      return NextResponse.json({ user: null }, { status: 200 });
    }

    const token = createSessionToken({
      userId: currentUser.id,
      role: currentUser.role as "student" | "admin",
      studentPhone: currentUser.studentPhone,
    });

    const response = NextResponse.json({
      user: sanitizeUserForStudent(currentUser, true),
    });

    response.cookies.set("albayan_session", token, {
      httpOnly: true,
      path: "/",
      sameSite: "lax",
      maxAge: 60 * 60 * 24 * 7,
    });

    return response;
  } catch (error) {
    console.error("GET /api/auth error:", error);
    return NextResponse.json(
      { error: "حدث خطأ أثناء التحقق من الجلسة" },
      { status: 500 }
    );
  }
}

export async function POST(req: NextRequest) {
  try {
    await ensureSeeded();
    const body = await req.json();
    const { action } = body;

    if (action === "logout") {
      const response = NextResponse.json({
        success: true,
        message: "تم تسجيل الخروج بنجاح",
      });
      response.cookies.delete("albayan_session");
      return response;
    }

    if (action === "quick_switch") {
      const targetPhone =
        body.role === "admin" ? "01000000001" : "01012345678";
      const [targetUser] = await db
        .select()
        .from(users)
        .where(eq(users.studentPhone, targetPhone));

      if (!targetUser) {
        return NextResponse.json(
          { error: "الحساب التجريبي غير موجود" },
          { status: 404 }
        );
      }

      await db
        .update(users)
        .set({ lastLoginAt: new Date() })
        .where(eq(users.id, targetUser.id));

      const token = createSessionToken({
        userId: targetUser.id,
        role: targetUser.role as "student" | "admin",
        studentPhone: targetUser.studentPhone,
      });

      const response = NextResponse.json({
        success: true,
        user: sanitizeUserForStudent(targetUser, true),
      });

      response.cookies.set("albayan_session", token, {
        httpOnly: true,
        path: "/",
        sameSite: "lax",
        maxAge: 60 * 60 * 24 * 7,
      });
      return response;
    }

    if (action === "login") {
      const studentPhone = String(body.studentPhone || "").trim();
      const password = String(body.password || "");

      if (!isValidEgyptianPhone(studentPhone)) {
        return NextResponse.json(
          {
            error:
              "يرجى إدخال رقم هاتف مصري صحيح يبدأ بـ (010 أو 011 أو 012 أو 015) ومكون من 11 رقماً.",
          },
          { status: 400 }
        );
      }

      const [existing] = await db
        .select()
        .from(users)
        .where(eq(users.studentPhone, studentPhone));

      if (!existing) {
        return NextResponse.json(
          { error: "رقم الهاتف غير مسجل بالمنصة أو كلمة المرور غير صحيحة." },
          { status: 401 }
        );
      }

      if (existing.status === "banned") {
        return NextResponse.json(
          {
            error:
              "تم حظر هذا الحساب من قِبل إدارة المنصة لمخالفة سياسة الاستخدام. يرجى التواصل مع الدعم الفني.",
          },
          { status: 403 }
        );
      }

      const validPw = await verifyPassword(password, existing.passwordHash);
      if (!validPw) {
        return NextResponse.json(
          { error: "كلمة المرور غير صحيحة. يرجى المحاولة مرة أخرى." },
          { status: 401 }
        );
      }

      await db
        .update(users)
        .set({ lastLoginAt: new Date() })
        .where(eq(users.id, existing.id));

      const token = createSessionToken({
        userId: existing.id,
        role: existing.role as "student" | "admin",
        studentPhone: existing.studentPhone,
      });

      const response = NextResponse.json({
        success: true,
        user: sanitizeUserForStudent(existing, true),
      });

      response.cookies.set("albayan_session", token, {
        httpOnly: true,
        path: "/",
        sameSite: "lax",
        maxAge: 60 * 60 * 24 * 7,
      });

      return response;
    }

    if (action === "register") {
      const tripleName = String(body.tripleName || "").trim();
      const studentPhone = String(body.studentPhone || "").trim();
      const guardianPhone = String(body.guardianPhone || "").trim();
      const motherPhone = String(body.motherPhone || "").trim();
      const email = body.email ? String(body.email).trim() : null;
      const password = String(body.password || "");
      const gradeLevel = String(
        body.gradeLevel || "الصف الثالث الثانوي - علمي علوم"
      );

      // Rule 1: Prevent account creation without all 3 required phones & triple name
      if (!tripleName || !studentPhone || !guardianPhone || !motherPhone || !password) {
        return NextResponse.json(
          {
            error:
              "جميع الحقول الأساسية إلزامية: الاسم الثلاثي، رقم هاتف الطالب، رقم هاتف ولي الأمر، رقم هاتف الأم، وكلمة المرور.",
          },
          { status: 400 }
        );
      }

      if (!isValidTripleName(tripleName)) {
        return NextResponse.json(
          {
            error:
              "يجب إدخال الاسم الثلاثي كاملاً باللغة العربية (ثلاثة أسماء على الأقل).",
          },
          { status: 400 }
        );
      }

      // Rule 2: Validate Egyptian Phone Format (010, 011, 012, 015 + 8 digits) for all 3 numbers
      if (!isValidEgyptianPhone(studentPhone)) {
        return NextResponse.json(
          {
            error:
              "رقم هاتف الطالب غير صحيح. يجب أن يكون رقماً مصرياً يبدأ بـ (010, 011, 012, 015) ومكوناً من 11 رقماً.",
          },
          { status: 400 }
        );
      }

      if (!isValidEgyptianPhone(guardianPhone)) {
        return NextResponse.json(
          {
            error:
              "رقم هاتف ولي الأمر غير صحيح. يجب أن يكون رقماً مصرياً يبدأ بـ (010, 011, 012, 015) ومكوناً من 11 رقماً.",
          },
          { status: 400 }
        );
      }

      if (!isValidEgyptianPhone(motherPhone)) {
        return NextResponse.json(
          {
            error:
              "رقم هاتف الأم غير صحيح. يجب أن يكون رقماً مصرياً يبدأ بـ (010, 011, 012, 015) ومكوناً من 11 رقماً.",
          },
          { status: 400 }
        );
      }

      if (
        studentPhone === guardianPhone ||
        studentPhone === motherPhone
      ) {
        return NextResponse.json(
          {
            error:
              "لا يمكن تكرار رقم هاتف الطالب في خانة رقم ولي الأمر أو رقم الأم. يرجى إدخال الأرقام الحقيقية لأولياء الأمور.",
          },
          { status: 400 }
        );
      }

      if (password.length < 6) {
        return NextResponse.json(
          { error: "كلمة المرور يجب ألا تقل عن 6 أحرف أو أرقام." },
          { status: 400 }
        );
      }

      // Rule 3: Prevent duplicate accounts with the same studentPhone
      const [duplicate] = await db
        .select()
        .from(users)
        .where(eq(users.studentPhone, studentPhone));

      if (duplicate) {
        return NextResponse.json(
          {
            error:
              "رقم هاتف الطالب مسجل بالفعل في المنصة! يمنع إنشاء حسابات متعددة بنفس رقم الهاتف.",
          },
          { status: 409 }
        );
      }

      // Hash password with Bcrypt
      const passwordHash = await hashPassword(password);
      const giftCode = `BAYAN-GIFT-${Math.floor(1000 + Math.random() * 9000)}`;

      const [newUser] = await db
        .insert(users)
        .values({
          tripleName,
          studentPhone,
          guardianPhone,
          motherPhone,
          email,
          passwordHash,
          role: "student",
          status: "active",
          gradeLevel,
          walletBalance: 100, // Welcome bonus
          points: 200,
          bookGiftCode: giftCode,
        })
        .returning();

      // Automatically enroll new student in free foundation courses
      const freeCourses = await db
        .select()
        .from(courses)
        .where(eq(courses.type, "free"));

      for (const fc of freeCourses) {
        await db.insert(enrollments).values({
          userId: newUser.id,
          courseId: fc.id,
          grantedBy: "free",
          status: "active",
        });
      }

      const token = createSessionToken({
        userId: newUser.id,
        role: "student",
        studentPhone: newUser.studentPhone,
      });

      const response = NextResponse.json({
        success: true,
        message: "تم إنشاء حسابك بنجاح وتأمين بياناتك!",
        user: sanitizeUserForStudent(newUser, true),
      });

      response.cookies.set("albayan_session", token, {
        httpOnly: true,
        path: "/",
        sameSite: "lax",
        maxAge: 60 * 60 * 24 * 7,
      });

      return response;
    }

    return NextResponse.json({ error: "إجراء غير معروف" }, { status: 400 });
  } catch (error) {
    console.error("POST /api/auth error:", error);
    return NextResponse.json(
      { error: "حدث خطأ في الخادم أثناء معالجة الطلب" },
      { status: 500 }
    );
  }
}
