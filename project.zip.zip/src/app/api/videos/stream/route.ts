import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { lessons, videoAssets } from "@/db/schema";
import { verifySignedVideoStreamToken } from "@/lib/security";
import { eq } from "drizzle-orm";

export async function GET(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url);
    const token = searchParams.get("token") || "";
    const signature = searchParams.get("X-Amz-Signature") || "";

    if (!token || !signature) {
      return NextResponse.json(
        { error: "رابط الفيديو المؤقت يفتقد لتوقيع الحماية" },
        { status: 403 }
      );
    }

    const decoded = JSON.parse(
      Buffer.from(token, "base64url").toString("utf-8")
    ) as { u: number; l: number; exp: number };

    const [lesson] = await db
      .select()
      .from(lessons)
      .where(eq(lessons.id, decoded.l));

    if (!lesson) {
      return NextResponse.json({ error: "المحاضرة غير موجودة" }, { status: 404 });
    }

    let storageKey = `r2://albayan-private-videos/2026/lesson-${lesson.id}.mp4`;
    if (lesson.videoAssetId) {
      const [asset] = await db
        .select()
        .from(videoAssets)
        .where(eq(videoAssets.id, lesson.videoAssetId));
      if (asset) {
        storageKey = asset.storageKey;
      }
    }

    const verification = verifySignedVideoStreamToken({
      token,
      signature,
      storageKey,
    });

    if (!verification.valid) {
      return NextResponse.json(
        { error: verification.reason || "رابط غير صالح" },
        { status: 403 }
      );
    }

    return NextResponse.json({
      verified: true,
      lessonId: lesson.id,
      expiresAt: decoded.exp * 1000,
      message: "تم التحقق من التوقيع الرقمي المؤقت (Signed R2/S3 Stream Active)",
    });
  } catch (error) {
    console.error("GET /api/videos/stream error:", error);
    return NextResponse.json(
      { error: "رمز البث المؤقت غير صالح" },
      { status: 403 }
    );
  }
}
