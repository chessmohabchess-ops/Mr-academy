import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import {
  users,
  lessons,
  videoAssets,
  enrollments,
  packageItems,
  progress,
} from "@/db/schema";
import {
  getServerSession,
  createSignedVideoStreamUrl,
} from "@/lib/security";
import { eq, and } from "drizzle-orm";

export async function POST(req: NextRequest) {
  try {
    const session = await getServerSession();
    const body = await req.json();
    const lessonId = Number(body.lessonId);

    if (!lessonId) {
      return NextResponse.json(
        { error: "معرف المحاضرة مطلوب" },
        { status: 400 }
      );
    }

    let currentUser = null;
    if (session) {
      const [found] = await db
        .select()
        .from(users)
        .where(eq(users.id, session.userId));
      currentUser = found;
    } else {
      const [defaultStudent] = await db
        .select()
        .from(users)
        .where(eq(users.studentPhone, "01012345678"));
      currentUser = defaultStudent;
    }

    if (!currentUser || currentUser.status === "banned") {
      return NextResponse.json(
        { error: "غير مصرح لك بمشاهدة هذا المحتوى المحمي." },
        { status: 403 }
      );
    }

    const [lesson] = await db
      .select()
      .from(lessons)
      .where(eq(lessons.id, lessonId));

    if (!lesson) {
      return NextResponse.json(
        { error: "المحاضرة غير موجودة" },
        { status: 404 }
      );
    }

    // Check enrollment authorization on the server
    let isAuthorized =
      lesson.isFreePreview ||
      lesson.type === "free" ||
      currentUser.role === "admin";

    if (!isAuthorized) {
      const userEnrollments = await db
        .select()
        .from(enrollments)
        .where(
          and(
            eq(enrollments.userId, currentUser.id),
            eq(enrollments.status, "active")
          )
        );

      const enrolledCourseIds = new Set(
        userEnrollments.filter((e) => e.courseId).map((e) => e.courseId as number)
      );
      const enrolledPkgIds = new Set(
        userEnrollments.filter((e) => e.packageId).map((e) => e.packageId as number)
      );

      if (enrolledCourseIds.has(lesson.courseId)) {
        isAuthorized = true;
      } else if (enrolledPkgIds.size > 0) {
        const pkgItems = await db
          .select()
          .from(packageItems)
          .where(eq(packageItems.courseId, lesson.courseId));
        if (pkgItems.some((pi) => enrolledPkgIds.has(pi.packageId))) {
          isAuthorized = true;
        }
      }
    }

    if (!isAuthorized) {
      return NextResponse.json(
        {
          error:
            "هذه المحاضرة مدفوعة ومحمية. يرجى الاشتراك في الكورس أو الباقة أولاً لفتح المشاهدة.",
          requiresPurchase: true,
        },
        { status: 403 }
      );
    }

    let storageKey = `r2://albayan-private-videos/2026/lesson-${lesson.id}.mp4`;
    let resolution = "1080p Full HD";
    let provider = "cloudflare_r2";

    if (lesson.videoAssetId) {
      const [asset] = await db
        .select()
        .from(videoAssets)
        .where(eq(videoAssets.id, lesson.videoAssetId));
      if (asset) {
        storageKey = asset.storageKey;
        resolution = asset.resolution;
        provider = asset.provider;
      }
    }

    const signedData = createSignedVideoStreamUrl({
      userId: currentUser.id,
      lessonId: lesson.id,
      storageKey,
      ttlSeconds: 900, // 15-minute temporary signed URL
    });

    const [existingProgress] = await db
      .select()
      .from(progress)
      .where(
        and(
          eq(progress.userId, currentUser.id),
          eq(progress.lessonId, lesson.id)
        )
      );

    return NextResponse.json({
      authorized: true,
      lessonId: lesson.id,
      title: lesson.title,
      durationSeconds: lesson.durationSeconds,
      watchedSeconds: existingProgress?.watchedSeconds || 0,
      completed: existingProgress?.completed || false,
      signedStream: {
        url: signedData.signedUrl,
        expiresAt: signedData.expiresAt,
        provider: signedData.provider,
        resolution,
        storageProvider: provider,
      },
      watermark: {
        studentName: currentUser.tripleName,
        studentPhone: currentUser.studentPhone,
      },
    });
  } catch (error) {
    console.error("POST /api/videos/authorize error:", error);
    return NextResponse.json(
      { error: "تعذر توليد الرابط المؤقت للفيديو المحمي" },
      { status: 500 }
    );
  }
}
