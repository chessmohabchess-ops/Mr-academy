"use client";

import React, { useEffect, useState, useCallback } from "react";
import Link from "next/link";
import {
  LayoutDashboard,
  PlayCircle,
  Package,
  FileCheck2,
  BookOpenCheck,
  ShoppingBag,
  UserCheck,
  ChevronRight,
  ChevronLeft,
  Wallet,
  Award,
  Gift,
  Copy,
  Check,
  Play,
  Lock,
  CheckCircle2,
  Clock,
  FileText,
  UploadCloud,
  AlertTriangle,
  Truck,
  HelpCircle,
  ShieldAlert,
  UserPlus,
  LogOut,
  Sparkles,
  Plus,
  X,
  Trash2,
  Menu,
  Sun,
  Moon,
  CreditCard,
  Send,
  DollarSign,
} from "lucide-react";
import {
  LectureCompletionPieChart,
  ExamScoresBarChart,
} from "@/components/AnalyticsCharts";
import { ProtectedVideoModal } from "@/components/ProtectedVideoModal";
import { PaymobCheckoutModal } from "@/components/PaymobCheckoutModal";
import { AuthModal } from "@/components/AuthModal";

interface LessonItem {
  id: number;
  sectionId: number;
  courseId: number;
  title: string;
  description: string;
  durationSeconds: number;
  type: "online" | "center" | "free";
  pdfTitle: string | null;
  pdfUrl: string | null;
  homeworkTitle: string | null;
  isFreePreview: boolean;
  courseTitle: string;
  coursePrice?: number;
  instructorName?: string;
  sectionTitle: string;
  isUnlocked: boolean;
  watchedSeconds: number;
  completed: boolean;
  progressPercent: number;
}

interface PackageItemDetail {
  id: number;
  packageId: number;
  courseId: number;
  lessonId: number | null;
  itemTitle: string;
  itemType: string;
  courseTitle: string;
  lessonStatus: "completed" | "in_progress" | "unlocked" | "locked";
  durationSeconds: number;
  progressPercent: number;
}

interface PackageData {
  id: number;
  title: string;
  subtitle: string;
  description: string;
  price: number;
  originalPrice: number;
  badge: string;
  durationLabel: string;
  features: string[];
  items: PackageItemDetail[];
  isSubscribed: boolean;
}

interface QuizQuestion {
  id: number;
  quizId: number;
  questionText: string;
  points: number;
  orderIndex: number;
  answers: Array<{
    id: number;
    questionId: number;
    answerText: string;
    orderIndex: number;
  }>;
}

interface QuizData {
  id: number;
  courseId: number;
  lessonId: number | null;
  title: string;
  description: string;
  passingScore: number;
  durationMinutes: number;
  totalMarks: number;
  questionsCount: number;
  questions: QuizQuestion[];
  attemptsCount: number;
  bestAttempt: {
    id: number;
    score: number;
    totalMarks: number;
    percentage: number;
    passed: boolean;
  } | null;
}

function formatSeconds(sec: number) {
  const mins = Math.floor(sec / 60);
  const rem = sec % 60;
  return `${mins}:${String(rem).padStart(2, "0")}`;
}

/**
 * Smart Time-Aware Greeting Function (صباح الخير / مساء الخير)
 * 5:00 AM - 11:59 AM -> صباح الخير
 * 12:00 PM - 4:59 AM -> مساء الخير
 */
function getSmartTimeGreeting(name: string): { text: string; isMorning: boolean } {
  const hour = new Date().getHours();
  const isMorning = hour >= 5 && hour < 12;
  const greetingText = isMorning
    ? `صباح الخير، ${name}`
    : `مساء الخير، ${name}`;
  return { text: greetingText, isMorning };
}

export default function StudentPlatformHome() {
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const [activeSection, setActiveSection] = useState<
    | "dashboard"
    | "lectures"
    | "packages"
    | "quizzes"
    | "materials"
    | "store"
    | "support_profile"
  >("dashboard");

  // Sub-tabs
  const [lectureFilter, setLectureFilter] = useState<
    "all" | "online" | "center" | "free" | "purchased"
  >("all");
  const [materialsTab, setMaterialsTab] = useState<
    "pdfs" | "homework" | "mistakes"
  >("pdfs");
  const [storeTab, setStoreTab] = useState<"buy" | "tracking" | "purchased">(
    "buy"
  );

  // Dashboard state from API
  const [loading, setLoading] = useState(true);
  const [toast, setToast] = useState<string | null>(null);
  const [copiedCode, setCopiedCode] = useState(false);

  const [student, setStudent] = useState<{
    id: number;
    tripleName: string;
    studentPhone: string;
    guardianPhone?: string;
    motherPhone?: string;
    email?: string | null;
    role: string;
    gradeLevel: string;
    walletBalance: number;
    points: number;
    bookGiftCode: string;
  } | null>(null);

  const [stats, setStats] = useState({
    walletBalance: 450,
    points: 1280,
    bookGiftCode: "BAYAN-GIFT-8841",
    totalLessonsCount: 7,
    completedLessonsCount: 3,
    inProgressLessonsCount: 2,
    notStartedLessonsCount: 2,
    overallCompletionPercent: 43,
  });

  const [lessonsList, setLessonsList] = useState<LessonItem[]>([]);
  const [continueWatching, setContinueWatching] = useState<LessonItem[]>([]);
  const [packagesList, setPackagesList] = useState<PackageData[]>([]);
  const [quizzesList, setQuizzesList] = useState<QuizData[]>([]);
  const [quizAttempts, setQuizAttempts] = useState<
    Array<{
      id: number;
      quizId: number;
      quizTitle: string;
      score: number;
      totalMarks: number;
      percentage: number;
      passed: boolean;
      completedAt: string;
    }>
  >([]);
  const [mistakesBank, setMistakesBank] = useState<
    Array<{
      attemptId: number;
      quizId: number;
      quizTitle: string;
      questionId: number;
      questionText: string;
      selectedAnswer: string;
      correctAnswer: string;
      explanation: string;
    }>
  >([]);

  // Modals State
  const [activeVideoLessonId, setActiveVideoLessonId] = useState<number | null>(
    null
  );
  const [inspectingPackage, setInspectingPackage] =
    useState<PackageData | null>(null);
  const [checkoutItem, setCheckoutItem] = useState<{
    courseId?: number;
    packageId?: number;
    title: string;
    price: number;
    subtitle?: string;
  } | null>(null);
  const [authModalOpen, setAuthModalOpen] = useState(false);
  const [authInitialMode, setAuthInitialMode] = useState<"login" | "register">(
    "register"
  );

  // Active Quiz Runner State
  const [activeQuiz, setActiveQuiz] = useState<QuizData | null>(null);
  const [quizAnswers, setQuizAnswers] = useState<Record<string, number>>({});
  const [quizSubmitting, setQuizSubmitting] = useState(false);
  const [quizResult, setQuizResult] = useState<{
    score: number;
    totalMarks: number;
    percentage: number;
    passed: boolean;
    quizTitle: string;
    breakdown: Array<{
      questionId: number;
      questionText: string;
      selectedAnswer: string;
      correctAnswer: string;
      isCorrect: boolean;
      explanation: string;
    }>;
  } | null>(null);

  // Homework & Store Interactive State
  const [submittedHomeworks, setSubmittedHomeworks] = useState<number[]>([1, 5]);
  const [homeworkAnswerNote, setHomeworkAnswerNote] = useState("");
  const [purchasedBooks, setPurchasedBooks] = useState<
    Array<{
      id: number;
      title: string;
      price: number;
      trackingCode: string;
      step: number;
      orderDate: string;
    }>
  >([
    {
      id: 101,
      title: "كتاب البيان في النحو والبلاغة المتحررة (طبعة 2026 الفاخرة)",
      price: 185,
      trackingCode: "SHP-EG-884920",
      step: 3,
      orderDate: "2026-02-20",
    },
  ]);

  // Support Tickets State
  const [supportQuestion, setSupportQuestion] = useState("");
  const [supportTickets, setSupportTickets] = useState<
    Array<{
      id: number;
      question: string;
      answer: string;
      status: string;
      date: string;
    }>
  >([
    {
      id: 1,
      question:
        "يا أستاذنا، متى نعرب الاسم الواقع بعد (لا سيما) خبراً لمبتدأ محذوف ومتى نعربه مضافاً إليه؟",
      answer:
        "إذا كان الاسم بعد (لا سيما) معرفة جاز فيه الرفع على أنه خبر لمبتدأ محذوف (لا سيما المتفوقُ) والجر على الإضافة (المتفوقِ)، أما إذا كان نكرة فيجوز فيه الرفع والجر والنصب على التمييز!",
      status: "تم الرد من أ.د. محمود الشافعي",
      date: "منذ ساعتين",
    },
  ]);

  // Profile Edit State
  const [profileName, setProfileName] = useState("");
  const [profileGuardianPhone, setProfileGuardianPhone] = useState("");
  const [profileMotherPhone, setProfileMotherPhone] = useState("");
  const [profileEmail, setProfileEmail] = useState("");
  const [profileNewPassword, setProfileNewPassword] = useState("");

  const showNotification = (msg: string) => {
    setToast(msg);
    setTimeout(() => setToast(null), 4000);
  };

  const fetchDashboard = useCallback(async () => {
    try {
      const res = await fetch("/api/student/dashboard");
      const data = await res.json();
      if (res.ok && data.student) {
        setStudent(data.student);
        setStats(data.stats);
        setLessonsList(data.lessons || []);
        setContinueWatching(data.continueWatching || []);
        setPackagesList(data.packages || []);
        setQuizzesList(data.quizzes || []);
        setQuizAttempts(data.quizAttempts || []);
        setMistakesBank(data.mistakesBank || []);

        setProfileName(data.student.tripleName || "");
        setProfileGuardianPhone(data.student.guardianPhone || "");
        setProfileMotherPhone(data.student.motherPhone || "");
        setProfileEmail(data.student.email || "");
      }
    } catch {
      // ignore
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchDashboard();
  }, [fetchDashboard]);

  const handleCopyGiftCode = () => {
    navigator.clipboard.writeText(stats.bookGiftCode);
    setCopiedCode(true);
    showNotification(`تم نسخ كود هدية الكتاب: ${stats.bookGiftCode}`);
    setTimeout(() => setCopiedCode(false), 2000);
  };

  const handleTopupWallet = async () => {
    try {
      const res = await fetch("/api/payments/checkout", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          action: "topup",
          amount: 200,
          method: "vodafone_cash",
        }),
      });
      const data = await res.json();
      if (res.ok) {
        showNotification(data.message);
        fetchDashboard();
      }
    } catch {
      showNotification("تعذر شحن المحفظة");
    }
  };

  const handleQuizSubmit = async () => {
    if (!activeQuiz) return;
    setQuizSubmitting(true);
    try {
      const res = await fetch("/api/quizzes/submit", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          quizId: activeQuiz.id,
          answers: quizAnswers,
        }),
      });
      const data = await res.json();
      if (res.ok && data.attempt) {
        setQuizResult(data.attempt);
        showNotification(
          `تم تصحيح الاختبار تلقائياً! نتيجتك: ${data.attempt.percentage}%`
        );
        fetchDashboard();
      }
    } catch {
      showNotification("حدث خطأ أثناء تسليم الاختبار");
    } finally {
      setQuizSubmitting(false);
    }
  };

  const handleUpdateProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const res = await fetch("/api/profile", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          tripleName: profileName,
          guardianPhone: profileGuardianPhone,
          motherPhone: profileMotherPhone,
          email: profileEmail,
          newPassword: profileNewPassword,
        }),
      });
      const data = await res.json();
      if (!res.ok) {
        showNotification(data.error || "تعذر تحديث البيانات");
      } else {
        showNotification(data.message);
        setProfileNewPassword("");
        fetchDashboard();
      }
    } catch {
      showNotification("حدث خطأ في الاتصال");
    }
  };

  const handleSecureDeleteAccount = async () => {
    try {
      const res = await fetch("/api/profile", { method: "DELETE" });
      const data = await res.json();
      if (!res.ok) {
        showNotification(data.error || "لا يمكن حذف هذا الحساب");
      } else {
        showNotification(data.message);
        fetchDashboard();
      }
    } catch {
      showNotification("تعذر حذف الحساب");
    }
  };

  const filteredLectures = lessonsList.filter((l) => {
    if (lectureFilter === "all") return true;
    if (lectureFilter === "purchased") return l.isUnlocked;
    return l.type === lectureFilter;
  });

  const studentDisplayName = student?.tripleName || "يوسف طارق عبد الرحمن";
  const smartGreeting = getSmartTimeGreeting(studentDisplayName);

  const navItems = [
    {
      id: "dashboard",
      label: "الرئيسية وإحصائياتي",
      sub: "نظرة شاملة واستكمال المشاهدة",
      icon: LayoutDashboard,
    },
    {
      id: "lectures",
      label: "المحاضرات والدروس",
      sub: "أونلاين • السنتر • مجانية • مشتراة",
      icon: PlayCircle,
    },
    {
      id: "packages",
      label: "الباقات والاشتراكات",
      sub: "الشهر الأول • 3 شهور • الترم",
      icon: Package,
    },
    {
      id: "quizzes",
      label: "الامتحانات ونتائجي",
      sub: "اختبارات تفاعلية وتصحيح فوري",
      icon: FileCheck2,
    },
    {
      id: "materials",
      label: "الملازم، الواجب، وأخطائي",
      sub: "PDF • تسليم الواجب • قسم أخطائي",
      icon: BookOpenCheck,
      badge: mistakesBank.length > 0 ? `${mistakesBank.length}` : undefined,
    },
    {
      id: "store",
      label: "متجر الكتب والشحن",
      sub: "شراء كتاب • تتبع الشحن • مشترياتي",
      icon: ShoppingBag,
    },
    {
      id: "support_profile",
      label: "الدعم العلمي والملف الشخصي",
      sub: "اسأل المعلم • إعدادات الحساب",
      icon: UserCheck,
    },
  ];

  return (
    <div className="min-h-screen flex bg-[#F8FAFC] text-[#0F172A]">
      {/* Global Toast Notification */}
      {toast && (
        <div className="fixed top-5 left-1/2 -translate-x-1/2 z-50 bg-[#0F172A] text-white px-5 py-3 rounded-2xl shadow-2xl border border-[#F59E0B] flex items-center gap-2.5 text-xs sm:text-sm font-bold">
          <Sparkles className="w-4 h-4 text-[#F59E0B] shrink-0" />
          <span>{toast}</span>
        </div>
      )}

      {/* ============================================================
          COLLAPSIBLE RTL SIDEBAR
         ============================================================ */}
      <aside
        className={`fixed inset-y-0 right-0 z-40 bg-[#0F172A] text-white border-l border-slate-800 transition-all duration-300 flex flex-col justify-between ${
          sidebarCollapsed ? "w-20" : "w-72"
        } ${
          mobileMenuOpen
            ? "translate-x-0"
            : "translate-x-full lg:translate-x-0"
        }`}
      >
        <div>
          <div className="h-20 px-4 flex items-center justify-between border-b border-slate-800/80">
            <div className="flex items-center gap-3 overflow-hidden">
              <div className="w-11 h-11 rounded-2xl bg-gradient-to-br from-[#F59E0B] to-amber-600 text-[#0F172A] flex items-center justify-center font-heading font-extrabold text-xl shrink-0 shadow-lg shadow-amber-500/20">
                ب
              </div>
              {!sidebarCollapsed && (
                <div className="leading-tight">
                  <h1 className="font-heading font-bold text-base text-white whitespace-nowrap">
                    منصة البيان التعليمية
                  </h1>
                  <p className="text-[11px] text-amber-400 font-semibold whitespace-nowrap">
                    أ.د. محمود الشافعي • لغة عربية
                  </p>
                </div>
              )}
            </div>

            <button
              onClick={() => setSidebarCollapsed(!sidebarCollapsed)}
              title={sidebarCollapsed ? "توسيع القائمة" : "طي القائمة الجانبية"}
              className="hidden lg:flex w-8 h-8 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white items-center justify-center transition shrink-0"
            >
              {sidebarCollapsed ? (
                <ChevronLeft className="w-4 h-4" />
              ) : (
                <ChevronRight className="w-4 h-4" />
              )}
            </button>

            <button
              onClick={() => setMobileMenuOpen(false)}
              className="lg:hidden p-2 rounded-xl bg-slate-800 text-slate-300"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          <nav className="p-3 space-y-1.5">
            {navItems.map((item) => {
              const Icon = item.icon;
              const isActive = activeSection === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => {
                    setActiveSection(
                      item.id as
                        | "dashboard"
                        | "lectures"
                        | "packages"
                        | "quizzes"
                        | "materials"
                        | "store"
                        | "support_profile"
                    );
                    setMobileMenuOpen(false);
                  }}
                  title={item.label}
                  className={`w-full flex items-center gap-3 px-3.5 py-3 rounded-2xl text-right transition relative ${
                    isActive
                      ? "bg-[#F59E0B] text-[#0F172A] font-bold shadow-lg shadow-amber-500/20"
                      : "text-slate-300 hover:bg-slate-800/80 hover:text-white"
                  }`}
                >
                  <Icon
                    className={`w-5 h-5 shrink-0 ${
                      isActive ? "text-[#0F172A]" : "text-amber-400"
                    }`}
                  />
                  {!sidebarCollapsed && (
                    <div className="flex-1 overflow-hidden">
                      <div className="text-xs font-bold truncate">
                        {item.label}
                      </div>
                      <div
                        className={`text-[10px] truncate ${
                          isActive ? "text-slate-900/80" : "text-slate-400"
                        }`}
                      >
                        {item.sub}
                      </div>
                    </div>
                  )}
                  {!sidebarCollapsed && item.badge && (
                    <span
                      className={`px-2 py-0.5 rounded-full text-[10px] font-mono-num font-extrabold ${
                        isActive
                          ? "bg-[#0F172A] text-white"
                          : "bg-red-500 text-white"
                      }`}
                    >
                      {item.badge}
                    </span>
                  )}
                </button>
              );
            })}
          </nav>
        </div>

        {/* Bottom Student Mini Card & Admin Switcher */}
        <div className="p-3 border-t border-slate-800 space-y-2">
          {!sidebarCollapsed && student && (
            <div className="p-3 rounded-2xl bg-slate-900/90 border border-slate-800">
              <div className="text-xs font-bold text-white truncate">
                {student.tripleName}
              </div>
              <div
                dir="ltr"
                className="text-[11px] font-mono-num text-amber-400 mt-0.5 text-right"
              >
                {student.studentPhone}
              </div>
              <div className="text-[10px] text-slate-400 mt-0.5 truncate">
                {student.gradeLevel}
              </div>
            </div>
          )}

          <Link
            href="/admin/students"
            className="w-full flex items-center justify-center gap-2 px-3 py-2.5 rounded-xl bg-slate-800/90 hover:bg-slate-700 text-amber-300 border border-amber-500/30 text-xs font-bold transition"
            title="لوحة تحكم الأدمن (/admin/students)"
          >
            <ShieldAlert className="w-4 h-4 shrink-0" />
            {!sidebarCollapsed && <span>لوحة تحكم الأدمن السرية</span>}
          </Link>
        </div>
      </aside>

      {/* ============================================================
          MAIN CONTENT VIEWPORT
         ============================================================ */}
      <div
        className={`flex-1 flex flex-col min-w-0 transition-all duration-300 ${
          sidebarCollapsed ? "lg:mr-20" : "lg:mr-72"
        }`}
      >
        {/* Top Sticky Header with Smart Time-Aware Greeting */}
        <header className="sticky top-0 z-30 h-20 bg-white/90 backdrop-blur-md border-b border-slate-200 px-4 sm:px-8 flex items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <button
              onClick={() => setMobileMenuOpen(true)}
              className="lg:hidden p-2.5 rounded-xl bg-slate-100 text-slate-800"
            >
              <Menu className="w-5 h-5" />
            </button>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-[#F59E0B]">
                  {smartGreeting.isMorning ? (
                    <Sun className="w-4 h-4 inline" />
                  ) : (
                    <Moon className="w-4 h-4 inline text-amber-500" />
                  )}
                </span>
                <h2 className="font-heading text-sm sm:text-base font-bold text-[#0F172A]">
                  {smartGreeting.text}
                </h2>
              </div>
              <p className="text-xs text-slate-500 hidden sm:block">
                العام الدراسي 2025 / 2026 — منصة التعلم الذكي التفاعلية
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2.5">
            <button
              onClick={() => {
                setAuthInitialMode("register");
                setAuthModalOpen(true);
              }}
              className="px-3.5 py-2 rounded-xl bg-[#0F172A] hover:bg-slate-800 text-white text-xs font-bold flex items-center gap-1.5 transition shadow-sm"
            >
              <UserPlus className="w-4 h-4 text-[#F59E0B]" />
              <span className="hidden sm:inline">تسجيل طالب جديد</span>
            </button>

            <button
              onClick={() => {
                setAuthInitialMode("login");
                setAuthModalOpen(true);
              }}
              className="px-3 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-bold flex items-center gap-1.5 transition"
            >
              <LogOut className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">تبديل الحساب</span>
            </button>
          </div>
        </header>

        {/* Main Workspace Container */}
        <main className="p-4 sm:p-8 max-w-[1400px] w-full mx-auto space-y-8 pb-24">
          {/* ==========================================================
              SECTION 1: MAIN STUDENT DASHBOARD
             ========================================================== */}
          {activeSection === "dashboard" && (
            <>
              {/* Personalized Welcome Banner with Smart Time Greeting */}
              <div className="relative rounded-2xl bg-gradient-to-l from-[#0F172A] via-[#1E293B] to-[#0F172A] text-white p-6 sm:p-8 shadow-xl overflow-hidden border border-slate-800">
                <div className="relative z-10 flex flex-col lg:flex-row lg:items-center justify-between gap-6">
                  <div className="space-y-2 max-w-2xl">
                    <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#F59E0B]/20 border border-[#F59E0B]/40 text-amber-300 text-xs font-bold">
                      <Sparkles className="w-3.5 h-3.5" />
                      {smartGreeting.isMorning
                        ? "صباح الهمة والنشاط والتفوق الأكاديمي"
                        : "مساء التميز والمراجعة المستمرة"}
                    </div>
                    <h1 className="font-heading text-2xl sm:text-3xl font-extrabold text-white">
                      {smartGreeting.text} 👋
                    </h1>
                    <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
                      أنت مسجل في{" "}
                      <strong className="text-white">
                        {student?.gradeLevel || "الصف الثالث الثانوي"}
                      </strong>
                      . لقد أنجزت حتى الآن{" "}
                      <strong className="text-emerald-400 font-mono-num">
                        {stats.overallCompletionPercent}%
                      </strong>{" "}
                      من خطة المحاضرات الأسبوعية. واصل المشاهدة لتحصد الدرجة النهائية!
                    </p>
                  </div>

                  <div className="flex flex-wrap items-center gap-3 shrink-0">
                    {continueWatching.length > 0 && (
                      <button
                        onClick={() =>
                          setActiveVideoLessonId(continueWatching[0].id)
                        }
                        className="px-5 py-3 rounded-xl bg-[#F59E0B] hover:bg-amber-400 text-[#0F172A] font-heading font-bold text-xs sm:text-sm flex items-center gap-2 shadow-lg shadow-amber-500/25 transition"
                      >
                        <Play className="w-4 h-4 fill-current" />
                        استكمال آخر محاضرة ({continueWatching[0].progressPercent}
                        %)
                      </button>
                    )}
                    <button
                      onClick={() => setActiveSection("quizzes")}
                      className="px-4 py-3 rounded-xl bg-white/10 hover:bg-white/20 text-white border border-white/15 font-bold text-xs sm:text-sm transition"
                    >
                      دخول الامتحان الأسبوعي
                    </button>
                  </div>
                </div>
              </div>

              {/* Top 3 Stat Cards: Wallet Balance, Points, Book Gift Code */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="bg-white rounded-2xl border border-slate-200/90 p-6 shadow-sm flex items-center justify-between hover:-translate-y-0.5 transition">
                  <div className="space-y-1.5">
                    <span className="text-xs font-bold text-slate-500">
                      رصيد المحفظة الإلكترونية
                    </span>
                    <div className="font-mono-num text-3xl font-extrabold text-[#0F172A]">
                      {stats.walletBalance}{" "}
                      <span className="text-sm font-sans font-bold text-slate-500">
                        ج.م
                      </span>
                    </div>
                    <button
                      onClick={handleTopupWallet}
                      className="inline-flex items-center gap-1 text-xs font-bold text-emerald-700 hover:text-emerald-800 bg-emerald-50 px-2.5 py-1 rounded-lg border border-emerald-200 transition"
                    >
                      <Plus className="w-3.5 h-3.5" />
                      شحن فوري (+200 ج.م Paymob)
                    </button>
                  </div>
                  <div className="w-14 h-14 rounded-2xl bg-[#0F172A] text-[#F59E0B] flex items-center justify-center shadow-md shrink-0">
                    <Wallet className="w-7 h-7" />
                  </div>
                </div>

                <div className="bg-white rounded-2xl border border-slate-200/90 p-6 shadow-sm flex items-center justify-between hover:-translate-y-0.5 transition">
                  <div className="space-y-1.5">
                    <span className="text-xs font-bold text-slate-500">
                      النقاط التشجيعية ومستوى التميز
                    </span>
                    <div className="font-mono-num text-3xl font-extrabold text-[#0F172A]">
                      {stats.points}{" "}
                      <span className="text-sm font-sans font-bold text-amber-600">
                        نقطة
                      </span>
                    </div>
                    <span className="inline-flex items-center gap-1 text-xs font-bold text-amber-800 bg-amber-50 px-2.5 py-1 rounded-lg border border-amber-200">
                      <Award className="w-3.5 h-3.5 text-[#F59E0B]" />
                      الوسام الذهبي للمتفوقين
                    </span>
                  </div>
                  <div className="w-14 h-14 rounded-2xl bg-amber-50 text-[#F59E0B] border border-amber-200 flex items-center justify-center shrink-0">
                    <Award className="w-7 h-7" />
                  </div>
                </div>

                <div className="bg-white rounded-2xl border border-slate-200/90 p-6 shadow-sm flex items-center justify-between hover:-translate-y-0.5 transition">
                  <div className="space-y-1.5">
                    <span className="text-xs font-bold text-slate-500">
                      كود هدية الكتاب المطبوع
                    </span>
                    <div
                      dir="ltr"
                      className="font-mono-num text-xl font-extrabold text-[#0F172A] tracking-wider bg-slate-100 px-3 py-1 rounded-xl border border-slate-200 w-fit"
                    >
                      {stats.bookGiftCode}
                    </div>
                    <button
                      onClick={handleCopyGiftCode}
                      className="inline-flex items-center gap-1.5 text-xs font-bold text-[#0F172A] hover:text-amber-700 transition"
                    >
                      {copiedCode ? (
                        <>
                          <Check className="w-3.5 h-3.5 text-emerald-600" />
                          <span className="text-emerald-600">تم نسخ الكود!</span>
                        </>
                      ) : (
                        <>
                          <Copy className="w-3.5 h-3.5 text-[#F59E0B]" />
                          <span>انسخ الكود واستخدمه في المتجر</span>
                        </>
                      )}
                    </button>
                  </div>
                  <div className="w-14 h-14 rounded-2xl bg-emerald-50 text-emerald-600 border border-emerald-200 flex items-center justify-center shrink-0">
                    <Gift className="w-7 h-7" />
                  </div>
                </div>
              </div>

              {/* Continue Watching Section */}
              <div className="bg-white rounded-2xl border border-slate-200/90 p-6 shadow-sm space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="font-heading text-lg font-bold text-[#0F172A] flex items-center gap-2">
                      <PlayCircle className="w-5 h-5 text-[#F59E0B]" />
                      استكمال المشاهدة (من آخر ثانية توقفت عندها)
                    </h3>
                    <p className="text-xs text-slate-500">
                      يحفظ المشغل الذكي موضع توقفك تلقائياً في جدول progress
                    </p>
                  </div>
                  <button
                    onClick={() => setActiveSection("lectures")}
                    className="text-xs font-bold text-[#0F172A] hover:text-[#F59E0B] transition"
                  >
                    عرض كل المحاضرات ←
                  </button>
                </div>

                {continueWatching.length === 0 ? (
                  <div className="p-6 rounded-xl bg-slate-50 text-center text-xs text-slate-500">
                    أكملت جميع المحاضرات المفتوحة حالياً! ابدأ محاضرة جديدة من قسم
                    المحاضرات.
                  </div>
                ) : (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {continueWatching.map((lesson) => (
                      <div
                        key={lesson.id}
                        className="p-4 rounded-2xl bg-slate-50/80 border border-slate-200 hover:border-[#0F172A]/40 transition flex flex-col justify-between gap-4"
                      >
                        <div className="flex items-start justify-between gap-3">
                          <div>
                            <span className="text-[11px] font-bold text-amber-700 bg-amber-100 px-2.5 py-0.5 rounded-full">
                              {lesson.courseTitle}
                            </span>
                            <h4 className="font-heading font-bold text-sm sm:text-base text-slate-900 mt-1.5">
                              {lesson.title}
                            </h4>
                          </div>
                          <button
                            onClick={() => setActiveVideoLessonId(lesson.id)}
                            className="w-11 h-11 rounded-xl bg-[#0F172A] hover:bg-[#F59E0B] text-white hover:text-[#0F172A] flex items-center justify-center shrink-0 shadow transition"
                            title="استئناف المشاهدة فوراً"
                          >
                            <Play className="w-5 h-5 fill-current ml-0.5" />
                          </button>
                        </div>

                        <div className="space-y-1.5">
                          <div className="flex items-center justify-between text-xs font-mono-num text-slate-600">
                            <span>
                              تمت مشاهدة {formatSeconds(lesson.watchedSeconds)}{" "}
                              من {formatSeconds(lesson.durationSeconds)}
                            </span>
                            <span className="font-bold text-[#0F172A]">
                              {lesson.progressPercent}%
                            </span>
                          </div>
                          <div className="w-full h-2.5 rounded-full bg-slate-200 overflow-hidden">
                            <div
                              className="h-full bg-gradient-to-l from-[#0F172A] to-[#F59E0B] rounded-full transition-all duration-500"
                              style={{ width: `${lesson.progressPercent}%` }}
                            />
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {/* Analytics Row: Pie Chart & Bar Chart */}
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <LectureCompletionPieChart
                  completed={stats.completedLessonsCount}
                  inProgress={stats.inProgressLessonsCount}
                  notStarted={stats.notStartedLessonsCount}
                  overallPercent={stats.overallCompletionPercent}
                />
                <ExamScoresBarChart attempts={quizAttempts} />
              </div>

              {/* Packages Showcase */}
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="font-heading text-xl font-bold text-[#0F172A]">
                      الباقات الدراسية المتاحة (الدفع عبر InstaPay أو فودافون كاش أو فيزا)
                    </h3>
                    <p className="text-xs text-slate-500">
                      اضغط على «استعراض محتويات الباقة وحالة الدروس» لمعاينة كل
                      درس داخل الباقة قبل الاشتراك
                    </p>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  {packagesList.map((pkg, idx) => (
                    <div
                      key={pkg.id}
                      className={`rounded-2xl p-6 flex flex-col justify-between transition hover:-translate-y-1 ${
                        idx === 1
                          ? "bg-[#0F172A] text-white border-2 border-[#F59E0B] shadow-xl"
                          : "bg-white text-slate-900 border border-slate-200 shadow-sm"
                      }`}
                    >
                      <div className="space-y-4">
                        <div className="flex items-center justify-between">
                          <span
                            className={`px-3 py-1 rounded-full text-xs font-bold ${
                              idx === 1
                                ? "bg-[#F59E0B] text-[#0F172A]"
                                : pkg.isSubscribed
                                ? "bg-emerald-100 text-emerald-800"
                                : "bg-slate-100 text-slate-800"
                            }`}
                          >
                            {pkg.isSubscribed ? "مشترك بها ✓" : pkg.badge}
                          </span>
                          <span
                            className={`text-xs font-semibold ${
                              idx === 1 ? "text-slate-300" : "text-slate-500"
                            }`}
                          >
                            {pkg.durationLabel}
                          </span>
                        </div>

                        <div>
                          <h4 className="font-heading text-lg font-bold">
                            {pkg.title}
                          </h4>
                          <p
                            className={`text-xs mt-1 leading-relaxed ${
                              idx === 1 ? "text-slate-300" : "text-slate-500"
                            }`}
                          >
                            {pkg.subtitle}
                          </p>
                        </div>

                        <div className="flex items-baseline gap-2 pt-1">
                          <span className="font-mono-num text-3xl font-extrabold">
                            {pkg.price}
                          </span>
                          <span className="text-xs font-bold">ج.م</span>
                          <span
                            className={`text-xs line-through font-mono-num mr-2 ${
                              idx === 1 ? "text-slate-400" : "text-slate-400"
                            }`}
                          >
                            {pkg.originalPrice} ج.م
                          </span>
                        </div>

                        <ul className="space-y-2 text-xs pt-2 border-t border-slate-200/20">
                          {pkg.features.map((feat, fIdx) => (
                            <li key={fIdx} className="flex items-start gap-2">
                              <CheckCircle2
                                className={`w-4 h-4 shrink-0 mt-0.5 ${
                                  idx === 1
                                    ? "text-[#F59E0B]"
                                    : "text-emerald-600"
                                }`}
                              />
                              <span>{feat}</span>
                            </li>
                          ))}
                        </ul>
                      </div>

                      <div className="pt-6 mt-6 border-t border-slate-200/20 space-y-2.5">
                        <button
                          onClick={() => setInspectingPackage(pkg)}
                          className={`w-full py-2.5 rounded-xl text-xs font-bold border transition ${
                            idx === 1
                              ? "border-slate-700 bg-slate-800/90 hover:bg-slate-800 text-amber-300"
                              : "border-slate-200 bg-slate-50 hover:bg-slate-100 text-slate-800"
                          }`}
                        >
                          استعراض محتويات الباقة وحالة الدروس (Modal)
                        </button>

                        {pkg.isSubscribed ? (
                          <button
                            onClick={() => setActiveSection("lectures")}
                            className="w-full py-3 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-heading font-bold text-xs transition"
                          >
                            الذهاب لمحاضرات الباقة المفتوحة
                          </button>
                        ) : (
                          <button
                            onClick={() =>
                              setCheckoutItem({
                                packageId: pkg.id,
                                title: pkg.title,
                                price: pkg.price,
                                subtitle: pkg.subtitle,
                              })
                            }
                            className={`w-full py-3 rounded-xl font-heading font-bold text-xs transition shadow-md ${
                              idx === 1
                                ? "bg-[#F59E0B] hover:bg-amber-400 text-[#0F172A]"
                                : "bg-[#0F172A] hover:bg-slate-800 text-white"
                            }`}
                          >
                            اشترك الآن في الباقة ({pkg.price} ج.م)
                          </button>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </>
          )}

          {/* ==========================================================
              SECTION 2: LECTURES (PAYWALL ENFORCEMENT & LESSONS)
             ========================================================== */}
          {activeSection === "lectures" && (
            <div className="space-y-6">
              <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-sm flex flex-wrap items-center justify-between gap-4">
                <div className="flex flex-wrap items-center gap-2">
                  {[
                    { id: "all", label: "جميع المحاضرات" },
                    { id: "online", label: "محاضرات أونلاين" },
                    { id: "center", label: "محاضرات السنتر" },
                    { id: "free", label: "محاضرات مجانية" },
                    { id: "purchased", label: "محاضرات تم شراؤها" },
                  ].map((tab) => (
                    <button
                      key={tab.id}
                      onClick={() =>
                        setLectureFilter(
                          tab.id as
                            | "all"
                            | "online"
                            | "center"
                            | "free"
                            | "purchased"
                        )
                      }
                      className={`px-4 py-2 rounded-xl text-xs font-bold transition ${
                        lectureFilter === tab.id
                          ? "bg-[#0F172A] text-[#F59E0B] shadow"
                          : "bg-slate-100 text-slate-600 hover:bg-slate-200"
                      }`}
                    >
                      {tab.label}
                    </button>
                  ))}
                </div>
                <span className="text-xs font-bold text-slate-500">
                  عدد المحاضرات المعروضة: {filteredLectures.length}
                </span>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {filteredLectures.map((lesson) => (
                  <div
                    key={lesson.id}
                    className="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-sm hover:shadow-md transition flex flex-col justify-between"
                  >
                    <div>
                      <div className="bg-gradient-to-br from-[#0F172A] to-slate-800 p-5 text-white relative">
                        <div className="flex items-center justify-between mb-3">
                          <span
                            className={`px-2.5 py-0.5 rounded-full text-[11px] font-bold ${
                              lesson.type === "free"
                                ? "bg-emerald-500 text-white"
                                : lesson.type === "center"
                                ? "bg-amber-500 text-slate-950"
                                : "bg-white/15 text-amber-300"
                            }`}
                          >
                            {lesson.type === "free"
                              ? "محاضرة مجانية"
                              : lesson.type === "center"
                              ? "تسجيل السنتر"
                              : "محاضرة أونلاين"}
                          </span>

                          <span className="font-mono-num text-xs text-slate-300 flex items-center gap-1">
                            <Clock className="w-3.5 h-3.5 text-[#F59E0B]" />
                            {Math.round(lesson.durationSeconds / 60)} دقيقة
                          </span>
                        </div>

                        <h4 className="font-heading font-bold text-base leading-snug line-clamp-2">
                          {lesson.title}
                        </h4>
                        <div className="flex items-center justify-between mt-1 text-[11px] text-slate-300">
                          <span className="truncate">{lesson.courseTitle}</span>
                          {lesson.instructorName && (
                            <span className="text-amber-300 shrink-0">
                              {lesson.instructorName}
                            </span>
                          )}
                        </div>
                      </div>

                      <div className="p-5 space-y-3">
                        <p className="text-xs text-slate-600 line-clamp-2 leading-relaxed">
                          {lesson.description}
                        </p>

                        <div className="space-y-1 pt-1">
                          <div className="flex items-center justify-between text-[11px] font-bold">
                            <span
                              className={
                                lesson.completed
                                  ? "text-emerald-600"
                                  : "text-slate-600"
                              }
                            >
                              {lesson.completed
                                ? "مكتملة بالكامل ✓"
                                : lesson.watchedSeconds > 0
                                ? `قيد المشاهدة (${formatSeconds(
                                    lesson.watchedSeconds
                                  )})`
                                : lesson.isUnlocked
                                ? "مفتوحة — لم تبدأ بعد"
                                : "مغلقة (Paywall)"}
                            </span>
                            <span className="font-mono-num">
                              {lesson.progressPercent}%
                            </span>
                          </div>
                          <div className="w-full h-2 rounded-full bg-slate-100 overflow-hidden">
                            <div
                              className={`h-full rounded-full ${
                                lesson.completed
                                  ? "bg-emerald-500"
                                  : "bg-[#F59E0B]"
                              }`}
                              style={{ width: `${lesson.progressPercent}%` }}
                            />
                          </div>
                        </div>
                      </div>
                    </div>

                    <div className="px-5 pb-5 pt-2">
                      {lesson.isUnlocked ? (
                        <button
                          onClick={() => setActiveVideoLessonId(lesson.id)}
                          className="w-full py-3 rounded-xl bg-[#0F172A] hover:bg-slate-800 text-white font-heading font-bold text-xs flex items-center justify-center gap-2 transition shadow"
                        >
                          <Play className="w-4 h-4 text-[#F59E0B] fill-[#F59E0B]" />
                          <span>
                            {lesson.watchedSeconds > 0 && !lesson.completed
                              ? `استكمال المشاهدة (${formatSeconds(
                                  lesson.watchedSeconds
                                )})`
                              : "تشغيل المحاضرة المحمية الآن"}
                          </span>
                        </button>
                      ) : (
                        <button
                          onClick={() =>
                            setCheckoutItem({
                              courseId: lesson.courseId,
                              title: lesson.courseTitle,
                              price: lesson.coursePrice || 250,
                              subtitle: `المحاضرة: ${lesson.title}`,
                            })
                          }
                          className="w-full py-3 rounded-xl bg-amber-500 hover:bg-amber-400 text-[#0F172A] font-heading font-bold text-xs flex items-center justify-center gap-2 transition shadow-md"
                        >
                          <Lock className="w-4 h-4" />
                          <span>شراء الكورس / اشترك الآن ({lesson.coursePrice || 250} ج.م)</span>
                        </button>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* ==========================================================
              SECTION 3: PACKAGES & SUBSCRIPTIONS
             ========================================================== */}
          {activeSection === "packages" && (
            <div className="space-y-6">
              <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm flex flex-wrap items-center justify-between gap-4">
                <div>
                  <h3 className="font-heading text-xl font-bold text-[#0F172A]">
                    الباقات الشهرية والموسمية — وفر أكثر وتابع دروسك بانتظام
                  </h3>
                  <p className="text-xs text-slate-500 mt-1">
                    طرق دفع متعددة: تحويل مباشر عبر InstaPay ومحفظة فودافون كاش أو الدفع الإلكتروني الفوري.
                  </p>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                {packagesList.map((pkg, idx) => (
                  <div
                    key={pkg.id}
                    className={`rounded-2xl p-6 flex flex-col justify-between ${
                      idx === 1
                        ? "bg-[#0F172A] text-white border-2 border-[#F59E0B] shadow-xl"
                        : "bg-white text-slate-900 border border-slate-200 shadow-sm"
                    }`}
                  >
                    <div className="space-y-4">
                      <div className="flex items-center justify-between">
                        <span className="px-3 py-1 rounded-full text-xs font-bold bg-[#F59E0B] text-[#0F172A]">
                          {pkg.badge}
                        </span>
                        <span className="text-xs opacity-75">
                          {pkg.durationLabel}
                        </span>
                      </div>
                      <h4 className="font-heading text-lg font-bold">
                        {pkg.title}
                      </h4>
                      <p className="text-xs opacity-80 leading-relaxed">
                        {pkg.description}
                      </p>
                      <div className="font-mono-num text-3xl font-extrabold">
                        {pkg.price} ج.م{" "}
                        <span className="text-xs line-through opacity-60">
                          {pkg.originalPrice} ج.م
                        </span>
                      </div>
                    </div>

                    <div className="pt-6 mt-6 border-t border-slate-200/20 space-y-2.5">
                      <button
                        onClick={() => setInspectingPackage(pkg)}
                        className="w-full py-2.5 rounded-xl bg-white/10 hover:bg-white/20 border border-slate-300/30 text-xs font-bold transition"
                      >
                        معاينة جدول الدروس داخل الباقة ({pkg.items.length} عناصر)
                      </button>
                      <button
                        onClick={() =>
                          setCheckoutItem({
                            packageId: pkg.id,
                            title: pkg.title,
                            price: pkg.price,
                            subtitle: pkg.subtitle,
                          })
                        }
                        className="w-full py-3 rounded-xl bg-[#F59E0B] hover:bg-amber-400 text-[#0F172A] font-heading font-bold text-xs transition"
                      >
                        {pkg.isSubscribed
                          ? "تم الاشتراك بالفعل — تجديد الباقة"
                          : `اشترك الآن (${pkg.price} ج.م)`}
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* ==========================================================
              SECTION 4: QUIZZES & RESULTS
             ========================================================== */}
          {activeSection === "quizzes" && (
            <div className="space-y-6">
              {activeQuiz ? (
                <div className="bg-white rounded-2xl border border-slate-200 p-6 sm:p-8 shadow-lg space-y-6">
                  <div className="flex flex-wrap items-center justify-between gap-4 pb-4 border-b border-slate-200">
                    <div>
                      <span className="text-xs font-bold text-[#F59E0B]">
                        نظام الاختبارات الإلكتروني
                      </span>
                      <h3 className="font-heading text-xl font-bold text-[#0F172A]">
                        {activeQuiz.title}
                      </h3>
                      <p className="text-xs text-slate-500">
                        درجة النجاح المطلوبة: {activeQuiz.passingScore}% • المدة:{" "}
                        {activeQuiz.durationMinutes} دقيقة
                      </p>
                    </div>
                    <button
                      onClick={() => {
                        setActiveQuiz(null);
                        setQuizResult(null);
                      }}
                      className="px-4 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-xs font-bold text-slate-700"
                    >
                      العودة لقائمة الامتحانات
                    </button>
                  </div>

                  {quizResult ? (
                    <div className="space-y-6">
                      <div
                        className={`p-6 rounded-2xl border text-center space-y-2 ${
                          quizResult.passed
                            ? "bg-emerald-50 border-emerald-200 text-emerald-950"
                            : "bg-red-50 border-red-200 text-red-950"
                        }`}
                      >
                        <div className="font-mono-num text-4xl font-extrabold">
                          {quizResult.percentage}% ({quizResult.score} /{" "}
                          {quizResult.totalMarks})
                        </div>
                        <h4 className="font-heading text-lg font-bold">
                          {quizResult.passed
                            ? "أحسنت يا بطل! لقد اجتزت الاختبار بنجاح وحصلت على +100 نقطة 🎉"
                            : "حاول مرة أخرى! تم حفظ أخطائك تلقائياً في (قسم أخطائي) لمراجعتها."}
                        </h4>
                      </div>

                      <div className="space-y-4">
                        <h4 className="font-heading font-bold text-base text-[#0F172A]">
                          التصحيح التفصيلي والتفسير العلمي لكل سؤال:
                        </h4>
                        {quizResult.breakdown.map((item, idx) => (
                          <div
                            key={item.questionId}
                            className={`p-4 rounded-2xl border space-y-2 text-xs ${
                              item.isCorrect
                                ? "bg-emerald-50/40 border-emerald-200"
                                : "bg-red-50/40 border-red-200"
                            }`}
                          >
                            <div className="font-bold text-sm text-slate-900">
                              س{idx + 1}: {item.questionText}
                            </div>
                            <div className="flex flex-wrap gap-4">
                              <span>
                                إجابتك:{" "}
                                <strong
                                  className={
                                    item.isCorrect
                                      ? "text-emerald-700"
                                      : "text-red-600"
                                  }
                                >
                                  {item.selectedAnswer}
                                </strong>
                              </span>
                              {!item.isCorrect && (
                                <span>
                                  الإجابة الصحيحة:{" "}
                                  <strong className="text-emerald-700">
                                    {item.correctAnswer}
                                  </strong>
                                </span>
                              )}
                            </div>
                            <div className="p-2.5 rounded-xl bg-white border border-slate-200 text-slate-700">
                              <strong>التفسير النحوي/البلاغي:</strong>{" "}
                              {item.explanation}
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  ) : (
                    <div className="space-y-6">
                      {activeQuiz.questions.map((q, qIdx) => (
                        <div
                          key={q.id}
                          className="p-5 rounded-2xl bg-slate-50 border border-slate-200 space-y-3"
                        >
                          <div className="flex items-center justify-between">
                            <span className="font-heading font-bold text-sm sm:text-base text-slate-900">
                              السؤال {qIdx + 1}: {q.questionText}
                            </span>
                            <span className="px-2.5 py-0.5 rounded-full bg-amber-100 text-amber-900 font-mono-num text-xs font-bold shrink-0">
                              {q.points} درجات
                            </span>
                          </div>
                          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                            {q.answers.map((ans) => {
                              const selected =
                                quizAnswers[String(q.id)] === ans.id;
                              return (
                                <button
                                  key={ans.id}
                                  type="button"
                                  onClick={() =>
                                    setQuizAnswers({
                                      ...quizAnswers,
                                      [String(q.id)]: ans.id,
                                    })
                                  }
                                  className={`p-3.5 rounded-xl border text-right text-xs font-bold transition ${
                                    selected
                                      ? "bg-[#0F172A] text-white border-[#0F172A] shadow"
                                      : "bg-white text-slate-800 border-slate-200 hover:border-slate-400"
                                  }`}
                                >
                                  {ans.answerText}
                                </button>
                              );
                            })}
                          </div>
                        </div>
                      ))}

                      <button
                        disabled={quizSubmitting}
                        onClick={handleQuizSubmit}
                        className="w-full py-3.5 rounded-xl bg-[#F59E0B] hover:bg-amber-400 text-[#0F172A] font-heading font-bold text-sm shadow-lg transition"
                      >
                        {quizSubmitting
                          ? "جاري التصحيح التلقائي وحفظ النتيجة..."
                          : "تسليم إجابات الاختبار وعرض النتيجة فوراً"}
                      </button>
                    </div>
                  )}
                </div>
              ) : (
                <>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    {quizzesList.map((qz) => (
                      <div
                        key={qz.id}
                        className="bg-white rounded-2xl border border-slate-200 p-6 shadow-sm flex flex-col justify-between space-y-4"
                      >
                        <div className="space-y-2">
                          <div className="flex items-center justify-between">
                            <span className="px-3 py-1 rounded-full text-xs font-bold bg-amber-100 text-amber-900">
                              درجة النجاح: {qz.passingScore}%
                            </span>
                            <span className="font-mono-num text-xs text-slate-500">
                              {qz.durationMinutes} دقيقة • {qz.questionsCount}{" "}
                              أسئلة
                            </span>
                          </div>
                          <h4 className="font-heading text-lg font-bold text-[#0F172A]">
                            {qz.title}
                          </h4>
                          <p className="text-xs text-slate-600 leading-relaxed">
                            {qz.description}
                          </p>
                        </div>

                        <div className="pt-4 border-t border-slate-100 flex items-center justify-between">
                          {qz.bestAttempt ? (
                            <span className="text-xs font-bold text-emerald-700">
                              أعلى نتيجة لك: {qz.bestAttempt.percentage}% (
                              {qz.bestAttempt.score}/{qz.bestAttempt.totalMarks})
                            </span>
                          ) : (
                            <span className="text-xs text-slate-400">
                              لم تمتحن بعد
                            </span>
                          )}
                          <button
                            onClick={() => {
                              setActiveQuiz(qz);
                              setQuizAnswers({});
                              setQuizResult(null);
                            }}
                            className="px-5 py-2.5 rounded-xl bg-[#0F172A] hover:bg-slate-800 text-white text-xs font-bold transition"
                          >
                            {qz.bestAttempt
                              ? "إعادة الاختبار"
                              : "ابدأ الاختبار الآن"}
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>

                  <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-sm space-y-4">
                    <h3 className="font-heading text-lg font-bold text-[#0F172A]">
                      سجل نتائج الامتحانات السابقة
                    </h3>
                    <div className="overflow-x-auto">
                      <table className="w-full text-right text-xs border-collapse">
                        <thead>
                          <tr className="bg-slate-100 text-slate-700">
                            <th className="p-3">اسم الامتحان</th>
                            <th className="p-3">الدرجة</th>
                            <th className="p-3">النسبة المئوية</th>
                            <th className="p-3">الحالة</th>
                            <th className="p-3">التاريخ</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-200">
                          {quizAttempts.map((att) => (
                            <tr key={att.id}>
                              <td className="p-3 font-bold text-slate-900">
                                {att.quizTitle}
                              </td>
                              <td className="p-3 font-mono-num font-bold">
                                {att.score} / {att.totalMarks}
                              </td>
                              <td className="p-3 font-mono-num font-extrabold text-[#0F172A]">
                                {att.percentage}%
                              </td>
                              <td className="p-3">
                                {att.passed ? (
                                  <span className="px-2.5 py-0.5 rounded-full bg-emerald-50 text-emerald-700 border border-emerald-200 font-bold">
                                    ناجح بتفوق ✓
                                  </span>
                                ) : (
                                  <span className="px-2.5 py-0.5 rounded-full bg-red-50 text-red-700 border border-red-200 font-bold">
                                    يحتاج مراجعة
                                  </span>
                                )}
                              </td>
                              <td className="p-3 font-mono-num text-slate-500">
                                {new Date(att.completedAt).toLocaleDateString(
                                  "ar-EG"
                                )}
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </div>
                </>
              )}
            </div>
          )}

          {/* ==========================================================
              SECTION 5: PDFS, HOMEWORK & MISTAKES BANK
             ========================================================== */}
          {activeSection === "materials" && (
            <div className="space-y-6">
              <div className="bg-white p-3 rounded-2xl border border-slate-200 shadow-sm flex flex-wrap gap-2">
                {[
                  {
                    id: "pdfs",
                    label: "الملازم وملفات الـ PDF",
                    icon: FileText,
                  },
                  {
                    id: "homework",
                    label: "تسليم الواجب الأسبوعي",
                    icon: UploadCloud,
                  },
                  {
                    id: "mistakes",
                    label: `قسم أخطائي (${mistakesBank.length})`,
                    icon: AlertTriangle,
                  },
                ].map((t) => {
                  const Icon = t.icon;
                  return (
                    <button
                      key={t.id}
                      onClick={() =>
                        setMaterialsTab(
                          t.id as "pdfs" | "homework" | "mistakes"
                        )
                      }
                      className={`px-4 py-2.5 rounded-xl text-xs font-bold flex items-center gap-2 transition ${
                        materialsTab === t.id
                          ? "bg-[#0F172A] text-[#F59E0B] shadow"
                          : "bg-slate-100 text-slate-700 hover:bg-slate-200"
                      }`}
                    >
                      <Icon className="w-4 h-4" />
                      <span>{t.label}</span>
                    </button>
                  );
                })}
              </div>

              {materialsTab === "pdfs" && (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {lessonsList.map((les) => (
                    <div
                      key={les.id}
                      className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm flex items-center justify-between gap-4"
                    >
                      <div className="flex items-center gap-3.5">
                        <div className="w-12 h-12 rounded-2xl bg-red-50 text-red-600 border border-red-200 flex items-center justify-center shrink-0">
                          <FileText className="w-6 h-6" />
                        </div>
                        <div>
                          <h4 className="font-heading font-bold text-sm text-slate-900">
                            {les.pdfTitle || `ملزمة ${les.title}`}
                          </h4>
                          <p className="text-xs text-slate-500 mt-0.5">
                            تابعة لـ: {les.title}
                          </p>
                        </div>
                      </div>
                      <button
                        onClick={() =>
                          showNotification(
                            `جاري فتح وتحميل: ${les.pdfTitle || les.title}`
                          )
                        }
                        className="px-4 py-2 rounded-xl bg-[#0F172A] hover:bg-slate-800 text-white text-xs font-bold shrink-0 transition"
                      >
                        تحميل PDF
                      </button>
                    </div>
                  ))}
                </div>
              )}

              {materialsTab === "homework" && (
                <div className="space-y-4">
                  {lessonsList.map((les) => {
                    const isDone = submittedHomeworks.includes(les.id);
                    return (
                      <div
                        key={les.id}
                        className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm flex flex-wrap items-center justify-between gap-4"
                      >
                        <div>
                          <span className="text-[11px] font-bold text-amber-700">
                            {les.courseTitle}
                          </span>
                          <h4 className="font-heading font-bold text-base text-slate-900">
                            {les.homeworkTitle || `واجب ${les.title}`}
                          </h4>
                          <p className="text-xs text-slate-500">
                            ارفع إجاباتك أو اكتب ملخص الحل ليتم مراجعته من
                            المساعدين
                          </p>
                        </div>

                        {isDone ? (
                          <span className="px-4 py-2 rounded-xl bg-emerald-50 text-emerald-700 border border-emerald-200 text-xs font-bold flex items-center gap-1.5">
                            <CheckCircle2 className="w-4 h-4" />
                            تم تسليم الواجب ومراجعته (+25 نقطة)
                          </span>
                        ) : (
                          <div className="flex items-center gap-2 w-full sm:w-auto">
                            <input
                              type="text"
                              value={homeworkAnswerNote}
                              onChange={(e) =>
                                setHomeworkAnswerNote(e.target.value)
                              }
                              placeholder="رابط الحل أو ملاحظة الواجب..."
                              className="px-3 py-2 rounded-xl border border-slate-300 text-xs flex-1"
                            />
                            <button
                              onClick={() => {
                                setSubmittedHomeworks([
                                  ...submittedHomeworks,
                                  les.id,
                                ]);
                                setHomeworkAnswerNote("");
                                showNotification(
                                  `تم تسليم "${
                                    les.homeworkTitle || les.title
                                  }" بنجاح!`
                                );
                              }}
                              className="px-4 py-2 rounded-xl bg-[#F59E0B] text-[#0F172A] text-xs font-bold shrink-0"
                            >
                              تسليم الواجب
                            </button>
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              )}

              {materialsTab === "mistakes" && (
                <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-sm space-y-4">
                  <div>
                    <h3 className="font-heading text-lg font-bold text-[#0F172A] flex items-center gap-2">
                      <AlertTriangle className="w-5 h-5 text-amber-500" />
                      بنك «قسم أخطائي» الذكي — تعلم من أخطائك السابقة
                    </h3>
                    <p className="text-xs text-slate-500">
                      يجمع النظام تلقائياً كل سؤال أخطأت فيه في الامتحانات
                      السابقة مع التفسير النموذجي لضمان عدم تكرار الخطأ في امتحان
                      آخر العام.
                    </p>
                  </div>

                  {mistakesBank.length === 0 ? (
                    <div className="p-8 text-center text-xs text-slate-500">
                      لا توجد أخطاء مسجلة حتى الآن! سجل ناصع بالعلامة الكاملة.
                    </div>
                  ) : (
                    <div className="space-y-4">
                      {mistakesBank.map((m, idx) => (
                        <div
                          key={`${m.attemptId}-${m.questionId}-${idx}`}
                          className="p-5 rounded-2xl bg-amber-50/40 border border-amber-200 space-y-2.5"
                        >
                          <div className="flex items-center justify-between text-xs">
                            <span className="px-2.5 py-0.5 rounded-md bg-[#0F172A] text-[#F59E0B] font-bold">
                              {m.quizTitle}
                            </span>
                            <span className="text-red-600 font-bold">
                              سؤال يحتاج مراجعة
                            </span>
                          </div>
                          <h4 className="font-heading font-bold text-sm sm:text-base text-slate-900">
                            {m.questionText}
                          </h4>
                          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
                            <div className="p-2.5 rounded-xl bg-red-50 border border-red-200 text-red-800">
                              <strong>إجابتك الخاطئة:</strong>{" "}
                              {m.selectedAnswer}
                            </div>
                            <div className="p-2.5 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-800">
                              <strong>الإجابة الصحيحة:</strong>{" "}
                              {m.correctAnswer}
                            </div>
                          </div>
                          <div className="p-3 rounded-xl bg-white border border-slate-200 text-xs text-slate-700">
                            <strong className="text-[#0F172A]">
                              شرح القاعدة والتفسير:
                            </strong>{" "}
                            {m.explanation}
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              )}
            </div>
          )}

          {/* ==========================================================
              SECTION 6: BOOK STORE
             ========================================================== */}
          {activeSection === "store" && (
            <div className="space-y-6">
              <div className="bg-white p-3 rounded-2xl border border-slate-200 shadow-sm flex flex-wrap gap-2">
                {[
                  { id: "buy", label: "شراء الكتب والمراجعات المطبوعة" },
                  { id: "tracking", label: "تتبع حالة الشحن للمنزل" },
                  {
                    id: "purchased",
                    label: `الكتب المشتراة (${purchasedBooks.length})`,
                  },
                ].map((t) => (
                  <button
                    key={t.id}
                    onClick={() =>
                      setStoreTab(t.id as "buy" | "tracking" | "purchased")
                    }
                    className={`px-4 py-2.5 rounded-xl text-xs font-bold transition ${
                      storeTab === t.id
                        ? "bg-[#0F172A] text-[#F59E0B] shadow"
                        : "bg-slate-100 text-slate-700 hover:bg-slate-200"
                    }`}
                  >
                    {t.label}
                  </button>
                ))}
              </div>

              {storeTab === "buy" && (
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  {[
                    {
                      id: 201,
                      title:
                        "كتاب البيان الشامل في النحو والبلاغة (طبعة الألوان الفاخرة)",
                      price: 185,
                      pages: "420 صفحة",
                      desc: "يشمل شرح جميع وحدات النحو والبلاغة مع 2500 سؤال متدرج وإجاباتها النموذجية.",
                    },
                    {
                      id: 202,
                      title:
                        "مجلد القراءة والنصوص المتحررة وقصة الأيام لطه حسين",
                      price: 160,
                      pages: "340 صفحة",
                      desc: "تدريبات عملية على أحدث قطع القراءة المتحررة والربط الأدبي والشعري.",
                    },
                    {
                      id: 203,
                      title: "بوكليت امتحانات الثانوية العامة (25 نموذج شامل)",
                      price: 140,
                      pages: "280 صفحة",
                      desc: "نماذج امتحانات مطابقة لمواصفات الورقة الامتحانية مع بابل شيت للتدريب.",
                    },
                  ].map((book) => (
                    <div
                      key={book.id}
                      className="bg-white rounded-2xl border border-slate-200 p-6 shadow-sm flex flex-col justify-between space-y-4"
                    >
                      <div className="space-y-2">
                        <span className="px-2.5 py-0.5 rounded-full bg-amber-100 text-amber-900 text-xs font-bold">
                          {book.pages} • شحن لجميع المحافظات
                        </span>
                        <h4 className="font-heading font-bold text-base text-[#0F172A]">
                          {book.title}
                        </h4>
                        <p className="text-xs text-slate-600 leading-relaxed">
                          {book.desc}
                        </p>
                      </div>
                      <div className="pt-4 border-t border-slate-100 flex items-center justify-between">
                        <span className="font-mono-num text-2xl font-extrabold text-[#0F172A]">
                          {book.price} ج.م
                        </span>
                        <button
                          onClick={() => {
                            setPurchasedBooks([
                              ...purchasedBooks,
                              {
                                id: book.id,
                                title: book.title,
                                price: book.price,
                                trackingCode: `SHP-EG-${Math.floor(
                                  100000 + Math.random() * 900000
                                )}`,
                                step: 2,
                                orderDate: new Date()
                                  .toISOString()
                                  .slice(0, 10),
                              },
                            ]);
                            showNotification(
                              `تم طلب "${book.title}" بنجاح! يمكنك تتبع الشحنة الآن.`
                            );
                            setStoreTab("tracking");
                          }}
                          className="px-4 py-2.5 rounded-xl bg-[#0F172A] hover:bg-slate-800 text-white text-xs font-bold transition"
                        >
                          اطلب الكتاب الآن
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}

              {(storeTab === "tracking" || storeTab === "purchased") && (
                <div className="space-y-4">
                  {purchasedBooks.map((pb) => (
                    <div
                      key={pb.trackingCode}
                      className="bg-white rounded-2xl border border-slate-200 p-6 shadow-sm space-y-5"
                    >
                      <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-100 pb-4">
                        <div className="flex items-center gap-3">
                          <div className="w-11 h-11 rounded-xl bg-amber-50 text-[#F59E0B] border border-amber-200 flex items-center justify-center">
                            <Truck className="w-6 h-6" />
                          </div>
                          <div>
                            <h4 className="font-heading font-bold text-base text-slate-900">
                              {pb.title}
                            </h4>
                            <p className="text-xs text-slate-500">
                              تاريخ الطلب: {pb.orderDate} • السعر: {pb.price}{" "}
                              ج.م
                            </p>
                          </div>
                        </div>
                        <span
                          dir="ltr"
                          className="px-3 py-1 rounded-lg bg-slate-900 text-amber-300 font-mono-num text-xs font-bold"
                        >
                          Tracking: {pb.trackingCode}
                        </span>
                      </div>

                      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                        {[
                          { s: 1, label: "1. تم تأكيد الطلب" },
                          { s: 2, label: "2. قيد التجهيز بالمطبعة" },
                          { s: 3, label: "3. خرج مع مندوب الشحن" },
                          { s: 4, label: "4. تم التسليم للطالب" },
                        ].map((st) => {
                          const done = pb.step >= st.s;
                          return (
                            <div
                              key={st.s}
                              className={`p-3 rounded-xl border text-xs font-bold flex items-center gap-2 ${
                                done
                                  ? "bg-emerald-50 border-emerald-300 text-emerald-800"
                                  : "bg-slate-50 border-slate-200 text-slate-400"
                              }`}
                            >
                              <CheckCircle2 className="w-4 h-4 shrink-0" />
                              <span>{st.label}</span>
                            </div>
                          );
                        })}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* ==========================================================
              SECTION 7: ACADEMIC SUPPORT & PROFILE
             ========================================================== */}
          {activeSection === "support_profile" && (
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-sm space-y-5 h-fit">
                <div className="flex items-center gap-3">
                  <div className="w-11 h-11 rounded-xl bg-[#0F172A] text-[#F59E0B] flex items-center justify-center">
                    <HelpCircle className="w-6 h-6" />
                  </div>
                  <div>
                    <h3 className="font-heading text-lg font-bold text-[#0F172A]">
                      الدعم العلمي المباشر — اسأل أستاذك
                    </h3>
                    <p className="text-xs text-slate-500">
                      أرسل أي سؤال نحوي أو بلاغي وسيقوم الفريق العلمي بالرد
                      عليك، أو تواصل عبر واتساب 01023316767
                    </p>
                  </div>
                </div>

                <div className="space-y-2">
                  <textarea
                    rows={3}
                    value={supportQuestion}
                    onChange={(e) => setSupportQuestion(e.target.value)}
                    placeholder="اكتب سؤالك العلمي أو الجملة التي تريد إعرابها بالتفصيل..."
                    className="w-full p-3.5 rounded-xl border border-slate-300 text-xs focus:outline-none focus:ring-2 focus:ring-[#0F172A]"
                  />
                  <button
                    onClick={() => {
                      if (!supportQuestion.trim()) return;
                      setSupportTickets([
                        {
                          id: Date.now(),
                          question: supportQuestion,
                          answer:
                            "تم استلام سؤالك العلمي، وجاري تحرير الإجابة النموذجية من قِبل المساعد العلمي المختص.",
                          status: "قيد المراجعة الفورية",
                          date: "الآن",
                        },
                        ...supportTickets,
                      ]);
                      setSupportQuestion("");
                      showNotification("تم إرسال سؤالك للدعم العلمي بنجاح!");
                    }}
                    className="w-full py-2.5 rounded-xl bg-[#0F172A] hover:bg-slate-800 text-white text-xs font-bold transition"
                  >
                    إرسال السؤال للفريق العلمي
                  </button>
                </div>

                <div className="space-y-3 pt-2 border-t border-slate-100">
                  {supportTickets.map((tk) => (
                    <div
                      key={tk.id}
                      className="p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-2 text-xs"
                    >
                      <div className="flex items-center justify-between">
                        <span className="px-2 py-0.5 rounded bg-emerald-100 text-emerald-800 font-bold text-[11px]">
                          {tk.status}
                        </span>
                        <span className="text-slate-400">{tk.date}</span>
                      </div>
                      <p className="font-bold text-slate-900">{tk.question}</p>
                      <p className="text-slate-600 bg-white p-2.5 rounded-lg border border-slate-200">
                        {tk.answer}
                      </p>
                    </div>
                  ))}
                </div>
              </div>

              <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-sm space-y-5">
                <div>
                  <h3 className="font-heading text-lg font-bold text-[#0F172A]">
                    الملف الشخصي وإعدادات الأمان والخصوصية
                  </h3>
                  <p className="text-xs text-slate-500">
                    بيانات أولياء الأمور محمية بتصريح Server-Side ولا تظهر لأي
                    طالب آخر
                  </p>
                </div>

                <form onSubmit={handleUpdateProfile} className="space-y-3.5">
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">
                      الاسم الثلاثي للطالب
                    </label>
                    <input
                      type="text"
                      value={profileName}
                      onChange={(e) => setProfileName(e.target.value)}
                      className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-xs"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">
                      رقم هاتف الطالب (معرف الدخول الفريد - غير قابل للتكرار)
                    </label>
                    <input
                      type="text"
                      dir="ltr"
                      disabled
                      value={student?.studentPhone || ""}
                      className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 bg-slate-100 font-mono-num text-xs text-slate-500"
                    />
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="block text-xs font-bold text-slate-700 mb-1">
                        رقم هاتف ولي الأمر (محمي)
                      </label>
                      <input
                        type="text"
                        dir="ltr"
                        value={profileGuardianPhone}
                        onChange={(e) =>
                          setProfileGuardianPhone(e.target.value)
                        }
                        className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 font-mono-num text-xs"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-bold text-slate-700 mb-1">
                        رقم هاتف الأم (محمي)
                      </label>
                      <input
                        type="text"
                        dir="ltr"
                        value={profileMotherPhone}
                        onChange={(e) => setProfileMotherPhone(e.target.value)}
                        className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 font-mono-num text-xs"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">
                      البريد الإلكتروني (اختياري)
                    </label>
                    <input
                      type="email"
                      dir="ltr"
                      value={profileEmail}
                      onChange={(e) => setProfileEmail(e.target.value)}
                      className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 font-mono-num text-xs"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">
                      تغيير كلمة المرور (تشفير Bcrypt)
                    </label>
                    <input
                      type="password"
                      dir="ltr"
                      value={profileNewPassword}
                      onChange={(e) => setProfileNewPassword(e.target.value)}
                      placeholder="اتركه فارغاً للاحتفاظ بكلمة المرور الحالية"
                      className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-xs"
                    />
                  </div>

                  <button
                    type="submit"
                    className="w-full py-3 rounded-xl bg-[#0F172A] hover:bg-slate-800 text-white font-heading font-bold text-xs transition"
                  >
                    حفظ تحديثات الملف الشخصي
                  </button>
                </form>

                <div className="pt-4 border-t border-slate-200 space-y-2">
                  <h4 className="text-xs font-bold text-red-700">
                    سياسة الحذف الآمن للبيانات الشخصية:
                  </h4>
                  <p className="text-[11px] text-slate-500">
                    عند رغبتك في حذف حسابك، يتم مسح كافة بياناتك الشخصية وأرقام
                    الهواتف وسجلات التقدم نهائياً من قاعدة البيانات دون الاحتفاظ
                    بها لغير حاجة.
                  </p>
                  <button
                    type="button"
                    onClick={handleSecureDeleteAccount}
                    className="px-4 py-2 rounded-xl bg-red-50 hover:bg-red-100 text-red-700 border border-red-200 text-xs font-bold flex items-center gap-1.5 transition"
                  >
                    <Trash2 className="w-4 h-4" />
                    حذف الحساب ومسح البيانات الشخصية بأمان
                  </button>
                </div>
              </div>
            </div>
          )}
        </main>
      </div>

      {/* ============================================================
          POP-UP MODAL: PACKAGE CONTENTS
         ============================================================ */}
      {inspectingPackage && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/75 backdrop-blur-sm p-4 overflow-y-auto">
          <div className="bg-white w-full max-w-2xl rounded-2xl shadow-2xl border border-slate-200 overflow-hidden my-auto">
            <div className="bg-[#0F172A] text-white px-6 py-4 flex items-center justify-between">
              <div>
                <span className="text-xs font-bold text-[#F59E0B]">
                  تفاصيل ومحتويات الباقة الدراسية
                </span>
                <h3 className="font-heading text-lg font-bold">
                  {inspectingPackage.title}
                </h3>
              </div>
              <button
                onClick={() => setInspectingPackage(null)}
                className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-6 space-y-4">
              <p className="text-xs text-slate-600 leading-relaxed">
                {inspectingPackage.description}
              </p>

              <div className="space-y-2.5">
                <h4 className="font-heading font-bold text-sm text-slate-900">
                  قائمة المحاضرات والدروس المشمولة وحالة كل درس:
                </h4>
                {inspectingPackage.items.map((item, i) => (
                  <div
                    key={item.id}
                    className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 flex items-center justify-between gap-3"
                  >
                    <div className="flex items-center gap-3">
                      <span className="w-7 h-7 rounded-lg bg-[#0F172A] text-[#F59E0B] font-mono-num text-xs font-bold flex items-center justify-center shrink-0">
                        {i + 1}
                      </span>
                      <div>
                        <div className="text-xs sm:text-sm font-bold text-slate-900">
                          {item.itemTitle}
                        </div>
                        <div className="text-[11px] text-slate-500">
                          {item.courseTitle} •{" "}
                          {Math.round(item.durationSeconds / 60)} دقيقة
                        </div>
                      </div>
                    </div>

                    <div className="shrink-0">
                      {item.lessonStatus === "completed" ? (
                        <span className="px-2.5 py-1 rounded-full bg-emerald-100 text-emerald-800 text-[11px] font-bold flex items-center gap-1">
                          <CheckCircle2 className="w-3.5 h-3.5" />
                          مكتمل (100%)
                        </span>
                      ) : item.lessonStatus === "in_progress" ? (
                        <span className="px-2.5 py-1 rounded-full bg-amber-100 text-amber-900 text-[11px] font-bold flex items-center gap-1">
                          <Clock className="w-3.5 h-3.5" />
                          قيد المشاهدة ({item.progressPercent}%)
                        </span>
                      ) : item.lessonStatus === "unlocked" ? (
                        <span className="px-2.5 py-1 rounded-full bg-blue-50 text-blue-700 text-[11px] font-bold">
                          متاح للمشاهدة
                        </span>
                      ) : (
                        <span className="px-2.5 py-1 rounded-full bg-slate-200 text-slate-700 text-[11px] font-bold flex items-center gap-1">
                          <Lock className="w-3 h-3" />
                          يُفتح بالاشتراك
                        </span>
                      )}
                    </div>
                  </div>
                ))}
              </div>

              <div className="pt-4 border-t border-slate-200 flex items-center justify-between gap-4">
                <div>
                  <span className="text-xs text-slate-500 block">
                    سعر الباقة الشامل:
                  </span>
                  <span className="font-mono-num text-2xl font-extrabold text-[#0F172A]">
                    {inspectingPackage.price} ج.م
                  </span>
                </div>
                <button
                  onClick={() => {
                    const pkg = inspectingPackage;
                    setInspectingPackage(null);
                    setCheckoutItem({
                      packageId: pkg.id,
                      title: pkg.title,
                      price: pkg.price,
                      subtitle: pkg.subtitle,
                    });
                  }}
                  className="px-6 py-3 rounded-xl bg-[#F59E0B] hover:bg-amber-400 text-[#0F172A] font-heading font-bold text-xs shadow-lg transition"
                >
                  اشترك الآن في الباقة
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ============================================================
          PROTECTED VIDEO PLAYER MODAL
         ============================================================ */}
      <ProtectedVideoModal
        lessonId={activeVideoLessonId}
        onClose={() => setActiveVideoLessonId(null)}
        onProgressUpdated={fetchDashboard}
      />

      {/* ============================================================
          CHECKOUT MODAL (INSTAPAY / VODAFONE CASH / PAYMOB)
         ============================================================ */}
      <PaymobCheckoutModal
        item={checkoutItem}
        walletBalance={stats.walletBalance}
        studentPhone={student?.studentPhone || "01012345678"}
        onClose={() => setCheckoutItem(null)}
        onSuccess={(msg) => {
          showNotification(msg);
          fetchDashboard();
        }}
      />

      {/* ============================================================
          AUTH MODAL
         ============================================================ */}
      <AuthModal
        isOpen={authModalOpen}
        initialMode={authInitialMode}
        onClose={() => setAuthModalOpen(false)}
        onAuthSuccess={() => {
          showNotification("تم تحديث جلسة الدخول بنجاح!");
          fetchDashboard();
        }}
      />
    </div>
  );
}
