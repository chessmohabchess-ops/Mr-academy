import type { Metadata } from "next";
import type { ReactNode } from "react";
import { Cairo, Readex_Pro, JetBrains_Mono } from "next/font/google";
import "./globals.css";
import { FloatingWhatsApp } from "@/components/FloatingWhatsApp";

const cairo = Cairo({
  subsets: ["arabic", "latin"],
  weight: ["400", "500", "600", "700", "800"],
  variable: "--font-cairo",
  display: "swap",
});

const readexPro = Readex_Pro({
  subsets: ["arabic", "latin"],
  weight: ["500", "600", "700"],
  variable: "--font-readex",
  display: "swap",
});

const jetbrainsMono = JetBrains_Mono({
  subsets: ["latin"],
  weight: ["500", "600", "700"],
  variable: "--font-mono",
  display: "swap",
});

export const metadata: Metadata = {
  title: "منصة البيان التعليمية | أ.د. محمود الشافعي — المنصة الأكاديمية المتكاملة",
  description:
    "المنصة التعليمية العربية المتكاملة لطلاب المرحلة الثانوية — محاضرات أونلاين وسنتر، امتحانات تفاعلية، قسم أخطائي، ملازم PDF، ومتجر الكتب مع دعم بوابات الدفع المصرية.",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html
      lang="ar"
      dir="rtl"
      className={`${cairo.variable} ${readexPro.variable} ${jetbrainsMono.variable}`}
    >
      <body className="bg-[#F8FAFC] text-[#0F172A] font-sans antialiased selection:bg-[#F59E0B]/20 selection:text-[#0F172A] min-h-screen">
        {children}
        <FloatingWhatsApp />
      </body>
    </html>
  );
}
