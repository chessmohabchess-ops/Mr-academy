"use client";

import React, { useEffect, useState, useCallback } from "react";
import Link from "next/link";
import {
  ShieldAlert,
  Users,
  Search,
  Ban,
  CheckCircle2,
  Edit3,
  PlusCircle,
  Trash2,
  BookOpen,
  Layers,
  Package,
  FileQuestion,
  TicketPercent,
  ClipboardList,
  ArrowRight,
  Lock,
  Phone,
  Terminal,
  X,
  CreditCard,
  Sparkles,
  RefreshCw,
  Settings,
  DollarSign,
  Send,
} from "lucide-react";

interface EnrolledCourseItem {
  enrollmentId: number;
  courseId: number;
  title: string;
  grantedBy: string;
}

interface EnrolledPackageItem {
  enrollmentId: number;
  packageId: number;
  title: string;
}

interface AdminStudentRow {
  id: number;
  tripleName: string;
  studentPhone: string;
  guardianPhone: string;
  motherPhone: string;
  email: string | null;
  status: string;
  gradeLevel: string;
  walletBalance: number;
  points: number;
  bookGiftCode: string;
  createdAt: string;
  lastLoginAt: string;
  enrolledCourses: EnrolledCourseItem[];
  enrolledPackages: EnrolledPackageItem[];
  totalPaid: number;
  paymentStatus: string;
  progressPercent: number;
  completedLessonsCount: number;
}

export default function AdminStudentsPage() {
  const [activeTab, setActiveTab] = useState<
    | "students"
    | "courses"
    | "packages"
    | "quizzes"
    | "coupons"
    | "direct_settings"
    | "audit"
    | "devops"
  >("students");

  const [loading, setLoading] = useState(true);
  const [toast, setToast] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState("");
  const [statusFilter, setStatusFilter] = useState<"all" | "active" | "banned">(
    "all"
  );

  const [students, setStudents] = useState<AdminStudentRow[]>([]);
  const [coursesList, setCoursesList] = useState<
    Array<{
      id: number;
      title: string;
      price: number;
      type: string;
      gradeLevel: string;
      instructorName?: string;
      subject?: string;
    }>
  >([]);
  const [sectionsList, setSectionsList] = useState<
    Array<{ id: number; courseId: number; title: string }>
  >([]);
  const [lessonsList, setLessonsList] = useState<
    Array<{
      id: number;
      courseId: number;
      sectionId: number;
      title: string;
      durationSeconds: number;
      type: string;
      pdfTitle: string | null;
    }>
  >([]);
  const [packagesList, setPackagesList] = useState<
    Array<{
      id: number;
      title: string;
      subtitle: string;
      price: number;
      originalPrice: number;
      durationLabel: string;
      items: Array<{ id: number; itemTitle: string }>;
    }>
  >([]);
  const [quizzesList, setQuizzesList] = useState<
    Array<{
      id: number;
      courseId: number;
      courseTitle: string;
      title: string;
      passingScore: number;
      durationMinutes: number;
      questions: Array<{
        id: number;
        questionText: string;
        explanation: string;
        answers: Array<{ id: number; answerText: string; isCorrect: boolean }>;
      }>;
    }>
  >([]);
  const [couponsList, setCouponsList] = useState<
    Array<{
      id: number;
      code: string;
      discountPercent: number;
      maxUses: number;
      usedCount: number;
      active: boolean;
    }>
  >([]);
  const [paymentsList, setPaymentsList] = useState<
    Array<{
      id: number;
      studentName: string;
      studentPhone: string;
      amount: number;
      method: string;
      status: string;
      paymobOrderId: string;
      hmacVerified: boolean;
      createdAt: string;
    }>
  >([]);
  const [auditLogsList, setAuditLogsList] = useState<
    Array<{
      id: number;
      adminName: string;
      action: string;
      targetType: string;
      targetId: string;
      details: string;
      createdAt: string;
    }>
  >([]);

  // Platform Settings state
  const [directSettings, setDirectSettings] = useState<{
    vodafoneCashNumber: string;
    instapayAddress: string;
    instapayName: string;
    supportPhone: string;
    transferInstructions: string;
  }>({
    vodafoneCashNumber: "01023316767",
    instapayAddress: "albayan@instapay",
    instapayName: "أ.د. محمود الشافعي (البيان التعليمية)",
    supportPhone: "01023316767",
    transferInstructions:
      "يرجى التحويل على رقم فودافون كاش أو معرف InstaPay الموضحين، ثم كتابة رقم المحفظة المحول منها ورفع صورة الإشعار للموافقة وتفعيل الكورس فوراً.",
  });

  // Modals for Student Edit & Manual Course Grant
  const [editingStudent, setEditingStudent] =
    useState<AdminStudentRow | null>(null);
  const [grantModalStudent, setGrantModalStudent] =
    useState<AdminStudentRow | null>(null);
  const [selectedGrantCourseId, setSelectedGrantCourseId] = useState<string>("");
  const [selectedGrantPkgId, setSelectedGrantPkgId] = useState<string>("");

  // Forms for CRUD
  const [newCourseTitle, setNewCourseTitle] = useState("");
  const [newCoursePrice, setNewCoursePrice] = useState("250");
  const [newCourseType, setNewCourseType] = useState("online");
  const [newCourseInstructor, setNewCourseInstructor] = useState("أ.د. محمود الشافعي");
  const [newCourseSubject, setNewCourseSubject] = useState("اللغة العربية");

  const [newSectionCourseId, setNewSectionCourseId] = useState<string>("");
  const [newSectionTitle, setNewSectionTitle] = useState("");

  const [newLessonCourseId, setNewLessonCourseId] = useState<string>("");
  const [newLessonTitle, setNewLessonTitle] = useState("");
  const [newLessonDuration, setNewLessonDuration] = useState("45");
  const [newLessonType, setNewLessonType] = useState("online");
  const [newLessonStorageKey, setNewLessonStorageKey] = useState(
    "r2://albayan-private-videos/2026/new-lecture.mp4"
  );

  const [newPkgTitle, setNewPkgTitle] = useState("");
  const [newPkgSubtitle, setNewPkgSubtitle] = useState("");
  const [newPkgPrice, setNewPkgPrice] = useState("350");
  const [newPkgOriginalPrice, setNewPkgOriginalPrice] = useState("500");
  const [newPkgDuration, setNewPkgDuration] = useState("اشتراك شهرين");
  const [newPkgCourseIds, setNewPkgCourseIds] = useState<number[]>([]);

  const [newQuizCourseId, setNewQuizCourseId] = useState<string>("");
  const [newQuizTitle, setNewQuizTitle] = useState("");
  const [newQuizPassScore, setNewQuizPassScore] = useState("60");
  const [newQuizDuration, setNewQuizDuration] = useState("20");
  const [newQuestionText, setNewQuestionText] = useState("");
  const [newQuestionExplanation, setNewQuestionExplanation] = useState("");
  const [newQuestionOptions, setNewQuestionOptions] = useState([
    "",
    "",
    "",
    "",
  ]);
  const [newQuestionCorrectIdx, setNewQuestionCorrectIdx] = useState(0);

  const [newCouponCode, setNewCouponCode] = useState("");
  const [newCouponDiscount, setNewCouponDiscount] = useState("30");
  const [newCouponMaxUses, setNewCouponMaxUses] = useState("100");

  const showToast = (msg: string) => {
    setToast(msg);
    setTimeout(() => setToast(null), 4000);
  };

  const fetchAdminData = useCallback(async () => {
    setLoading(true);
    try {
      const [adminRes, settingsRes] = await Promise.all([
        fetch("/api/admin/students"),
        fetch("/api/admin/settings"),
      ]);
      const data = await adminRes.json();
      const settingsData = await settingsRes.json();

      if (adminRes.ok) {
        setStudents(data.students || []);
        setCoursesList(data.courses || []);
        setSectionsList(data.sections || []);
        setLessonsList(data.lessons || []);
        setPackagesList(data.packages || []);
        setQuizzesList(data.quizzes || []);
        setCouponsList(data.coupons || []);
        setPaymentsList(data.payments || []);
        setAuditLogsList(data.auditLogs || []);

        if (data.courses?.length > 0) {
          setNewSectionCourseId(String(data.courses[0].id));
          setNewLessonCourseId(String(data.courses[0].id));
          setNewQuizCourseId(String(data.courses[0].id));
          setSelectedGrantCourseId(String(data.courses[0].id));
        }
      }

      if (settingsData.settings) {
        setDirectSettings(settingsData.settings);
      }
    } catch {
      showToast("تعذر جلب بيانات لوحة التحكم");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchAdminData();
  }, [fetchAdminData]);

  const runAdminAction = async (payload: Record<string, unknown>) => {
    try {
      const res = await fetch("/api/admin/students", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });
      const data = await res.json();
      if (!res.ok) {
        showToast(data.error || "تعذر تنفيذ العملية");
        return false;
      }
      showToast(data.message || "تمت العملية بنجاح");
      fetchAdminData();
      return true;
    } catch {
      showToast("حدث خطأ في الاتصال بالخادم");
      return false;
    }
  };

  const handleSaveDirectSettings = async () => {
    try {
      const res = await fetch("/api/admin/settings", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(directSettings),
      });
      const data = await res.json();
      if (!res.ok) {
        showToast(data.error || "تعذر حفظ إعدادات الدفع");
      } else {
        showToast(data.message);
        fetchAdminData();
      }
    } catch {
      showToast("حدث خطأ في الاتصال");
    }
  };

  const filteredStudents = students.filter((stu) => {
    const matchesStatus =
      statusFilter === "all" || stu.status === statusFilter;
    const q = searchQuery.trim().toLowerCase();
    if (!q) return matchesStatus;
    return (
      matchesStatus &&
      (stu.tripleName.toLowerCase().includes(q) ||
        stu.studentPhone.includes(q) ||
        stu.guardianPhone.includes(q) ||
        stu.motherPhone.includes(q) ||
        (stu.email && stu.email.toLowerCase().includes(q)))
    );
  });

  return (
    <div className="min-h-screen bg-[#F8FAFC] text-[#0F172A] pb-20">
      {/* Toast Notification */}
      {toast && (
        <div className="fixed top-5 left-1/2 -translate-x-1/2 z-50 bg-[#0F172A] text-white px-5 py-3 rounded-2xl shadow-2xl border border-[#F59E0B] flex items-center gap-2.5 text-sm font-bold">
          <Sparkles className="w-4 h-4 text-[#F59E0B]" />
          <span>{toast}</span>
        </div>
      )}

      {/* Top Header */}
      <header className="bg-[#0F172A] text-white border-b border-slate-800 sticky top-0 z-40">
        <div className="max-w-[1440px] mx-auto px-4 sm:px-8 py-4 flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center gap-3.5">
            <div className="w-11 h-11 rounded-2xl bg-[#F59E0B] text-[#0F172A] flex items-center justify-center shadow-lg shadow-amber-500/20">
              <ShieldAlert className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="font-heading text-lg sm:text-xl font-bold">
                  لوحة تحكم الإدارة الأكاديمية (/admin/students)
                </h1>
                <span className="px-2.5 py-0.5 rounded-full bg-emerald-500/20 border border-emerald-400/40 text-emerald-300 text-[11px] font-bold">
                  Server-Side Authorized
                </span>
              </div>
              <p className="text-xs text-slate-300">
                إدارة الطلاب، أرقام أولياء الأمور المعزولة، التحكم بأسعار الكورسات، ومراجعة إشعارات InstaPay
              </p>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2.5">
            <Link
              href="/admin/courses"
              className="px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-amber-300 border border-amber-500/30 text-xs font-bold transition flex items-center gap-1.5"
            >
              <DollarSign className="w-3.5 h-3.5 text-amber-400" />
              <span>التحكم بأسعار الكورسات والمدرس</span>
            </Link>
            <Link
              href="/admin/payments"
              className="px-3.5 py-2 rounded-xl bg-emerald-950/80 hover:bg-emerald-900 text-emerald-300 border border-emerald-500/40 text-xs font-bold transition flex items-center gap-1.5"
            >
              <CreditCard className="w-3.5 h-3.5 text-emerald-400" />
              <span>مراجعة طلبات الدفع والـ InstaPay</span>
            </Link>
            <Link
              href="/"
              className="px-4 py-2.5 rounded-xl bg-[#F59E0B] hover:bg-amber-400 text-[#0F172A] font-heading font-bold text-xs flex items-center gap-2 transition shadow-md"
            >
              <span>منصة الطالب</span>
              <ArrowRight className="w-4 h-4 rotate-180" />
            </Link>
          </div>
        </div>

        {/* Navigation Tabs */}
        <div className="max-w-[1440px] mx-auto px-4 sm:px-8 flex items-center gap-2 overflow-x-auto pb-3 pt-1">
          {[
            {
              id: "students",
              label: `إدارة الطلاب (${students.length})`,
              icon: Users,
            },
            {
              id: "direct_settings",
              label: "إعدادات InstaPay وفودافون كاش",
              icon: Send,
            },
            {
              id: "courses",
              label: `الكورسات والدروس (${coursesList.length})`,
              icon: BookOpen,
            },
            {
              id: "packages",
              label: `الباقات (${packagesList.length})`,
              icon: Package,
            },
            {
              id: "quizzes",
              label: `الاختبارات والأسئلة (${quizzesList.length})`,
              icon: FileQuestion,
            },
            {
              id: "coupons",
              label: `الكوبونات والمدفوعات (${couponsList.length})`,
              icon: TicketPercent,
            },
            {
              id: "audit",
              label: `سجل العمليات (${auditLogsList.length})`,
              icon: ClipboardList,
            },
            {
              id: "devops",
              label: "بيئة الإنتاج (.env & Seed)",
              icon: Terminal,
            },
          ].map((tab) => {
            const Icon = tab.icon;
            const active = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() =>
                  setActiveTab(
                    tab.id as
                      | "students"
                      | "courses"
                      | "packages"
                      | "quizzes"
                      | "coupons"
                      | "direct_settings"
                      | "audit"
                      | "devops"
                  )
                }
                className={`px-4 py-2 rounded-xl text-xs font-bold flex items-center gap-2 whitespace-nowrap transition ${
                  active
                    ? "bg-[#F59E0B] text-[#0F172A] shadow"
                    : "bg-slate-800/80 text-slate-300 hover:bg-slate-800 hover:text-white"
                }`}
              >
                <Icon className="w-4 h-4" />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </div>
      </header>

      <main className="max-w-[1440px] mx-auto px-4 sm:px-8 pt-6 space-y-6">
        {/* ====================================================
            TAB: DIRECT TRANSFER SETTINGS (INSTAPAY & VODAFONE)
           ==================================================== */}
        {activeTab === "direct_settings" && (
          <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-6 max-w-3xl mx-auto space-y-5">
            <div className="border-b border-slate-100 pb-4">
              <h2 className="font-heading text-lg font-bold text-[#0F172A] flex items-center gap-2">
                <Send className="w-5 h-5 text-[#F59E0B]" />
                إعدادات التحويل المباشر (InstaPay / محفظة فودافون كاش)
              </h2>
              <p className="text-xs text-slate-500 mt-1">
                تظهر هذه الأرقام والمعرفات للطلاب عند اختيار وسيلة الدفع بالتحويل المباشر مع أزرار نسخ فورية
              </p>
            </div>

            <div className="space-y-4 text-xs">
              <div>
                <label className="font-bold text-slate-800 block mb-1">
                  عنوان الدفع اللحظي (InstaPay Address / IPA):
                </label>
                <input
                  type="text"
                  dir="ltr"
                  value={directSettings.instapayAddress}
                  onChange={(e) =>
                    setDirectSettings({
                      ...directSettings,
                      instapayAddress: e.target.value,
                    })
                  }
                  placeholder="albayan@instapay"
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 font-mono-num text-sm text-purple-950 font-bold bg-purple-50/30"
                />
              </div>

              <div>
                <label className="font-bold text-slate-800 block mb-1">
                  الاسم المسجل على حساب InstaPay (ليتأكد منه الطالب):
                </label>
                <input
                  type="text"
                  value={directSettings.instapayName}
                  onChange={(e) =>
                    setDirectSettings({
                      ...directSettings,
                      instapayName: e.target.value,
                    })
                  }
                  placeholder="أ.د. محمود الشافعي (البيان التعليمية)"
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-xs"
                />
              </div>

              <div>
                <label className="font-bold text-slate-800 block mb-1">
                  رقم محفظة فودافون كاش لاستقبال التحويلات:
                </label>
                <input
                  type="text"
                  dir="ltr"
                  value={directSettings.vodafoneCashNumber}
                  onChange={(e) =>
                    setDirectSettings({
                      ...directSettings,
                      vodafoneCashNumber: e.target.value,
                    })
                  }
                  placeholder="01023316767"
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 font-mono-num text-sm text-red-950 font-bold bg-red-50/30"
                />
              </div>

              <div>
                <label className="font-bold text-slate-800 block mb-1">
                  رقم هاتف الدعم الفني والمساعدة (WhatsApp):
                </label>
                <input
                  type="text"
                  dir="ltr"
                  value={directSettings.supportPhone}
                  onChange={(e) =>
                    setDirectSettings({
                      ...directSettings,
                      supportPhone: e.target.value,
                    })
                  }
                  placeholder="01023316767"
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 font-mono-num text-xs"
                />
              </div>

              <div>
                <label className="font-bold text-slate-800 block mb-1">
                  تعليمات وتوجيهات التحويل التي تظهر للطالب:
                </label>
                <textarea
                  rows={3}
                  value={directSettings.transferInstructions}
                  onChange={(e) =>
                    setDirectSettings({
                      ...directSettings,
                      transferInstructions: e.target.value,
                    })
                  }
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-xs"
                />
              </div>

              <div className="pt-2">
                <button
                  onClick={handleSaveDirectSettings}
                  className="w-full py-3 rounded-xl bg-[#0F172A] hover:bg-slate-800 text-white font-heading font-bold text-xs transition shadow-md"
                >
                  حفظ إعدادات التحويل المباشر
                </button>
              </div>
            </div>
          </div>
        )}

        {/* ====================================================
            TAB 1: STUDENTS MANAGEMENT TABLE (/admin/students)
           ==================================================== */}
        {activeTab === "students" && (
          <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
            {/* Search & Filter Header */}
            <div className="p-5 border-b border-slate-200 flex flex-wrap items-center justify-between gap-4 bg-slate-50/60">
              <div>
                <h2 className="font-heading text-lg font-bold text-[#0F172A] flex items-center gap-2">
                  <span>جدول إدارة الطلاب وبيانات أولياء الأمور السرية</span>
                  <span className="px-2.5 py-0.5 rounded-full text-[11px] bg-amber-100 text-amber-900 border border-amber-300">
                    خاص بالأدمن فقط
                  </span>
                </h2>
                <p className="text-xs text-slate-500 mt-0.5">
                  ابحث بالاسم الثلاثي أو برقم هاتف الطالب أو رقم ولي الأمر أو رقم
                  الأم، أو تحكم في حالة الحساب والكورسات يدوياً.
                </p>
              </div>

              <div className="flex flex-wrap items-center gap-3 w-full sm:w-auto">
                <div className="relative flex-1 sm:w-80">
                  <Search className="w-4 h-4 text-slate-400 absolute right-3.5 top-3" />
                  <input
                    type="text"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder="ابحث بالاسم الثلاثي أو رقم الهاتف (010...)"
                    className="w-full pr-10 pl-3 py-2 rounded-xl bg-white border border-slate-300 text-xs focus:outline-none focus:ring-2 focus:ring-[#0F172A]"
                  />
                </div>

                <div className="flex rounded-xl bg-slate-200/70 p-1 text-xs font-bold">
                  {[
                    { id: "all", label: "الكل" },
                    { id: "active", label: "نشط" },
                    { id: "banned", label: "محظور" },
                  ].map((st) => (
                    <button
                      key={st.id}
                      onClick={() =>
                        setStatusFilter(st.id as "all" | "active" | "banned")
                      }
                      className={`px-3 py-1.5 rounded-lg transition ${
                        statusFilter === st.id
                          ? "bg-[#0F172A] text-white shadow"
                          : "text-slate-600 hover:text-slate-900"
                      }`}
                    >
                      {st.label}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {/* Responsive Full Table */}
            <div className="overflow-x-auto">
              <table className="w-full text-right border-collapse">
                <thead>
                  <tr className="bg-[#0F172A] text-white text-xs font-heading">
                    <th className="py-3.5 px-4">الاسم الثلاثي للطالب</th>
                    <th className="py-3.5 px-4">رقم الطالب</th>
                    <th className="py-3.5 px-4 bg-slate-800/90 text-amber-300">
                      <span className="inline-flex items-center gap-1">
                        <Lock className="w-3 h-3" /> رقم ولي الأمر
                      </span>
                    </th>
                    <th className="py-3.5 px-4 bg-slate-800/90 text-amber-300">
                      <span className="inline-flex items-center gap-1">
                        <Lock className="w-3 h-3" /> رقم الأم
                      </span>
                    </th>
                    <th className="py-3.5 px-4">تاريخ الحساب وآخر دخول</th>
                    <th className="py-3.5 px-4">حالة الحساب</th>
                    <th className="py-3.5 px-4">الكورسات والباقات المسجلة</th>
                    <th className="py-3.5 px-4">حالة الدفع</th>
                    <th className="py-3.5 px-4">نسبة التقدم</th>
                    <th className="py-3.5 px-4 text-center">إجراءات التحكم</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200 text-xs">
                  {loading ? (
                    <tr>
                      <td
                        colSpan={10}
                        className="py-12 text-center text-slate-500 font-bold"
                      >
                        جاري تحميل سجل الطلاب...
                      </td>
                    </tr>
                  ) : filteredStudents.length === 0 ? (
                    <tr>
                      <td
                        colSpan={10}
                        className="py-12 text-center text-slate-500 font-bold"
                      >
                        لا يوجد طلاب مطابقون لمعايير البحث الحالية.
                      </td>
                    </tr>
                  ) : (
                    filteredStudents.map((stu) => (
                      <tr
                        key={stu.id}
                        className={`hover:bg-slate-50/90 transition ${
                          stu.status === "banned" ? "bg-red-50/30" : ""
                        }`}
                      >
                        <td className="py-4 px-4">
                          <div className="font-bold text-slate-900 text-sm">
                            {stu.tripleName}
                          </div>
                          <div className="text-[11px] text-slate-500">
                            {stu.gradeLevel}
                          </div>
                          <div className="text-[11px] font-mono-num text-emerald-700 mt-0.5">
                            المحفظة: {stu.walletBalance} ج.م • {stu.points} نقطة
                          </div>
                        </td>

                        <td className="py-4 px-4">
                          <span
                            dir="ltr"
                            className="inline-flex items-center gap-1 font-mono-num font-bold text-slate-900 bg-slate-100 px-2.5 py-1 rounded-lg border border-slate-200"
                          >
                            <Phone className="w-3 h-3 text-slate-500" />
                            {stu.studentPhone}
                          </span>
                        </td>

                        <td className="py-4 px-4 bg-amber-50/40">
                          <span
                            dir="ltr"
                            className="inline-flex items-center gap-1 font-mono-num font-bold text-amber-950 bg-amber-100/80 px-2.5 py-1 rounded-lg border border-amber-300"
                          >
                            <Phone className="w-3 h-3 text-amber-700" />
                            {stu.guardianPhone}
                          </span>
                        </td>

                        <td className="py-4 px-4 bg-amber-50/40">
                          <span
                            dir="ltr"
                            className="inline-flex items-center gap-1 font-mono-num font-bold text-amber-950 bg-amber-100/80 px-2.5 py-1 rounded-lg border border-amber-300"
                          >
                            <Phone className="w-3 h-3 text-amber-700" />
                            {stu.motherPhone}
                          </span>
                        </td>

                        <td className="py-4 px-4">
                          <div className="text-slate-800 font-medium">
                            إنشاء:{" "}
                            <span className="font-mono-num">
                              {new Date(stu.createdAt).toLocaleDateString(
                                "ar-EG"
                              )}
                            </span>
                          </div>
                          <div className="text-[11px] text-slate-500 mt-0.5">
                            آخر دخول:{" "}
                            <span className="font-mono-num">
                              {stu.lastLoginAt
                                ? new Date(stu.lastLoginAt).toLocaleDateString(
                                    "ar-EG"
                                  )
                                : "اليوم"}
                            </span>
                          </div>
                        </td>

                        <td className="py-4 px-4">
                          {stu.status === "active" ? (
                            <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full bg-emerald-50 text-emerald-700 border border-emerald-200 font-bold text-[11px]">
                              <CheckCircle2 className="w-3.5 h-3.5" />
                              نشط
                            </span>
                          ) : (
                            <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full bg-red-100 text-red-700 border border-red-300 font-bold text-[11px]">
                              <Ban className="w-3.5 h-3.5" />
                              محظور
                            </span>
                          )}
                        </td>

                        <td className="py-4 px-4 max-w-[240px]">
                          <div className="flex flex-wrap gap-1.5">
                            {stu.enrolledPackages.map((pk) => (
                              <span
                                key={`pk-${pk.enrollmentId}`}
                                className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md bg-amber-100 text-amber-950 border border-amber-300 text-[11px] font-bold"
                              >
                                {pk.title.slice(0, 20)}..
                                <button
                                  onClick={() =>
                                    runAdminAction({
                                      action: "revoke_access",
                                      enrollmentId: pk.enrollmentId,
                                    })
                                  }
                                  title="إلغاء صلاحية الباقة"
                                  className="text-red-600 hover:text-red-800 font-extrabold px-0.5"
                                >
                                  ×
                                </button>
                              </span>
                            ))}
                            {stu.enrolledCourses.map((cr) => (
                              <span
                                key={`cr-${cr.enrollmentId}`}
                                className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md bg-slate-100 text-slate-800 border border-slate-300 text-[11px] font-semibold"
                              >
                                {cr.title.slice(0, 18)}..
                                <button
                                  onClick={() =>
                                    runAdminAction({
                                      action: "revoke_access",
                                      enrollmentId: cr.enrollmentId,
                                    })
                                  }
                                  title="إلغاء صلاحية الكورس"
                                  className="text-red-600 hover:text-red-800 font-extrabold px-0.5"
                                >
                                  ×
                                </button>
                              </span>
                            ))}
                            <button
                              onClick={() => setGrantModalStudent(stu)}
                              className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md bg-[#0F172A] text-white hover:bg-slate-800 text-[11px] font-bold transition"
                            >
                              <PlusCircle className="w-3 h-3 text-[#F59E0B]" />
                              منح كورس
                            </button>
                          </div>
                        </td>

                        <td className="py-4 px-4">
                          <div className="font-bold text-slate-900">
                            {stu.paymentStatus}
                          </div>
                          <div className="font-mono-num text-[11px] text-emerald-700 font-bold">
                            {stu.totalPaid} ج.م
                          </div>
                        </td>

                        <td className="py-4 px-4 min-w-[130px]">
                          <div className="flex items-center justify-between text-[11px] font-bold mb-1">
                            <span>{stu.progressPercent}%</span>
                            <span className="text-slate-400">
                              ({stu.completedLessonsCount} درس)
                            </span>
                          </div>
                          <div className="w-full h-2 rounded-full bg-slate-100 overflow-hidden">
                            <div
                              className="h-full bg-emerald-500 rounded-full"
                              style={{ width: `${stu.progressPercent}%` }}
                            />
                          </div>
                        </td>

                        <td className="py-4 px-4">
                          <div className="flex items-center justify-center gap-1.5">
                            <button
                              onClick={() => setEditingStudent(stu)}
                              title="تعديل بيانات الطالب والأرقام"
                              className="p-2 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 transition"
                            >
                              <Edit3 className="w-4 h-4" />
                            </button>
                            <button
                              onClick={() =>
                                runAdminAction({
                                  action: "toggle_ban_student",
                                  studentId: stu.id,
                                })
                              }
                              title={
                                stu.status === "banned"
                                  ? "فك حظر الحساب"
                                  : "حظر حساب الطالب"
                              }
                              className={`p-2 rounded-lg transition ${
                                stu.status === "banned"
                                  ? "bg-emerald-100 hover:bg-emerald-200 text-emerald-700"
                                  : "bg-amber-100 hover:bg-amber-200 text-amber-800"
                              }`}
                            >
                              <Ban className="w-4 h-4" />
                            </button>
                            <button
                              onClick={() =>
                                runAdminAction({
                                  action: "delete_student",
                                  studentId: stu.id,
                                })
                              }
                              title="حذف الحساب نهائياً بأمان"
                              className="p-2 rounded-lg bg-red-50 hover:bg-red-100 text-red-600 transition"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* ====================================================
            TAB 2: COURSES, SECTIONS & LESSONS CRUD
           ==================================================== */}
        {activeTab === "courses" && (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Forms Column */}
            <div className="space-y-6">
              {/* Create Course Form */}
              <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm space-y-3">
                <h3 className="font-heading font-bold text-base text-[#0F172A] flex items-center gap-2">
                  <PlusCircle className="w-5 h-5 text-[#F59E0B]" />
                  إضافة كورس تعليمي جديد
                </h3>
                <input
                  type="text"
                  value={newCourseTitle}
                  onChange={(e) => setNewCourseTitle(e.target.value)}
                  placeholder="عنوان الكورس (مثال: مراجعة ليلة الامتحان الشاملة)"
                  className="w-full px-3.5 py-2 rounded-xl border border-slate-300 text-xs"
                />
                <div className="grid grid-cols-2 gap-2">
                  <input
                    type="number"
                    value={newCoursePrice}
                    onChange={(e) => setNewCoursePrice(e.target.value)}
                    placeholder="السعر (ج.م)"
                    className="w-full px-3.5 py-2 rounded-xl border border-slate-300 text-xs font-mono-num"
                  />
                  <select
                    value={newCourseType}
                    onChange={(e) => setNewCourseType(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs bg-white"
                  >
                    <option value="online">محاضرات أونلاين</option>
                    <option value="center">محاضرات السنتر</option>
                    <option value="free">كورس مجاني</option>
                  </select>
                </div>
                <div className="grid grid-cols-2 gap-2">
                  <input
                    type="text"
                    value={newCourseInstructor}
                    onChange={(e) => setNewCourseInstructor(e.target.value)}
                    placeholder="اسم المدرس"
                    className="w-full px-3.5 py-2 rounded-xl border border-slate-300 text-xs"
                  />
                  <input
                    type="text"
                    value={newCourseSubject}
                    onChange={(e) => setNewCourseSubject(e.target.value)}
                    placeholder="المادة والفرع"
                    className="w-full px-3.5 py-2 rounded-xl border border-slate-300 text-xs"
                  />
                </div>
                <button
                  onClick={async () => {
                    const ok = await runAdminAction({
                      action: "create_course",
                      title: newCourseTitle,
                      price: Number(newCoursePrice),
                      type: newCourseType,
                    });
                    if (ok) setNewCourseTitle("");
                  }}
                  className="w-full py-2.5 rounded-xl bg-[#0F172A] hover:bg-slate-800 text-white text-xs font-bold transition"
                >
                  حفظ الكورس الجديد
                </button>
              </div>

              {/* Create Section Form */}
              <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm space-y-3">
                <h3 className="font-heading font-bold text-base text-[#0F172A] flex items-center gap-2">
                  <Layers className="w-5 h-5 text-[#F59E0B]" />
                  إضافة قسم (Section) داخل كورس
                </h3>
                <select
                  value={newSectionCourseId}
                  onChange={(e) => setNewSectionCourseId(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs bg-white"
                >
                  {coursesList.map((c) => (
                    <option key={c.id} value={c.id}>
                      {c.title}
                    </option>
                  ))}
                </select>
                <input
                  type="text"
                  value={newSectionTitle}
                  onChange={(e) => setNewSectionTitle(e.target.value)}
                  placeholder="اسم القسم (مثال: الوحدة الثالثة - النواسخ)"
                  className="w-full px-3.5 py-2 rounded-xl border border-slate-300 text-xs"
                />
                <button
                  onClick={async () => {
                    const ok = await runAdminAction({
                      action: "create_section",
                      courseId: Number(newSectionCourseId),
                      title: newSectionTitle,
                    });
                    if (ok) setNewSectionTitle("");
                  }}
                  className="w-full py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-white text-xs font-bold transition"
                >
                  إضافة القسم للكورس
                </button>
              </div>

              {/* Create Protected Lesson Form */}
              <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm space-y-3">
                <h3 className="font-heading font-bold text-base text-[#0F172A] flex items-center gap-2">
                  <BookOpen className="w-5 h-5 text-[#F59E0B]" />
                  إضافة محاضرة + فيديو محمي (Cloudflare R2)
                </h3>
                <select
                  value={newLessonCourseId}
                  onChange={(e) => setNewLessonCourseId(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs bg-white"
                >
                  {coursesList.map((c) => (
                    <option key={c.id} value={c.id}>
                      {c.title}
                    </option>
                  ))}
                </select>
                <input
                  type="text"
                  value={newLessonTitle}
                  onChange={(e) => setNewLessonTitle(e.target.value)}
                  placeholder="عنوان المحاضرة الجديدة"
                  className="w-full px-3.5 py-2 rounded-xl border border-slate-300 text-xs"
                />
                <div className="grid grid-cols-2 gap-2">
                  <input
                    type="number"
                    value={newLessonDuration}
                    onChange={(e) => setNewLessonDuration(e.target.value)}
                    placeholder="المدة بالدقائق (45)"
                    className="w-full px-3.5 py-2 rounded-xl border border-slate-300 text-xs font-mono-num"
                  />
                  <select
                    value={newLessonType}
                    onChange={(e) => setNewLessonType(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs bg-white"
                  >
                    <option value="online">أونلاين</option>
                    <option value="center">السنتر</option>
                    <option value="free">مجانية</option>
                  </select>
                </div>
                <div>
                  <label className="block text-[11px] font-bold text-slate-600 mb-1">
                    مفتاح التخزين السري في Cloudflare R2 / S3:
                  </label>
                  <input
                    type="text"
                    dir="ltr"
                    value={newLessonStorageKey}
                    onChange={(e) => setNewLessonStorageKey(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs font-mono-num bg-slate-50"
                  />
                </div>
                <button
                  onClick={async () => {
                    const ok = await runAdminAction({
                      action: "create_lesson",
                      courseId: Number(newLessonCourseId),
                      title: newLessonTitle,
                      durationMinutes: Number(newLessonDuration),
                      type: newLessonType,
                      storageKey: newLessonStorageKey,
                    });
                    if (ok) setNewLessonTitle("");
                  }}
                  className="w-full py-2.5 rounded-xl bg-[#F59E0B] hover:bg-amber-400 text-[#0F172A] text-xs font-bold transition"
                >
                  رفع المحاضرة وتأمين رابط الفيديو
                </button>
              </div>
            </div>

            {/* Courses & Lessons List */}
            <div className="lg:col-span-2 space-y-4">
              <div className="p-4 rounded-2xl bg-amber-50 border border-amber-200 flex items-center justify-between">
                <div>
                  <h4 className="font-heading font-bold text-sm text-amber-950">
                    هل تريد تعديل أسعار الكورسات والمدرسين دون لمس الكود؟
                  </h4>
                  <p className="text-xs text-amber-800">
                    يمكنك استخدام صفحة التحكم المخصصة للأسعار مع حفظ فوري
                  </p>
                </div>
                <Link
                  href="/admin/courses"
                  className="px-4 py-2 rounded-xl bg-[#0F172A] text-white text-xs font-bold shrink-0"
                >
                  الانتقال لصفحة الأسعار ←
                </Link>
              </div>

              {coursesList.map((crs) => {
                const crsSections = sectionsList.filter(
                  (s) => s.courseId === crs.id
                );
                const crsLessons = lessonsList.filter(
                  (l) => l.courseId === crs.id
                );
                return (
                  <div
                    key={crs.id}
                    className="bg-white rounded-2xl border border-slate-200 p-5 shadow-sm space-y-3"
                  >
                    <div className="flex items-center justify-between border-b border-slate-100 pb-3">
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-slate-900 text-[#F59E0B]">
                            {crs.type === "online"
                              ? "كورس أونلاين"
                              : crs.type === "center"
                              ? "محاضرات السنتر"
                              : "كورس مجاني"}
                          </span>
                          <h4 className="font-heading font-bold text-base text-slate-900">
                            {crs.title}
                          </h4>
                        </div>
                        <p className="text-xs text-slate-500 mt-1">
                          الأقسام: {crsSections.length} • المحاضرات:{" "}
                          {crsLessons.length} • السعر:{" "}
                          <span className="font-mono-num font-bold text-emerald-700">
                            {crs.price} ج.م
                          </span>
                        </p>
                      </div>
                      <button
                        onClick={() =>
                          runAdminAction({
                            action: "delete_item",
                            targetType: "course",
                            targetId: crs.id,
                          })
                        }
                        className="p-2 rounded-xl bg-red-50 hover:bg-red-100 text-red-600 transition"
                        title="حذف الكورس"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>

                    <div className="space-y-2">
                      {crsLessons.map((les) => (
                        <div
                          key={les.id}
                          className="p-3 rounded-xl bg-slate-50 border border-slate-200/80 flex items-center justify-between text-xs"
                        >
                          <div>
                            <div className="font-bold text-slate-800">
                              {les.title}
                            </div>
                            <div className="text-[11px] text-slate-500 mt-0.5">
                              المدة: {Math.round(les.durationSeconds / 60)} دقيقة
                              • النوع: {les.type} • المرفق:{" "}
                              {les.pdfTitle || "ملزمة PDF"}
                            </div>
                          </div>
                          <button
                            onClick={() =>
                              runAdminAction({
                                action: "delete_item",
                                targetType: "lesson",
                                targetId: les.id,
                              })
                            }
                            className="p-1.5 rounded-lg text-red-600 hover:bg-red-50 transition"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      ))}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* ====================================================
            TAB 3: PACKAGES CRUD
           ==================================================== */}
        {activeTab === "packages" && (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm space-y-3 h-fit">
              <h3 className="font-heading font-bold text-base text-[#0F172A] flex items-center gap-2">
                <Package className="w-5 h-5 text-[#F59E0B]" />
                إنشاء باقة دراسية جديدة
              </h3>
              <input
                type="text"
                value={newPkgTitle}
                onChange={(e) => setNewPkgTitle(e.target.value)}
                placeholder="اسم الباقة (مثال: باقة المراجعة النهائية الشاملة)"
                className="w-full px-3.5 py-2 rounded-xl border border-slate-300 text-xs"
              />
              <input
                type="text"
                value={newPkgSubtitle}
                onChange={(e) => setNewPkgSubtitle(e.target.value)}
                placeholder="وصف مختصر لمحتويات الباقة"
                className="w-full px-3.5 py-2 rounded-xl border border-slate-300 text-xs"
              />
              <div className="grid grid-cols-2 gap-2">
                <input
                  type="number"
                  value={newPkgPrice}
                  onChange={(e) => setNewPkgPrice(e.target.value)}
                  placeholder="السعر بعد الخصم"
                  className="w-full px-3.5 py-2 rounded-xl border border-slate-300 text-xs font-mono-num"
                />
                <input
                  type="number"
                  value={newPkgOriginalPrice}
                  onChange={(e) => setNewPkgOriginalPrice(e.target.value)}
                  placeholder="السعر قبل الخصم"
                  className="w-full px-3.5 py-2 rounded-xl border border-slate-300 text-xs font-mono-num"
                />
              </div>
              <input
                type="text"
                value={newPkgDuration}
                onChange={(e) => setNewPkgDuration(e.target.value)}
                placeholder="مدة الاشتراك (مثال: 3 شهور)"
                className="w-full px-3.5 py-2 rounded-xl border border-slate-300 text-xs"
              />
              <div className="space-y-1.5">
                <label className="block text-xs font-bold text-slate-700">
                  اختر الكورسات المشمولة داخل الباقة:
                </label>
                {coursesList.map((c) => (
                  <label
                    key={c.id}
                    className="flex items-center gap-2 text-xs text-slate-700 cursor-pointer"
                  >
                    <input
                      type="checkbox"
                      checked={newPkgCourseIds.includes(c.id)}
                      onChange={(e) => {
                        if (e.target.checked) {
                          setNewPkgCourseIds([...newPkgCourseIds, c.id]);
                        } else {
                          setNewPkgCourseIds(
                            newPkgCourseIds.filter((id) => id !== c.id)
                          );
                        }
                      }}
                      className="rounded accent-[#0F172A]"
                    />
                    <span>{c.title}</span>
                  </label>
                ))}
              </div>
              <button
                onClick={async () => {
                  const ok = await runAdminAction({
                    action: "create_package",
                    title: newPkgTitle,
                    subtitle: newPkgSubtitle,
                    price: Number(newPkgPrice),
                    originalPrice: Number(newPkgOriginalPrice),
                    durationLabel: newPkgDuration,
                    courseIds: newPkgCourseIds,
                  });
                  if (ok) {
                    setNewPkgTitle("");
                    setNewPkgSubtitle("");
                  }
                }}
                className="w-full py-2.5 rounded-xl bg-[#0F172A] hover:bg-slate-800 text-white text-xs font-bold transition"
              >
                نشر الباقة الدراسية
              </button>
            </div>

            <div className="lg:col-span-2 grid grid-cols-1 sm:grid-cols-2 gap-4">
              {packagesList.map((pkg) => (
                <div
                  key={pkg.id}
                  className="bg-white rounded-2xl border border-slate-200 p-5 shadow-sm flex flex-col justify-between space-y-4"
                >
                  <div>
                    <div className="flex items-center justify-between">
                      <span className="px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-amber-100 text-amber-900">
                        {pkg.durationLabel}
                      </span>
                      <button
                        onClick={() =>
                          runAdminAction({
                            action: "delete_item",
                            targetType: "package",
                            targetId: pkg.id,
                          })
                        }
                        className="text-red-500 hover:text-red-700"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                    <h4 className="font-heading font-bold text-base text-slate-900 mt-2">
                      {pkg.title}
                    </h4>
                    <p className="text-xs text-slate-500 mt-1">{pkg.subtitle}</p>
                    <div className="mt-3 space-y-1">
                      {pkg.items.map((it) => (
                        <div
                          key={it.id}
                          className="text-xs text-slate-700 bg-slate-50 px-2.5 py-1.5 rounded-lg border border-slate-200/70"
                        >
                          • {it.itemTitle}
                        </div>
                      ))}
                    </div>
                  </div>
                  <div className="pt-3 border-t border-slate-100 flex items-center justify-between">
                    <span className="text-xs text-slate-400 line-through font-mono-num">
                      {pkg.originalPrice} ج.م
                    </span>
                    <span className="font-mono-num text-lg font-extrabold text-[#0F172A]">
                      {pkg.price} ج.م
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* ====================================================
            TAB 4: QUIZZES & QUESTIONS CRUD
           ==================================================== */}
        {activeTab === "quizzes" && (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm space-y-3 h-fit">
              <h3 className="font-heading font-bold text-base text-[#0F172A] flex items-center gap-2">
                <FileQuestion className="w-5 h-5 text-[#F59E0B]" />
                إنشاء اختبار جديد مع سؤال متعدد الخيارات
              </h3>
              <select
                value={newQuizCourseId}
                onChange={(e) => setNewQuizCourseId(e.target.value)}
                className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs bg-white"
              >
                {coursesList.map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.title}
                  </option>
                ))}
              </select>
              <input
                type="text"
                value={newQuizTitle}
                onChange={(e) => setNewQuizTitle(e.target.value)}
                placeholder="عنوان الاختبار (مثال: امتحان الشهر الأول الشامل)"
                className="w-full px-3.5 py-2 rounded-xl border border-slate-300 text-xs"
              />
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="text-[10px] font-bold text-slate-500">
                    درجة النجاح (%)
                  </label>
                  <input
                    type="number"
                    value={newQuizPassScore}
                    onChange={(e) => setNewQuizPassScore(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs font-mono-num"
                  />
                </div>
                <div>
                  <label className="text-[10px] font-bold text-slate-500">
                    المدة (دقيقة)
                  </label>
                  <input
                    type="number"
                    value={newQuizDuration}
                    onChange={(e) => setNewQuizDuration(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs font-mono-num"
                  />
                </div>
              </div>

              <div className="pt-2 border-t border-slate-100 space-y-2">
                <label className="block text-xs font-bold text-slate-800">
                  السؤال الأول في الاختبار:
                </label>
                <textarea
                  rows={2}
                  value={newQuestionText}
                  onChange={(e) => setNewQuestionText(e.target.value)}
                  placeholder="اكتب نص السؤال النحوي أو البلاغي هنا..."
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs"
                />
                {newQuestionOptions.map((opt, idx) => (
                  <div key={idx} className="flex items-center gap-2">
                    <input
                      type="radio"
                      name="correctOpt"
                      checked={newQuestionCorrectIdx === idx}
                      onChange={() => setNewQuestionCorrectIdx(idx)}
                      className="accent-emerald-600"
                    />
                    <input
                      type="text"
                      value={opt}
                      onChange={(e) => {
                        const copy = [...newQuestionOptions];
                        copy[idx] = e.target.value;
                        setNewQuestionOptions(copy);
                      }}
                      placeholder={`الخيار ${idx + 1} ${
                        newQuestionCorrectIdx === idx ? "(الإجابة الصحيحة)" : ""
                      }`}
                      className="flex-1 px-3 py-1.5 rounded-lg border border-slate-300 text-xs"
                    />
                  </div>
                ))}
                <input
                  type="text"
                  value={newQuestionExplanation}
                  onChange={(e) => setNewQuestionExplanation(e.target.value)}
                  placeholder="تفسير الإجابة الصحيحة (يظهر للطالب في قسم أخطائي)"
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs"
                />
              </div>

              <button
                onClick={async () => {
                  const ok = await runAdminAction({
                    action: "create_quiz",
                    courseId: Number(newQuizCourseId),
                    title: newQuizTitle,
                    passingScore: Number(newQuizPassScore),
                    durationMinutes: Number(newQuizDuration),
                    questionText: newQuestionText,
                    explanation: newQuestionExplanation,
                    options: newQuestionOptions,
                    correctIndex: newQuestionCorrectIdx,
                  });
                  if (ok) {
                    setNewQuizTitle("");
                    setNewQuestionText("");
                    setNewQuestionOptions(["", "", "", ""]);
                  }
                }}
                className="w-full py-2.5 rounded-xl bg-[#0F172A] hover:bg-slate-800 text-white text-xs font-bold transition"
              >
                نشر الاختبار والأسئلة
              </button>
            </div>

            <div className="lg:col-span-2 space-y-4">
              {quizzesList.map((qz) => (
                <div
                  key={qz.id}
                  className="bg-white rounded-2xl border border-slate-200 p-5 shadow-sm space-y-3"
                >
                  <div className="flex items-center justify-between border-b border-slate-100 pb-3">
                    <div>
                      <h4 className="font-heading font-bold text-base text-slate-900">
                        {qz.title}
                      </h4>
                      <p className="text-xs text-slate-500">
                        الكورس: {qz.courseTitle} • درجة النجاح:{" "}
                        <span className="font-mono-num font-bold text-emerald-700">
                          {qz.passingScore}%
                        </span>{" "}
                        • المدة: {qz.durationMinutes} دقيقة • الأسئلة:{" "}
                        {qz.questions.length}
                      </p>
                    </div>
                    <button
                      onClick={() =>
                        runAdminAction({
                          action: "delete_item",
                          targetType: "quiz",
                          targetId: qz.id,
                        })
                      }
                      className="p-2 rounded-xl bg-red-50 hover:bg-red-100 text-red-600"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>

                  <div className="space-y-2">
                    {qz.questions.map((q, idx) => (
                      <div
                        key={q.id}
                        className="p-3 rounded-xl bg-slate-50 border border-slate-200/80 text-xs space-y-1.5"
                      >
                        <div className="font-bold text-slate-900">
                          س{idx + 1}: {q.questionText}
                        </div>
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-1.5">
                          {q.answers.map((ans) => (
                            <div
                              key={ans.id}
                              className={`px-2.5 py-1 rounded-lg border text-[11px] ${
                                ans.isCorrect
                                  ? "bg-emerald-50 border-emerald-300 text-emerald-800 font-bold"
                                  : "bg-white border-slate-200 text-slate-600"
                              }`}
                            >
                              {ans.answerText} {ans.isCorrect ? "✓" : ""}
                            </div>
                          ))}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* ====================================================
            TAB 5: COUPONS & PAYMENTS
           ==================================================== */}
        {activeTab === "coupons" && (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm space-y-4 h-fit">
              <h3 className="font-heading font-bold text-base text-[#0F172A] flex items-center gap-2">
                <TicketPercent className="w-5 h-5 text-[#F59E0B]" />
                إنشاء كوبون خصم جديد
              </h3>
              <input
                type="text"
                dir="ltr"
                value={newCouponCode}
                onChange={(e) => setNewCouponCode(e.target.value.toUpperCase())}
                placeholder="CODE (مثال: RAMADAN40)"
                className="w-full px-3.5 py-2 rounded-xl border border-slate-300 text-xs font-mono-num uppercase"
              />
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="text-[10px] font-bold text-slate-500">
                    نسبة الخصم (%)
                  </label>
                  <input
                    type="number"
                    value={newCouponDiscount}
                    onChange={(e) => setNewCouponDiscount(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs font-mono-num"
                  />
                </div>
                <div>
                  <label className="text-[10px] font-bold text-slate-500">
                    الحد الأقصى للاستخدام
                  </label>
                  <input
                    type="number"
                    value={newCouponMaxUses}
                    onChange={(e) => setNewCouponMaxUses(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs font-mono-num"
                  />
                </div>
              </div>
              <button
                onClick={async () => {
                  const ok = await runAdminAction({
                    action: "create_coupon",
                    code: newCouponCode,
                    discountPercent: Number(newCouponDiscount),
                    maxUses: Number(newCouponMaxUses),
                  });
                  if (ok) setNewCouponCode("");
                }}
                className="w-full py-2.5 rounded-xl bg-[#0F172A] hover:bg-slate-800 text-white text-xs font-bold transition"
              >
                إصدار الكوبون فوراً
              </button>

              <div className="pt-4 border-t border-slate-100 space-y-2">
                <h4 className="text-xs font-bold text-slate-700">
                  الكوبونات الفعالة حالياً:
                </h4>
                {couponsList.map((cp) => (
                  <div
                    key={cp.id}
                    className="p-3 rounded-xl bg-slate-50 border border-slate-200 flex items-center justify-between text-xs"
                  >
                    <div>
                      <span className="font-mono-num font-extrabold text-[#0F172A] bg-amber-100 px-2 py-0.5 rounded">
                        {cp.code}
                      </span>
                      <span className="mr-2 font-bold text-emerald-700">
                        خصم {cp.discountPercent}%
                      </span>
                      <div className="text-[11px] text-slate-500 mt-1">
                        استُخدم {cp.usedCount} من {cp.maxUses}
                      </div>
                    </div>
                    <button
                      onClick={() =>
                        runAdminAction({
                          action: "delete_item",
                          targetType: "coupon",
                          targetId: cp.id,
                        })
                      }
                      className="text-red-500 hover:text-red-700"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                ))}
              </div>
            </div>

            {/* Paymob Payments Table */}
            <div className="lg:col-span-2 bg-white rounded-2xl border border-slate-200 p-5 shadow-sm space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="font-heading font-bold text-base text-[#0F172A]">
                  سجل معاملات بوابات الدفع والتحويلات
                </h3>
                <Link
                  href="/admin/payments"
                  className="px-3 py-1.5 rounded-xl bg-emerald-600 text-white text-xs font-bold flex items-center gap-1"
                >
                  فتح صفحة مراجعة التحويلات ←
                </Link>
              </div>
              <div className="overflow-x-auto">
                <table className="w-full text-right text-xs border-collapse">
                  <thead>
                    <tr className="bg-slate-100 text-slate-700">
                      <th className="p-3">الطالب</th>
                      <th className="p-3">المبلغ</th>
                      <th className="p-3">وسيلة الدفع</th>
                      <th className="p-3">رقم الطلب / المرجع</th>
                      <th className="p-3">الحالة</th>
                      <th className="p-3">التاريخ</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-200">
                    {paymentsList.map((p) => (
                      <tr key={p.id}>
                        <td className="p-3">
                          <div className="font-bold text-slate-900">
                            {p.studentName}
                          </div>
                          <div className="font-mono-num text-[11px] text-slate-500">
                            {p.studentPhone}
                          </div>
                        </td>
                        <td className="p-3 font-mono-num font-extrabold text-emerald-700">
                          {p.amount} ج.م
                        </td>
                        <td className="p-3 font-bold">
                          {p.method === "instapay"
                            ? "InstaPay"
                            : p.method === "vodafone_cash"
                            ? "فودافون كاش"
                            : p.method === "fawry_pay"
                            ? "فوري باي"
                            : p.method === "visa_mastercard"
                            ? "بطاقة بنكية Visa/MC"
                            : "محفظة المنصة"}
                        </td>
                        <td className="p-3 font-mono-num text-slate-700">
                          {p.paymobOrderId}
                        </td>
                        <td className="p-3">
                          <span
                            className={`px-2 py-0.5 rounded-full font-bold text-[10px] ${
                              p.status === "paid"
                                ? "bg-emerald-50 text-emerald-700 border border-emerald-200"
                                : "bg-amber-50 text-amber-800 border border-amber-200"
                            }`}
                          >
                            {p.status === "paid" ? "مدفوع ✓" : "قيد المراجعة"}
                          </span>
                        </td>
                        <td className="p-3 font-mono-num text-slate-500">
                          {new Date(p.createdAt).toLocaleDateString("ar-EG")}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* ====================================================
            TAB 6: ADMIN AUDIT LOGS
           ==================================================== */}
        {activeTab === "audit" && (
          <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-sm space-y-4">
            <div>
              <h3 className="font-heading font-bold text-lg text-[#0F172A]">
                سجل العمليات الإدارية والأمنية (Audit Logs)
              </h3>
              <p className="text-xs text-slate-500">
                توثيق غير قابل للتلاعب لكافة عمليات الحظر، منح الصلاحيات، تعديل
                بيانات الطلاب، وإدارة المحتوى.
              </p>
            </div>
            <div className="space-y-3">
              {auditLogsList.map((log) => (
                <div
                  key={log.id}
                  className="p-4 rounded-xl bg-slate-50 border border-slate-200 flex flex-wrap items-center justify-between gap-4"
                >
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <span className="px-2.5 py-0.5 rounded-md bg-[#0F172A] text-[#F59E0B] text-[11px] font-bold">
                        {log.action}
                      </span>
                      <span className="text-xs font-bold text-slate-700">
                        بواسطة: {log.adminName}
                      </span>
                    </div>
                    <p className="text-xs text-slate-600">{log.details}</p>
                  </div>
                  <div className="text-left font-mono-num text-[11px] text-slate-500">
                    <div>
                      Target: {log.targetType} #{log.targetId}
                    </div>
                    <div>
                      {new Date(log.createdAt).toLocaleString("ar-EG")}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* ====================================================
            TAB 7: DEVOPS, .ENV.EXAMPLE, SEED & PRODUCTION GUIDE
           ==================================================== */}
        {activeTab === "devops" && (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-sm space-y-4">
              <h3 className="font-heading font-bold text-lg text-[#0F172A] flex items-center gap-2">
                <Terminal className="w-5 h-5 text-[#F59E0B]" />
                ملف المتغيرات البيئية (.env.example)
              </h3>
              <pre
                dir="ltr"
                className="p-4 rounded-xl bg-[#0F172A] text-emerald-300 font-mono-num text-xs overflow-x-auto leading-relaxed"
              >
{`# 1. Database Connection (PostgreSQL)
DATABASE_URL="postgresql://postgres:postgres@127.0.0.1:5432/app_db"

# 2. Authentication & Session Security (HMAC / Bcrypt)
AUTH_SECRET="albayan-super-secret-jwt-hmac-key-2026-production-ready"

# 3. Egyptian Payment Gateways (Paymob: Vodafone Cash, Fawry, Cards)
PAYMENT_SECRET_KEY="paymob_sk_live_egypt_integration_9f8e7d6c5b4a3"
PAYMENT_WEBHOOK_SECRET="paymob_hmac_secret_sha512_webhook_verifier_2026"

# 4. Private Video Storage (Cloudflare R2 / AWS S3 Signed URLs)
VIDEO_STORAGE_PROVIDER="cloudflare_r2"
VIDEO_STORAGE_ENDPOINT="https://a1b2c3d4e5f6.r2.cloudflarestorage.com"
VIDEO_STORAGE_BUCKET="albayan-private-videos"
VIDEO_STORAGE_ACCESS_KEY="R2_ACCESS_KEY_ID_PRIVATE_2026"
VIDEO_STORAGE_SECRET_KEY="R2_SECRET_ACCESS_KEY_PRIVATE_SIGNING_2026"
VIDEO_SIGNED_URL_TTL_SECONDS="900"`}
              </pre>
            </div>

            <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-sm space-y-4">
              <h3 className="font-heading font-bold text-lg text-[#0F172A]">
                أوامر التشغيل والـ Seed والربط مع GitHub للإنتاج
              </h3>
              <div className="space-y-3 text-xs text-slate-700">
                <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200">
                  <div className="font-bold text-slate-900 mb-1">
                    1. دفع الجداول وتوليد البيانات الأولية (Seed):
                  </div>
                  <code
                    dir="ltr"
                    className="block bg-slate-900 text-amber-300 p-2.5 rounded-lg font-mono-num"
                  >
                    npx drizzle-kit push && curl -s http://localhost:3000/api/auth
                  </code>
                </div>

                <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200">
                  <div className="font-bold text-slate-900 mb-1">
                    2. بيانات حساب الأدمن الافتراضي وحساب الطالب التجريبي:
                  </div>
                  <p>
                    • <strong>حساب الأدمن:</strong> الهاتف{" "}
                    <code className="font-mono-num font-bold">01000000001</code>{" "}
                    | كلمة المرور:{" "}
                    <code className="font-mono-num font-bold">Admin@2026</code>
                  </p>
                  <p className="mt-1">
                    • <strong>حساب الطالب:</strong> الهاتف{" "}
                    <code className="font-mono-num font-bold">01012345678</code>{" "}
                    | كلمة المرور:{" "}
                    <code className="font-mono-num font-bold">Student@2026</code>
                  </p>
                </div>
              </div>
            </div>
          </div>
        )}
      </main>

      {/* Modal: Edit Student Details */}
      {editingStudent && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/75 backdrop-blur-sm p-4">
          <div className="bg-white w-full max-w-md rounded-2xl shadow-2xl border border-slate-200 overflow-hidden">
            <div className="bg-[#0F172A] text-white px-5 py-4 flex items-center justify-between">
              <h3 className="font-heading font-bold text-sm">
                تعديل بيانات الطالب: {editingStudent.tripleName}
              </h3>
              <button onClick={() => setEditingStudent(null)}>
                <X className="w-4 h-4" />
              </button>
            </div>
            <div className="p-5 space-y-3 text-xs">
              <div>
                <label className="font-bold text-slate-700 block mb-1">
                  الاسم الثلاثي
                </label>
                <input
                  type="text"
                  value={editingStudent.tripleName}
                  onChange={(e) =>
                    setEditingStudent({
                      ...editingStudent,
                      tripleName: e.target.value,
                    })
                  }
                  className="w-full px-3 py-2 rounded-xl border border-slate-300"
                />
              </div>
              <div>
                <label className="font-bold text-slate-700 block mb-1">
                  رقم هاتف الطالب
                </label>
                <input
                  type="text"
                  dir="ltr"
                  value={editingStudent.studentPhone}
                  onChange={(e) =>
                    setEditingStudent({
                      ...editingStudent,
                      studentPhone: e.target.value,
                    })
                  }
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 font-mono-num"
                />
              </div>
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="font-bold text-slate-700 block mb-1">
                    رقم ولي الأمر
                  </label>
                  <input
                    type="text"
                    dir="ltr"
                    value={editingStudent.guardianPhone}
                    onChange={(e) =>
                      setEditingStudent({
                        ...editingStudent,
                        guardianPhone: e.target.value,
                      })
                    }
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 font-mono-num"
                  />
                </div>
                <div>
                  <label className="font-bold text-slate-700 block mb-1">
                    رقم الأم
                  </label>
                  <input
                    type="text"
                    dir="ltr"
                    value={editingStudent.motherPhone}
                    onChange={(e) =>
                      setEditingStudent({
                        ...editingStudent,
                        motherPhone: e.target.value,
                      })
                    }
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 font-mono-num"
                  />
                </div>
              </div>
              <div>
                <label className="font-bold text-slate-700 block mb-1">
                  رصيد المحفظة (ج.م)
                </label>
                <input
                  type="number"
                  value={editingStudent.walletBalance}
                  onChange={(e) =>
                    setEditingStudent({
                      ...editingStudent,
                      walletBalance: Number(e.target.value),
                    })
                  }
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 font-mono-num"
                />
              </div>
              <button
                onClick={async () => {
                  const ok = await runAdminAction({
                    action: "update_student",
                    studentId: editingStudent.id,
                    tripleName: editingStudent.tripleName,
                    studentPhone: editingStudent.studentPhone,
                    guardianPhone: editingStudent.guardianPhone,
                    motherPhone: editingStudent.motherPhone,
                    walletBalance: editingStudent.walletBalance,
                    gradeLevel: editingStudent.gradeLevel,
                  });
                  if (ok) setEditingStudent(null);
                }}
                className="w-full py-2.5 rounded-xl bg-[#0F172A] text-white font-bold"
              >
                حفظ التعديلات
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Modal: Grant Manual Course/Package Access */}
      {grantModalStudent && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/75 backdrop-blur-sm p-4">
          <div className="bg-white w-full max-w-md rounded-2xl shadow-2xl border border-slate-200 overflow-hidden">
            <div className="bg-[#0F172A] text-white px-5 py-4 flex items-center justify-between">
              <h3 className="font-heading font-bold text-sm">
                منح صلاحية وصول يدوي للطالب: {grantModalStudent.tripleName}
              </h3>
              <button onClick={() => setGrantModalStudent(null)}>
                <X className="w-4 h-4" />
              </button>
            </div>
            <div className="p-5 space-y-4 text-xs">
              <div>
                <label className="font-bold text-slate-700 block mb-1">
                  اختر الكورس المراد فتحه للطالب:
                </label>
                <select
                  value={selectedGrantCourseId}
                  onChange={(e) => setSelectedGrantCourseId(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 bg-white"
                >
                  <option value="">-- بدون كورس منفرد --</option>
                  {coursesList.map((c) => (
                    <option key={c.id} value={c.id}>
                      {c.title}
                    </option>
                  ))}
                </select>
              </div>
              <div>
                <label className="font-bold text-slate-700 block mb-1">
                  أو اختر باقة كاملة لفتحها للطالب:
                </label>
                <select
                  value={selectedGrantPkgId}
                  onChange={(e) => setSelectedGrantPkgId(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 bg-white"
                >
                  <option value="">-- بدون باقة --</option>
                  {packagesList.map((p) => (
                    <option key={p.id} value={p.id}>
                      {p.title}
                    </option>
                  ))}
                </select>
              </div>
              <button
                onClick={async () => {
                  const ok = await runAdminAction({
                    action: "grant_access",
                    studentId: grantModalStudent.id,
                    courseId: selectedGrantCourseId
                      ? Number(selectedGrantCourseId)
                      : null,
                    packageId: selectedGrantPkgId
                      ? Number(selectedGrantPkgId)
                      : null,
                  });
                  if (ok) setGrantModalStudent(null);
                }}
                className="w-full py-2.5 rounded-xl bg-[#F59E0B] text-[#0F172A] font-bold"
              >
                تفعيل الصلاحية فوراً وتسجيلها في Audit Log
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
