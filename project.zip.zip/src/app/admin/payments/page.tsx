"use client";

import React, { useEffect, useState, useCallback } from "react";
import Link from "next/link";
import {
  CreditCard,
  CheckCircle2,
  XCircle,
  Eye,
  Clock,
  Phone,
  User,
  ShieldCheck,
  Search,
  Filter,
  DollarSign,
  ArrowRight,
  ExternalLink,
  Sparkles,
  RefreshCw,
  Image as ImageIcon,
  X,
} from "lucide-react";

interface PaymentRow {
  id: number;
  userId: number;
  studentName: string;
  studentPhone: string;
  guardianPhone: string;
  itemTitle: string;
  itemType: string;
  amount: number;
  currency: string;
  method: string;
  status: "paid" | "pending" | "rejected" | "failed";
  paymentType: "automated" | "direct_transfer";
  paymobOrderId: string;
  referenceCode: string | null;
  senderPhone: string | null;
  senderName: string | null;
  receiptUrl: string | null;
  transferNote: string | null;
  reviewedAt: string | null;
  rejectionReason: string | null;
  createdAt: string;
}

export default function AdminPaymentsReviewPage() {
  const [payments, setPayments] = useState<PaymentRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [toast, setToast] = useState<string | null>(null);
  const [statusFilter, setStatusFilter] = useState<"all" | "pending" | "paid" | "rejected">("pending");
  const [searchQuery, setSearchQuery] = useState("");

  // Inspect Modal
  const [inspectingPayment, setInspectingPayment] = useState<PaymentRow | null>(null);
  const [rejectReason, setRejectReason] = useState("");
  const [isRejecting, setIsRejecting] = useState(false);

  const showToast = (msg: string) => {
    setToast(msg);
    setTimeout(() => setToast(null), 4000);
  };

  const fetchPayments = useCallback(async () => {
    setLoading(true);
    try {
      const res = await fetch("/api/admin/payments");
      const data = await res.json();
      if (res.ok) {
        setPayments(data.payments || []);
      }
    } catch {
      showToast("تعذر تحميل سجل المدفوعات");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchPayments();
  }, [fetchPayments]);

  const handleApprove = async (paymentId: number) => {
    try {
      const res = await fetch("/api/admin/payments", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action: "approve", paymentId }),
      });
      const data = await res.json();
      if (!res.ok) {
        showToast(data.error || "تعذر تفعيل الاشتراك");
      } else {
        showToast(data.message);
        setInspectingPayment(null);
        fetchPayments();
      }
    } catch {
      showToast("حدث خطأ أثناء الموافقة على التحويل");
    }
  };

  const handleReject = async (paymentId: number) => {
    try {
      const res = await fetch("/api/admin/payments", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          action: "reject",
          paymentId,
          reason: rejectReason || "الإشعار غير متطابق مع رصيد الحساب",
        }),
      });
      const data = await res.json();
      if (!res.ok) {
        showToast(data.error || "تعذر رفض الطلب");
      } else {
        showToast(data.message);
        setInspectingPayment(null);
        setIsRejecting(false);
        setRejectReason("");
        fetchPayments();
      }
    } catch {
      showToast("حدث خطأ أثناء رفض الطلب");
    }
  };

  const filtered = payments.filter((p) => {
    const matchesStatus =
      statusFilter === "all" ? true : p.status === statusFilter;
    const q = searchQuery.trim().toLowerCase();
    if (!q) return matchesStatus;
    return (
      matchesStatus &&
      (p.studentName.toLowerCase().includes(q) ||
        p.studentPhone.includes(q) ||
        (p.senderPhone && p.senderPhone.includes(q)) ||
        (p.referenceCode && p.referenceCode.toLowerCase().includes(q)) ||
        p.itemTitle.toLowerCase().includes(q))
    );
  });

  const pendingCount = payments.filter((p) => p.status === "pending").length;

  return (
    <div className="min-h-screen bg-[#F8FAFC] text-[#0F172A] pb-20">
      {/* Toast Notification */}
      {toast && (
        <div className="fixed top-5 left-1/2 -translate-x-1/2 z-50 bg-[#0F172A] text-white px-5 py-3 rounded-2xl shadow-2xl border border-[#F59E0B] flex items-center gap-2 text-xs sm:text-sm font-bold">
          <Sparkles className="w-4 h-4 text-[#F59E0B]" />
          <span>{toast}</span>
        </div>
      )}

      {/* Top Header */}
      <header className="bg-[#0F172A] text-white border-b border-slate-800 sticky top-0 z-40">
        <div className="max-w-[1400px] mx-auto px-4 sm:px-8 py-4 flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-500 text-[#0F172A] flex items-center justify-center font-bold">
              <CreditCard className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="font-heading text-lg sm:text-xl font-bold">
                  مراجعة طلبات الدفع والتحويل المباشر (/admin/payments)
                </h1>
                {pendingCount > 0 && (
                  <span className="px-2.5 py-0.5 rounded-full bg-amber-500 text-[#0F172A] text-xs font-bold animate-pulse">
                    {pendingCount} طلب معلق
                  </span>
                )}
              </div>
              <p className="text-xs text-slate-300">
                فحص إشعارات التحويل عبر InstaPay وفودافون كاش والموافقة بنقرة واحدة
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2.5">
            <Link
              href="/admin/courses"
              className="px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold transition flex items-center gap-1.5"
            >
              <DollarSign className="w-3.5 h-3.5 text-amber-400" />
              <span>التحكم بالأسعار والمدرسين</span>
            </Link>
            <Link
              href="/admin/students"
              className="px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold transition flex items-center gap-1.5"
            >
              <ShieldCheck className="w-3.5 h-3.5 text-amber-400" />
              <span>لوحة الطلاب</span>
            </Link>
            <Link
              href="/"
              className="px-4 py-2 rounded-xl bg-[#F59E0B] text-[#0F172A] font-bold text-xs transition"
            >
              منصة الطالب ←
            </Link>
          </div>
        </div>
      </header>

      <main className="max-w-[1400px] mx-auto px-4 sm:px-8 pt-6 space-y-6">
        {/* Filter & Search Bar */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm flex flex-wrap items-center justify-between gap-4">
          <div className="flex flex-wrap items-center gap-2">
            {[
              { id: "pending", label: `طلبات معلقة للمراجعة (${pendingCount})` },
              { id: "paid", label: "مدفوع ومفعل ✓" },
              { id: "rejected", label: "مرفوض ✗" },
              { id: "all", label: `جميع المعاملات (${payments.length})` },
            ].map((f) => (
              <button
                key={f.id}
                onClick={() =>
                  setStatusFilter(
                    f.id as "all" | "pending" | "paid" | "rejected"
                  )
                }
                className={`px-4 py-2 rounded-xl text-xs font-bold transition ${
                  statusFilter === f.id
                    ? "bg-[#0F172A] text-white shadow"
                    : "bg-slate-100 text-slate-700 hover:bg-slate-200"
                }`}
              >
                {f.label}
              </button>
            ))}
          </div>

          <div className="flex items-center gap-3 w-full sm:w-auto">
            <div className="relative flex-1 sm:w-72">
              <Search className="w-4 h-4 text-slate-400 absolute right-3 top-2.5" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="ابحث بالطالب أو رقم المرسل..."
                className="w-full pr-9 pl-3 py-1.5 rounded-xl border border-slate-300 text-xs"
              />
            </div>
            <button
              onClick={fetchPayments}
              className="p-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700"
              title="تحديث"
            >
              <RefreshCw className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Payments Table */}
        <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-right text-xs border-collapse">
              <thead>
                <tr className="bg-[#0F172A] text-white font-heading">
                  <th className="p-3.5">الطالب</th>
                  <th className="p-3.5">المحتوى المطلوب</th>
                  <th className="p-3.5">المبلغ</th>
                  <th className="p-3.5">طريقة الدفع والنوع</th>
                  <th className="p-3.5">بيانات المرسل والإشعار</th>
                  <th className="p-3.5">الحالة</th>
                  <th className="p-3.5">التاريخ</th>
                  <th className="p-3.5 text-center">الإجراء الفوري</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200">
                {loading ? (
                  <tr>
                    <td colSpan={8} className="p-8 text-center text-slate-500 font-bold">
                      جاري تحميل المعاملات...
                    </td>
                  </tr>
                ) : filtered.length === 0 ? (
                  <tr>
                    <td colSpan={8} className="p-8 text-center text-slate-500 font-bold">
                      لا توجد طلبات دفع مطابقة للفلتر الحالي.
                    </td>
                  </tr>
                ) : (
                  filtered.map((p) => (
                    <tr
                      key={p.id}
                      className={`hover:bg-slate-50 transition ${
                        p.status === "pending" ? "bg-amber-50/30" : ""
                      }`}
                    >
                      {/* Student info */}
                      <td className="p-3.5">
                        <div className="font-bold text-slate-900 text-sm">
                          {p.studentName}
                        </div>
                        <div
                          dir="ltr"
                          className="font-mono-num text-[11px] text-slate-500 text-right"
                        >
                          {p.studentPhone}
                        </div>
                      </td>

                      {/* Item */}
                      <td className="p-3.5 max-w-[200px]">
                        <span className="font-bold text-slate-900 line-clamp-1">
                          {p.itemTitle}
                        </span>
                        <span className="text-[10px] text-slate-500">
                          {p.itemType === "package" ? "باقة دراسية" : "كورس فردي"}
                        </span>
                      </td>

                      {/* Amount */}
                      <td className="p-3.5 font-mono-num text-sm font-extrabold text-emerald-700">
                        {p.amount} ج.م
                      </td>

                      {/* Method */}
                      <td className="p-3.5">
                        <div className="font-bold text-slate-800">
                          {p.method === "instapay"
                            ? "تحويل إنستاباي InstaPay"
                            : p.method === "vodafone_cash"
                            ? "فودافون كاش"
                            : p.method === "fawry_pay"
                            ? "فوري باي"
                            : p.method === "visa_mastercard"
                            ? "بطاقة فيزا/ماستركارد"
                            : "محفظة المنصة"}
                        </div>
                        <span
                          className={`text-[10px] font-bold px-2 py-0.5 rounded-md inline-block mt-0.5 ${
                            p.paymentType === "direct_transfer"
                              ? "bg-purple-100 text-purple-900"
                              : "bg-blue-100 text-blue-900"
                          }`}
                        >
                          {p.paymentType === "direct_transfer"
                            ? "تحويل يدوي بإشعار"
                            : "دفع آلي Paymob"}
                        </span>
                      </td>

                      {/* Transfer Sender & Receipt Proof */}
                      <td className="p-3.5">
                        {p.senderPhone && (
                          <div dir="ltr" className="font-mono-num text-xs font-bold text-slate-800 text-right">
                            من: {p.senderPhone}
                          </div>
                        )}
                        {p.referenceCode && (
                          <div className="text-[11px] text-slate-500 font-mono-num truncate max-w-[140px]">
                            مرجع: {p.referenceCode}
                          </div>
                        )}
                        {p.receiptUrl && (
                          <button
                            onClick={() => setInspectingPayment(p)}
                            className="inline-flex items-center gap-1 text-[11px] font-bold text-purple-700 hover:text-purple-900 mt-1 underline"
                          >
                            <ImageIcon className="w-3.5 h-3.5" />
                            معاينة صورة الإشعار
                          </button>
                        )}
                      </td>

                      {/* Status */}
                      <td className="p-3.5">
                        {p.status === "paid" ? (
                          <span className="px-2.5 py-1 rounded-full bg-emerald-100 text-emerald-800 font-bold text-[11px] flex items-center gap-1 w-fit">
                            <CheckCircle2 className="w-3.5 h-3.5" /> تم التفعيل
                          </span>
                        ) : p.status === "pending" ? (
                          <span className="px-2.5 py-1 rounded-full bg-amber-100 text-amber-900 font-bold text-[11px] flex items-center gap-1 w-fit">
                            <Clock className="w-3.5 h-3.5" /> قيد المراجعة
                          </span>
                        ) : (
                          <span className="px-2.5 py-1 rounded-full bg-red-100 text-red-800 font-bold text-[11px] flex items-center gap-1 w-fit">
                            <XCircle className="w-3.5 h-3.5" /> مرفوض
                          </span>
                        )}
                      </td>

                      {/* Date */}
                      <td className="p-3.5 font-mono-num text-slate-500">
                        {new Date(p.createdAt).toLocaleDateString("ar-EG")}
                      </td>

                      {/* Actions */}
                      <td className="p-3.5 text-center">
                        {p.status === "pending" ? (
                          <div className="flex items-center justify-center gap-1.5">
                            <button
                              onClick={() => handleApprove(p.id)}
                              className="px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs flex items-center gap-1 shadow-sm transition"
                              title="الموافقة الفورية وتفعيل الكورس للطالب"
                            >
                              <CheckCircle2 className="w-3.5 h-3.5" />
                              موافقة وتفعيل
                            </button>
                            <button
                              onClick={() => {
                                setInspectingPayment(p);
                                setIsRejecting(true);
                              }}
                              className="px-2.5 py-1.5 rounded-xl bg-red-100 hover:bg-red-200 text-red-700 font-bold text-xs transition"
                              title="رفض الطلب"
                            >
                              رفض
                            </button>
                          </div>
                        ) : (
                          <button
                            onClick={() => setInspectingPayment(p)}
                            className="p-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold inline-flex items-center gap-1"
                          >
                            <Eye className="w-3.5 h-3.5" /> تفاصيل
                          </button>
                        )}
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      </main>

      {/* Inspect / Receipt Proof Modal */}
      {inspectingPayment && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/80 backdrop-blur-sm p-4 overflow-y-auto">
          <div className="bg-white w-full max-w-lg rounded-2xl shadow-2xl border border-slate-200 overflow-hidden my-auto">
            <div className="bg-[#0F172A] text-white px-5 py-4 flex items-center justify-between">
              <div>
                <span className="text-xs font-bold text-[#F59E0B]">
                  طلب دفع #{inspectingPayment.id}
                </span>
                <h3 className="font-heading font-bold text-base">
                  {inspectingPayment.studentName} — {inspectingPayment.itemTitle}
                </h3>
              </div>
              <button
                onClick={() => {
                  setInspectingPayment(null);
                  setIsRejecting(false);
                }}
                className="p-1.5 rounded-lg bg-slate-800 text-slate-300 hover:text-white"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="p-5 space-y-4 text-xs">
              <div className="grid grid-cols-2 gap-3 p-3.5 rounded-xl bg-slate-50 border border-slate-200">
                <div>
                  <span className="text-slate-500 block">المبلغ المطلوب:</span>
                  <span className="font-mono-num font-extrabold text-base text-emerald-700">
                    {inspectingPayment.amount} ج.م
                  </span>
                </div>
                <div>
                  <span className="text-slate-500 block">طريقة التحويل:</span>
                  <span className="font-bold text-slate-800">
                    {inspectingPayment.method === "instapay"
                      ? "InstaPay"
                      : "فودافون كاش"}
                  </span>
                </div>
                <div>
                  <span className="text-slate-500 block">رقم هاتف الطالب:</span>
                  <span dir="ltr" className="font-mono-num font-bold text-slate-900 block text-right">
                    {inspectingPayment.studentPhone}
                  </span>
                </div>
                <div>
                  <span className="text-slate-500 block">الرقم المحول منه:</span>
                  <span dir="ltr" className="font-mono-num font-bold text-purple-900 block text-right">
                    {inspectingPayment.senderPhone || "غير محدد"}
                  </span>
                </div>
              </div>

              {inspectingPayment.transferNote && (
                <div className="p-3 rounded-xl bg-purple-50 border border-purple-200 text-purple-950">
                  <strong>ملاحظة الطالب:</strong> {inspectingPayment.transferNote}
                </div>
              )}

              {/* Receipt Image Proof */}
              <div>
                <label className="font-bold text-slate-800 block mb-1.5">
                  صورة إشعار التحويل المرفقة من الطالب:
                </label>
                {inspectingPayment.receiptUrl ? (
                  <div className="border border-slate-200 rounded-xl overflow-hidden bg-slate-100 max-h-64 flex items-center justify-center">
                    {/* eslint-disable-next-line @next/next/no-img-element */}
                    <img
                      src={inspectingPayment.receiptUrl}
                      alt="إشعار التحويل"
                      className="object-contain w-full h-full max-h-64"
                    />
                  </div>
                ) : (
                  <div className="p-6 text-center text-slate-400 bg-slate-50 rounded-xl border border-dashed">
                    لم يرفق الطالب صورة
                  </div>
                )}
              </div>

              {/* Reject Reason input if active */}
              {isRejecting ? (
                <div className="space-y-2 pt-2 border-t border-slate-200">
                  <label className="font-bold text-red-700 block">
                    سبب الرفض (يظهر للطالب):
                  </label>
                  <input
                    type="text"
                    value={rejectReason}
                    onChange={(e) => setRejectReason(e.target.value)}
                    placeholder="مثال: الإشعار غير واضح أو لم يصل التحويل على الرقم"
                    className="w-full px-3 py-2 rounded-xl border border-red-300 text-xs"
                  />
                  <div className="flex gap-2">
                    <button
                      onClick={() => handleReject(inspectingPayment.id)}
                      className="flex-1 py-2 rounded-xl bg-red-600 hover:bg-red-500 text-white font-bold"
                    >
                      تأكيد الرفض
                    </button>
                    <button
                      onClick={() => setIsRejecting(false)}
                      className="px-4 py-2 rounded-xl bg-slate-200 text-slate-700 font-bold"
                    >
                      إلغاء
                    </button>
                  </div>
                </div>
              ) : (
                inspectingPayment.status === "pending" && (
                  <div className="flex gap-2 pt-3 border-t border-slate-200">
                    <button
                      onClick={() => handleApprove(inspectingPayment.id)}
                      className="flex-1 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs flex items-center justify-center gap-1.5 shadow"
                    >
                      <CheckCircle2 className="w-4 h-4" />
                      الموافقة وتفعيل الكورس للطالب فوراً
                    </button>
                    <button
                      onClick={() => setIsRejecting(true)}
                      className="px-4 py-2.5 rounded-xl bg-red-100 hover:bg-red-200 text-red-700 font-bold text-xs"
                    >
                      رفض الطلب
                    </button>
                  </div>
                )
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
