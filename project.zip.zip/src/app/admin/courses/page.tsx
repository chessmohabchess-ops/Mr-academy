"use client";

import React, { useEffect, useState, useCallback } from "react";
import Link from "next/link";
import {
  BookOpen,
  DollarSign,
  User,
  Edit3,
  Check,
  X,
  Package,
  Layers,
  ArrowRight,
  PlusCircle,
  Trash2,
  Sparkles,
  RefreshCw,
  ShieldAlert,
} from "lucide-react";

interface CourseItem {
  id: number;
  title: string;
  slug: string;
  description: string;
  subject: string;
  gradeLevel: string;
  instructorName: string;
  price: number;
  type: string;
  published: boolean;
}

interface PackageItem {
  id: number;
  title: string;
  subtitle: string;
  description: string;
  price: number;
  originalPrice: number;
  badge: string;
  durationLabel: string;
  published: boolean;
}

export default function AdminCoursesPricingPage() {
  const [courses, setCourses] = useState<CourseItem[]>([]);
  const [packages, setPackages] = useState<PackageItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [toast, setToast] = useState<string | null>(null);

  // Editing state for courses
  const [editingCourseId, setEditingCourseId] = useState<number | null>(null);
  const [courseForm, setCourseForm] = useState<{
    title: string;
    instructorName: string;
    subject: string;
    description: string;
    price: number;
    type: string;
    gradeLevel: string;
  }>({
    title: "",
    instructorName: "",
    subject: "",
    description: "",
    price: 0,
    type: "online",
    gradeLevel: "الصف الثالث الثانوي",
  });

  // Editing state for packages
  const [editingPkgId, setEditingPkgId] = useState<number | null>(null);
  const [pkgForm, setPkgForm] = useState<{
    title: string;
    subtitle: string;
    description: string;
    price: number;
    originalPrice: number;
    durationLabel: string;
  }>({
    title: "",
    subtitle: "",
    description: "",
    price: 0,
    originalPrice: 0,
    durationLabel: "",
  });

  const showToast = (msg: string) => {
    setToast(msg);
    setTimeout(() => setToast(null), 4000);
  };

  const fetchData = useCallback(async () => {
    setLoading(true);
    try {
      const res = await fetch("/api/admin/courses");
      const data = await res.json();
      if (res.ok) {
        setCourses(data.courses || []);
        setPackages(data.packages || []);
      }
    } catch {
      showToast("تعذر تحميل بيانات الكورسات والأسعار");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchData();
  }, [fetchData]);

  const handleStartEditCourse = (c: CourseItem) => {
    setEditingCourseId(c.id);
    setCourseForm({
      title: c.title,
      instructorName: c.instructorName,
      subject: c.subject,
      description: c.description,
      price: c.price,
      type: c.type,
      gradeLevel: c.gradeLevel,
    });
  };

  const handleSaveCourse = async (courseId: number) => {
    try {
      const res = await fetch("/api/admin/courses", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          targetType: "course",
          targetId: courseId,
          ...courseForm,
        }),
      });
      const data = await res.json();
      if (!res.ok) {
        showToast(data.error || "تعذر حفظ التعديلات");
      } else {
        showToast(data.message);
        setEditingCourseId(null);
        fetchData();
      }
    } catch {
      showToast("حدث خطأ أثناء حفظ الكورس");
    }
  };

  const handleStartEditPkg = (p: PackageItem) => {
    setEditingPkgId(p.id);
    setPkgForm({
      title: p.title,
      subtitle: p.subtitle,
      description: p.description,
      price: p.price,
      originalPrice: p.originalPrice,
      durationLabel: p.durationLabel,
    });
  };

  const handleSavePkg = async (pkgId: number) => {
    try {
      const res = await fetch("/api/admin/courses", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          targetType: "package",
          targetId: pkgId,
          ...pkgForm,
        }),
      });
      const data = await res.json();
      if (!res.ok) {
        showToast(data.error || "تعذر حفظ التعديلات");
      } else {
        showToast(data.message);
        setEditingPkgId(null);
        fetchData();
      }
    } catch {
      showToast("حدث خطأ أثناء حفظ الباقة");
    }
  };

  return (
    <div className="min-h-screen bg-[#F8FAFC] text-[#0F172A] pb-20">
      {/* Toast Notification */}
      {toast && (
        <div className="fixed top-5 left-1/2 -translate-x-1/2 z-50 bg-[#0F172A] text-white px-5 py-3 rounded-2xl shadow-2xl border border-[#F59E0B] flex items-center gap-2 text-xs sm:text-sm font-bold">
          <Sparkles className="w-4 h-4 text-[#F59E0B]" />
          <span>{toast}</span>
        </div>
      )}

      {/* Top Header */}
      <header className="bg-[#0F172A] text-white border-b border-slate-800 sticky top-0 z-40">
        <div className="max-w-[1400px] mx-auto px-4 sm:px-8 py-4 flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-[#F59E0B] text-[#0F172A] flex items-center justify-center font-bold">
              <DollarSign className="w-6 h-6" />
            </div>
            <div>
              <h1 className="font-heading text-lg sm:text-xl font-bold">
                التحكم بأسعار الكورسات والمدرسين (/admin/courses)
              </h1>
              <p className="text-xs text-slate-300">
                تعديل وتحديد سعر كل كورس أو باقة، اسم المدرس، ووصف المادة فوراً
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2.5">
            <Link
              href="/admin/students"
              className="px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold transition flex items-center gap-1.5"
            >
              <ShieldAlert className="w-3.5 h-3.5 text-amber-400" />
              <span>لوحة الطلاب</span>
            </Link>
            <Link
              href="/admin/payments"
              className="px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold transition flex items-center gap-1.5"
            >
              <DollarSign className="w-3.5 h-3.5 text-emerald-400" />
              <span>مراجعة طلبات الدفع</span>
            </Link>
            <Link
              href="/"
              className="px-4 py-2 rounded-xl bg-[#F59E0B] text-[#0F172A] font-bold text-xs transition"
            >
              منصة الطالب ←
            </Link>
          </div>
        </div>
      </header>

      <main className="max-w-[1400px] mx-auto px-4 sm:px-8 pt-6 space-y-8">
        {/* Course Pricing & Details Section */}
        <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-6 space-y-6">
          <div className="flex items-center justify-between pb-4 border-b border-slate-100">
            <div>
              <h2 className="font-heading text-lg font-bold text-[#0F172A] flex items-center gap-2">
                <BookOpen className="w-5 h-5 text-[#F59E0B]" />
                قائمة الكورسات والأسعار والمدرسين
              </h2>
              <p className="text-xs text-slate-500">
                اضغط على «تعديل» لأي كورس لتغيير السعر واسم المدرس ووصف المادة
                مباشرة وسينعكس ذلك على المنصة فوراً
              </p>
            </div>
            <button
              onClick={fetchData}
              className="px-3 py-1.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold flex items-center gap-1"
            >
              <RefreshCw className="w-3.5 h-3.5" /> تحديث
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {courses.map((c) => {
              const isEditing = editingCourseId === c.id;
              return (
                <div
                  key={c.id}
                  className={`rounded-2xl border p-5 transition ${
                    isEditing
                      ? "border-[#0F172A] bg-slate-50 ring-2 ring-[#0F172A]/10"
                      : "border-slate-200 bg-white hover:border-slate-300 shadow-sm"
                  }`}
                >
                  {isEditing ? (
                    <div className="space-y-3 text-xs">
                      <div className="flex items-center justify-between pb-2 border-b border-slate-200">
                        <span className="font-bold text-[#F59E0B]">
                          تعديل الكورس #{c.id}
                        </span>
                        <button
                          onClick={() => setEditingCourseId(null)}
                          className="p-1 rounded bg-slate-200 text-slate-600 hover:bg-slate-300"
                        >
                          <X className="w-3.5 h-3.5" />
                        </button>
                      </div>

                      <div>
                        <label className="block font-bold text-slate-700 mb-1">
                          عنوان الكورس:
                        </label>
                        <input
                          type="text"
                          value={courseForm.title}
                          onChange={(e) =>
                            setCourseForm({
                              ...courseForm,
                              title: e.target.value,
                            })
                          }
                          className="w-full px-3 py-1.5 rounded-xl border border-slate-300 bg-white font-bold"
                        />
                      </div>

                      <div className="grid grid-cols-2 gap-2">
                        <div>
                          <label className="block font-bold text-slate-700 mb-1">
                            سعر الكورس (ج.م):
                          </label>
                          <input
                            type="number"
                            value={courseForm.price}
                            onChange={(e) =>
                              setCourseForm({
                                ...courseForm,
                                price: Number(e.target.value),
                              })
                            }
                            className="w-full px-3 py-1.5 rounded-xl border border-slate-300 bg-white font-mono-num font-bold text-emerald-700"
                          />
                        </div>
                        <div>
                          <label className="block font-bold text-slate-700 mb-1">
                            نوع الكورس:
                          </label>
                          <select
                            value={courseForm.type}
                            onChange={(e) =>
                              setCourseForm({
                                ...courseForm,
                                type: e.target.value,
                              })
                            }
                            className="w-full px-3 py-1.5 rounded-xl border border-slate-300 bg-white"
                          >
                            <option value="online">أونلاين مدفوع</option>
                            <option value="center">السنتر</option>
                            <option value="free">مجاني بالكامل (0 ج.م)</option>
                          </select>
                        </div>
                      </div>

                      <div className="grid grid-cols-2 gap-2">
                        <div>
                          <label className="block font-bold text-slate-700 mb-1">
                            اسم المدرس:
                          </label>
                          <input
                            type="text"
                            value={courseForm.instructorName}
                            onChange={(e) =>
                              setCourseForm({
                                ...courseForm,
                                instructorName: e.target.value,
                              })
                            }
                            className="w-full px-3 py-1.5 rounded-xl border border-slate-300 bg-white"
                          />
                        </div>
                        <div>
                          <label className="block font-bold text-slate-700 mb-1">
                            المادة والفرع:
                          </label>
                          <input
                            type="text"
                            value={courseForm.subject}
                            onChange={(e) =>
                              setCourseForm({
                                ...courseForm,
                                subject: e.target.value,
                              })
                            }
                            className="w-full px-3 py-1.5 rounded-xl border border-slate-300 bg-white"
                          />
                        </div>
                      </div>

                      <div>
                        <label className="block font-bold text-slate-700 mb-1">
                          وصف الكورس والمحتوى:
                        </label>
                        <textarea
                          rows={2}
                          value={courseForm.description}
                          onChange={(e) =>
                            setCourseForm({
                              ...courseForm,
                              description: e.target.value,
                            })
                          }
                          className="w-full px-3 py-1.5 rounded-xl border border-slate-300 bg-white text-xs"
                        />
                      </div>

                      <div className="flex gap-2 pt-2">
                        <button
                          onClick={() => handleSaveCourse(c.id)}
                          className="flex-1 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold transition flex items-center justify-center gap-1.5"
                        >
                          <Check className="w-4 h-4" /> حفظ التعديلات فورا
                        </button>
                        <button
                          onClick={() => setEditingCourseId(null)}
                          className="px-4 py-2 rounded-xl bg-slate-200 text-slate-700 font-bold"
                        >
                          إلغاء
                        </button>
                      </div>
                    </div>
                  ) : (
                    <div className="flex flex-col justify-between h-full space-y-4">
                      <div>
                        <div className="flex items-center justify-between">
                          <span
                            className={`px-2.5 py-0.5 rounded-full text-[11px] font-bold ${
                              c.type === "free"
                                ? "bg-emerald-100 text-emerald-800"
                                : c.type === "center"
                                ? "bg-amber-100 text-amber-900"
                                : "bg-slate-100 text-slate-800"
                            }`}
                          >
                            {c.type === "free"
                              ? "كورس مجاني"
                              : c.type === "center"
                              ? "محاضرات السنتر"
                              : "كورس أونلاين"}
                          </span>
                          <span className="font-mono-num text-xl font-extrabold text-emerald-700">
                            {c.price} ج.م
                          </span>
                        </div>

                        <h3 className="font-heading font-bold text-base text-slate-900 mt-2">
                          {c.title}
                        </h3>

                        <div className="flex flex-wrap items-center gap-3 text-xs text-slate-500 mt-1">
                          <span className="flex items-center gap-1 text-slate-700 font-semibold">
                            <User className="w-3.5 h-3.5 text-[#F59E0B]" />
                            {c.instructorName}
                          </span>
                          <span>• {c.subject}</span>
                          <span>• {c.gradeLevel}</span>
                        </div>

                        <p className="text-xs text-slate-600 mt-2 line-clamp-2 leading-relaxed">
                          {c.description}
                        </p>
                      </div>

                      <div className="pt-3 border-t border-slate-100 flex items-center justify-between">
                        <span className="text-[11px] text-slate-400">
                          ID: #{c.id}
                        </span>
                        <button
                          onClick={() => handleStartEditCourse(c)}
                          className="px-4 py-2 rounded-xl bg-[#0F172A] hover:bg-slate-800 text-white text-xs font-bold flex items-center gap-1.5 transition"
                        >
                          <Edit3 className="w-3.5 h-3.5 text-[#F59E0B]" />
                          تعديل السعر والمدرس
                        </button>
                      </div>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>

        {/* Packages Pricing Section */}
        <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-6 space-y-6">
          <div className="flex items-center justify-between pb-4 border-b border-slate-100">
            <div>
              <h2 className="font-heading text-lg font-bold text-[#0F172A] flex items-center gap-2">
                <Package className="w-5 h-5 text-[#F59E0B]" />
                التحكم بأسعار الباقات والاشتراكات الشهرية
              </h2>
              <p className="text-xs text-slate-500">
                تعديل سعر الاشتراك بعد الخصم وقبل الخصم ومدة الباقة
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {packages.map((pkg) => {
              const isEditing = editingPkgId === pkg.id;
              return (
                <div
                  key={pkg.id}
                  className={`rounded-2xl border p-5 transition ${
                    isEditing
                      ? "border-[#0F172A] bg-slate-50 ring-2 ring-[#0F172A]/10"
                      : "border-slate-200 bg-white hover:border-slate-300 shadow-sm"
                  }`}
                >
                  {isEditing ? (
                    <div className="space-y-3 text-xs">
                      <div className="flex items-center justify-between pb-2 border-b border-slate-200">
                        <span className="font-bold text-[#F59E0B]">
                          تعديل الباقة #{pkg.id}
                        </span>
                        <button
                          onClick={() => setEditingPkgId(null)}
                          className="p-1 rounded bg-slate-200 text-slate-600"
                        >
                          <X className="w-3.5 h-3.5" />
                        </button>
                      </div>

                      <div>
                        <label className="block font-bold text-slate-700 mb-1">
                          عنوان الباقة:
                        </label>
                        <input
                          type="text"
                          value={pkgForm.title}
                          onChange={(e) =>
                            setPkgForm({ ...pkgForm, title: e.target.value })
                          }
                          className="w-full px-3 py-1.5 rounded-xl border border-slate-300 bg-white font-bold"
                        />
                      </div>

                      <div className="grid grid-cols-2 gap-2">
                        <div>
                          <label className="block font-bold text-slate-700 mb-1">
                            السعر بعد الخصم:
                          </label>
                          <input
                            type="number"
                            value={pkgForm.price}
                            onChange={(e) =>
                              setPkgForm({
                                ...pkgForm,
                                price: Number(e.target.value),
                              })
                            }
                            className="w-full px-3 py-1.5 rounded-xl border border-slate-300 bg-white font-mono-num font-bold text-emerald-700"
                          />
                        </div>
                        <div>
                          <label className="block font-bold text-slate-700 mb-1">
                            السعر الأصلي:
                          </label>
                          <input
                            type="number"
                            value={pkgForm.originalPrice}
                            onChange={(e) =>
                              setPkgForm({
                                ...pkgForm,
                                originalPrice: Number(e.target.value),
                              })
                            }
                            className="w-full px-3 py-1.5 rounded-xl border border-slate-300 bg-white font-mono-num line-through text-slate-500"
                          />
                        </div>
                      </div>

                      <div>
                        <label className="block font-bold text-slate-700 mb-1">
                          مدة الاشتراك:
                        </label>
                        <input
                          type="text"
                          value={pkgForm.durationLabel}
                          onChange={(e) =>
                            setPkgForm({
                              ...pkgForm,
                              durationLabel: e.target.value,
                            })
                          }
                          className="w-full px-3 py-1.5 rounded-xl border border-slate-300 bg-white"
                        />
                      </div>

                      <div className="flex gap-2 pt-2">
                        <button
                          onClick={() => handleSavePkg(pkg.id)}
                          className="flex-1 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold transition flex items-center justify-center gap-1.5"
                        >
                          <Check className="w-4 h-4" /> حفظ الباقة
                        </button>
                        <button
                          onClick={() => setEditingPkgId(null)}
                          className="px-4 py-2 rounded-xl bg-slate-200 text-slate-700 font-bold"
                        >
                          إلغاء
                        </button>
                      </div>
                    </div>
                  ) : (
                    <div className="flex flex-col justify-between h-full space-y-4">
                      <div>
                        <div className="flex items-center justify-between">
                          <span className="px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-amber-100 text-amber-900">
                            {pkg.durationLabel}
                          </span>
                          <div className="text-left">
                            <span className="font-mono-num text-xl font-extrabold text-[#0F172A]">
                              {pkg.price} ج.م
                            </span>
                            <span className="block text-[10px] font-mono-num text-slate-400 line-through">
                              {pkg.originalPrice} ج.م
                            </span>
                          </div>
                        </div>

                        <h3 className="font-heading font-bold text-base text-slate-900 mt-2">
                          {pkg.title}
                        </h3>
                        <p className="text-xs text-slate-600 mt-1 line-clamp-2">
                          {pkg.subtitle}
                        </p>
                      </div>

                      <button
                        onClick={() => handleStartEditPkg(pkg)}
                        className="w-full py-2 rounded-xl bg-[#0F172A] hover:bg-slate-800 text-white text-xs font-bold flex items-center justify-center gap-1.5 transition"
                      >
                        <Edit3 className="w-3.5 h-3.5 text-[#F59E0B]" />
                        تعديل سعر الباقة
                      </button>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      </main>
    </div>
  );
}
