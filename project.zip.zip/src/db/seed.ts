import { db } from "./index";
import {
  users,
  courses,
  sections,
  videoAssets,
  lessons,
  packages,
  packageItems,
  enrollments,
  payments,
  quizzes,
  questions,
  answers,
  quizAttempts,
  progress,
  coupons,
  couponRedemptions,
  auditLogs,
  platformSettings,
} from "./schema";
import { hashPassword } from "@/lib/security";
import { count } from "drizzle-orm";

let isSeeding = false;

export async function ensureSeeded() {
  if (isSeeding) return;
  try {
    const [{ value: existingUsers }] = await db
      .select({ value: count() })
      .from(users);
    
    // Ensure platformSettings exists regardless
    const [{ value: existingSettings }] = await db
      .select({ value: count() })
      .from(platformSettings);
    if (existingSettings === 0) {
      await db.insert(platformSettings).values({
        vodafoneCashNumber: "01023316767",
        instapayAddress: "albayan@instapay",
        instapayName: "أ.د. محمود الشافعي (البيان التعليمية)",
        supportPhone: "01023316767",
        transferInstructions:
          "يرجى التحويل على رقم فودافون كاش أو معرف InstaPay الموضحين، ثم كتابة رقم المحفظة المحول منها ورفع صورة الإشعار للموافقة وتفعيل الكورس فوراً.",
      });
    }

    if (existingUsers > 0) {
      return;
    }

    isSeeding = true;
    const adminPasswordHash = await hashPassword("Admin@2026");
    const studentPasswordHash = await hashPassword("Student@2026");

    // 1. Seed Admin & Students
    const insertedUsers = await db
      .insert(users)
      .values([
        {
          tripleName: "أ.د. محمود الشافعي",
          studentPhone: "01000000001",
          guardianPhone: "01000000002",
          motherPhone: "01000000003",
          email: "admin@albayan-edu.eg",
          passwordHash: adminPasswordHash,
          role: "admin",
          status: "active",
          gradeLevel: "الإدارة العامة للمنصة",
          walletBalance: 5000,
          points: 9999,
          bookGiftCode: "ADMIN-MASTER-2026",
        },
        {
          tripleName: "يوسف طارق عبد الرحمن",
          studentPhone: "01012345678",
          guardianPhone: "01123456789",
          motherPhone: "01234567890",
          email: "youssef.tarek@albayan.eg",
          passwordHash: studentPasswordHash,
          role: "student",
          status: "active",
          gradeLevel: "الصف الثالث الثانوي - علمي علوم",
          walletBalance: 450,
          points: 1280,
          bookGiftCode: "BAYAN-GIFT-8841",
        },
        {
          tripleName: "مريم خالد محمد الشناوي",
          studentPhone: "01098765432",
          guardianPhone: "01198765432",
          motherPhone: "01598765432",
          email: "mariam.khaled@albayan.eg",
          passwordHash: studentPasswordHash,
          role: "student",
          status: "active",
          gradeLevel: "الصف الثالث الثانوي - أدبي",
          walletBalance: 320,
          points: 1540,
          bookGiftCode: "BAYAN-GIFT-7720",
        },
        {
          tripleName: "عمر أحمد حسن المنصوري",
          studentPhone: "01155443322",
          guardianPhone: "01055443322",
          motherPhone: "01255443322",
          email: "omar.mansoury@albayan.eg",
          passwordHash: studentPasswordHash,
          role: "student",
          status: "active",
          gradeLevel: "الصف الثالث الثانوي - علمي رياضة",
          walletBalance: 180,
          points: 920,
          bookGiftCode: "BAYAN-GIFT-5519",
        },
        {
          tripleName: "سارة وائل إبراهيم الدسوقي",
          studentPhone: "01288776655",
          guardianPhone: "01088776655",
          motherPhone: "01188776655",
          email: "sara.wael@albayan.eg",
          passwordHash: studentPasswordHash,
          role: "student",
          status: "active",
          gradeLevel: "الصف الثالث الثانوي - علمي علوم",
          walletBalance: 90,
          points: 640,
          bookGiftCode: "BAYAN-GIFT-3310",
        },
        {
          tripleName: "كريم مصطفى كامل الجوهري",
          studentPhone: "01533221100",
          guardianPhone: "01033221100",
          motherPhone: "01233221100",
          email: "karim.mostafa@albayan.eg",
          passwordHash: studentPasswordHash,
          role: "student",
          status: "banned",
          gradeLevel: "الصف الثالث الثانوي - علمي علوم",
          walletBalance: 0,
          points: 210,
          bookGiftCode: "BAYAN-GIFT-1102",
        },
      ])
      .returning();

    const adminUser = insertedUsers[0];
    const mainStudent = insertedUsers[1];
    const studentMariam = insertedUsers[2];
    const studentOmar = insertedUsers[3];
    const studentSara = insertedUsers[4];

    // 2. Seed Courses with instructorName, subject, price, description
    const insertedCourses = await db
      .insert(courses)
      .values([
        {
          title: "إتقان النحو والبلاغة الشامل - الوحدة الأولى والثانية",
          slug: "arabic-grammar-rhetoric-mastery",
          description:
            "شرح تفصيلي لقواعد النحو (همزة القطع وألف الوصل، المشتقات العاملة، الأبنية) مع تطبيقات البلاغة المتحررة بأحدث نظام للثانوية العامة.",
          subject: "اللغة العربية - نحو وبلاغة",
          gradeLevel: "الصف الثالث الثانوي",
          instructorName: "أ.د. محمود الشافعي",
          price: 250,
          type: "online",
          published: true,
        },
        {
          title: "مراجعات السنتر المكثفة وحل بنوك الأسئلة الوزارية",
          slug: "center-intensive-revisions",
          description:
            "تسجيلات عالية الجودة لمحاضرات السنتر التفاعلية مع حل 500 سؤال من امتحانات الأعوام السابقة والنماذج الاسترشادية.",
          subject: "اللغة العربية - مراجعات السنتر",
          gradeLevel: "الصف الثالث الثانوي",
          instructorName: "أ.د. محمود الشافعي",
          price: 200,
          type: "center",
          published: true,
        },
        {
          title: "كورس التأسيس الذهبي في الإعراب والقراءة المتحررة (مجاني)",
          slug: "free-foundation-course",
          description:
            "محاضرات تأسيسية مجانية متاحة لجميع الطلاب لإتقان مفاتيح الإعراب واستخراج العلاقات الضمنية في قطع القراءة المتحررة.",
          subject: "اللغة العربية - تأسيس مجاني",
          gradeLevel: "الصف الثالث الثانوي",
          instructorName: "أ.د. محمود الشافعي",
          price: 0,
          type: "free",
          published: true,
        },
        {
          title: "مدارس الأدب والنصوص المتحررة وقصة الأيام لطه حسين",
          slug: "literature-texts-story-course",
          description:
            "دراسة تحليلية لمدرسة الإحياء والبعث والاتجاه الوجداني والديوان وأبولو مع ربطها بالنصوص المتحررة وفصول قصة الأيام.",
          subject: "اللغة العربية - أدب ونصوص",
          gradeLevel: "الصف الثالث الثانوي",
          instructorName: "أ.د. محمود الشافعي",
          price: 220,
          type: "online",
          published: true,
        },
      ])
      .returning();

    const course1 = insertedCourses[0];
    const course2 = insertedCourses[1];
    const course3 = insertedCourses[2];
    const course4 = insertedCourses[3];

    // 3. Seed Sections
    const insertedSections = await db
      .insert(sections)
      .values([
        {
          courseId: course1.id,
          title: "القسم الأول: الوحدة الأولى في النحو (النطق والإملاء)",
          orderIndex: 1,
        },
        {
          courseId: course1.id,
          title: "القسم الثاني: الوحدة الثانية (المشتقات العاملة والأبنية)",
          orderIndex: 2,
        },
        {
          courseId: course2.id,
          title: "القسم الأول: ورش عمل السنتر وحل امتحانات شاملة",
          orderIndex: 1,
        },
        {
          courseId: course3.id,
          title: "القسم الأول: أساسيات الإعراب ومفاتيح القراءة",
          orderIndex: 1,
        },
        {
          courseId: course4.id,
          title: "القسم الأول: الكلاسيكية الجديدة والاتجاه الوجداني",
          orderIndex: 1,
        },
      ])
      .returning();

    // 4. Seed Private Video Assets
    const insertedVideos = await db
      .insert(videoAssets)
      .values([
        {
          title: "محاضرة 1: همزة القطع وألف الوصل والفرق بين ألا وإلا",
          storageKey: "r2://albayan-private-videos/2026/unit1-lecture1-hamza.mp4",
          bucketName: "albayan-private-videos",
          provider: "cloudflare_r2",
          durationSeconds: 2700,
          resolution: "1080p Full HD",
          sampleTopic: "النطق والإملاء وتطبيقات وزارية",
        },
        {
          title: "محاضرة 2: إعمال اسم الفاعل وصيغ المبالغة بشروطها",
          storageKey: "r2://albayan-private-videos/2026/unit2-lecture2-mushtaqat.mp4",
          bucketName: "albayan-private-videos",
          provider: "cloudflare_r2",
          durationSeconds: 3120,
          resolution: "1080p Full HD",
          sampleTopic: "إعمال المشتقات وحالات الإعراب الخاصة",
        },
        {
          title: "محاضرة 3: التجربة الشعرية والوحدة العضوية في البلاغة",
          storageKey: "r2://albayan-private-videos/2026/rhetoric-lecture3-poetic.mp4",
          bucketName: "albayan-private-videos",
          provider: "cloudflare_r2",
          durationSeconds: 2400,
          resolution: "1080p Full HD",
          sampleTopic: "عناصر التجربة الشعرية والصور المركبة",
        },
        {
          title: "محاضرة السنتر 1: معسكر حل 150 سؤال نحو وبلاغة",
          storageKey: "r2://albayan-private-videos/2026/center-camp-150q.mp4",
          bucketName: "albayan-private-videos",
          provider: "cloudflare_r2",
          durationSeconds: 3600,
          resolution: "1080p Full HD",
          sampleTopic: "مراجعة السنتر التفاعلية الكبرى",
        },
        {
          title: "محاضرة مجانية 1: خريطة الإعراب الذهنية من الصفر للاحتراف",
          storageKey: "r2://albayan-private-videos/2026/free-irab-mindmap.mp4",
          bucketName: "albayan-private-videos",
          provider: "cloudflare_r2",
          durationSeconds: 1980,
          resolution: "1080p Full HD",
          sampleTopic: "الجملة الاسمية والفعلية والنواسخ",
        },
        {
          title: "محاضرة مجانية 2: كيف تجيب عن القراءة المتحررة في 12 دقيقة؟",
          storageKey: "r2://albayan-private-videos/2026/free-reading-strategy.mp4",
          bucketName: "albayan-private-videos",
          provider: "cloudflare_r2",
          durationSeconds: 1800,
          resolution: "1080p Full HD",
          sampleTopic: "العلاقات الضمنية والمغزى الضمني",
        },
        {
          title: "محاضرة الأدب 1: مدرسة الإحياء والبعث وجيل التطوير (أحمد شوقي)",
          storageKey: "r2://albayan-private-videos/2026/lit-neo-classicism.mp4",
          bucketName: "albayan-private-videos",
          provider: "cloudflare_r2",
          durationSeconds: 2850,
          resolution: "1080p Full HD",
          sampleTopic: "سمات الكلاسيكية الجديدة وتطبيقات على نص غربـة وحنين",
        },
      ])
      .returning();

    // 5. Seed Lessons
    const insertedLessons = await db
      .insert(lessons)
      .values([
        {
          sectionId: insertedSections[0].id,
          courseId: course1.id,
          videoAssetId: insertedVideos[0].id,
          title: "المحاضرة الأولى: همزة القطع وألف الوصل واللام الشمسية والقمرية",
          description:
            "شرح تفصيلي لكل مواضع همزة القطع وألف الوصل والهمزة المتوسطة والمتطرفة مع حل 60 سؤالاً من كتاب الامتحان وكيان.",
          orderIndex: 1,
          durationSeconds: 2700,
          type: "online",
          pdfTitle: "ملزمة الوحدة الأولى في النحو (PDF ملون 34 صفحة)",
          pdfUrl: "/files/unit1-grammar-notes.pdf",
          homeworkTitle: "واجب المحاضرة الأولى (30 سؤال اختيار من متعدد)",
          isFreePreview: false,
        },
        {
          sectionId: insertedSections[1].id,
          courseId: course1.id,
          videoAssetId: insertedVideos[1].id,
          title: "المحاضرة الثانية: إعمال اسم الفاعل وصيغ المبالغة واسم المفعول",
          description:
            "متى يعمل المشتق عمل فعله؟ شروط الاعتماد على مبتدأ أو نفي أو استفهام أو موصوف مع التفرقة بين المعمول المرفوع والمنصوب.",
          orderIndex: 2,
          durationSeconds: 3120,
          type: "online",
          pdfTitle: "ملزمة المشتقات العاملة وخرائط الذهن (PDF)",
          pdfUrl: "/files/unit2-derivatives-notes.pdf",
          homeworkTitle: "واجب المشتقات العاملة وإعراب المعمول",
          isFreePreview: false,
        },
        {
          sectionId: insertedSections[1].id,
          courseId: course1.id,
          videoAssetId: insertedVideos[2].id,
          title: "المحاضرة الثالثة: التجربة الشعرية والوحدة العضوية والخيال المركب",
          description:
            "كيف تستخرج الصدق الشعوري، امتزاج الفكر بالوجدان، الصورة الكلية (صوت ولون وحركة)، والخيال الممتد والمركب.",
          orderIndex: 3,
          durationSeconds: 2400,
          type: "online",
          pdfTitle: "كراسة البلاغة المتحررة والتدريبات التطبيقية (PDF)",
          pdfUrl: "/files/rhetoric-mastery-notes.pdf",
          homeworkTitle: "واجب البلاغة المتحررة (5 قطع شعرية)",
          isFreePreview: false,
        },
        {
          sectionId: insertedSections[2].id,
          courseId: course2.id,
          videoAssetId: insertedVideos[3].id,
          title: "ورشة السنتر الكبرى (1): حل 150 سؤال نحو وبلاغة مستويات عليا",
          description:
            "محاضرة السنتر المسجلة بجودة 1080p لتحليل أفكار الامتحانات الوزارية وتفادي الفخاخ النحوية الشائعة.",
          orderIndex: 1,
          durationSeconds: 3600,
          type: "center",
          pdfTitle: "كتيب معسكر السنتر الأول (150 سؤال بالإجابات)",
          pdfUrl: "/files/center-camp-150q.pdf",
          homeworkTitle: "تسليم شيت السنتر الأسبوعي الأول",
          isFreePreview: false,
        },
        {
          sectionId: insertedSections[3].id,
          courseId: course3.id,
          videoAssetId: insertedVideos[4].id,
          title: "محاضرة تأسيسية (1): خريطة الإعراب الذهنية الشاملة (مجانية)",
          description:
            "أساسيات الجملة الاسمية والفعلية، المرفوعات والمنصوبات والمجرورات، وكيف تحدد موقع الكلمة الإعرابي بدقة.",
          orderIndex: 1,
          durationSeconds: 1980,
          type: "free",
          pdfTitle: "خريطة الإعراب الذهنية المبسطة (مجاني PDF)",
          pdfUrl: "/files/free-irab-map.pdf",
          homeworkTitle: "تدريب الإعراب التأسيسي (20 جملة)",
          isFreePreview: true,
        },
        {
          sectionId: insertedSections[3].id,
          courseId: course3.id,
          videoAssetId: insertedVideos[5].id,
          title: "محاضرة تأسيسية (2): مفاتيح القراءة المتحررة والعلاقات الضمنية (مجانية)",
          description:
            "التفرقة الدقيقة بين علاقة التعليل والنتيجة والتفصيل بعد إجمال والتوضيح والاستدراك في قطع القراءة العلمية والأدبية.",
          orderIndex: 2,
          durationSeconds: 1800,
          type: "free",
          pdfTitle: "دليل العلاقات الضمنية في القراءة والنصوص (PDF)",
          pdfUrl: "/files/free-reading-keys.pdf",
          homeworkTitle: "تطبيق قطعتين قراءة متحررة",
          isFreePreview: true,
        },
        {
          sectionId: insertedSections[4].id,
          courseId: course4.id,
          videoAssetId: insertedVideos[6].id,
          title: "محاضرة الأدب والنصوص (1): مدرسة الإحياء والبعث وجيل التطوير",
          description:
            "عوامل تطور تلاميذ البارودي، مظاهر التجديد عند أحمد شوقي وأحمد محرم، وتحليل نص غربة وحنين ونصوص متحررة موازية.",
          orderIndex: 1,
          durationSeconds: 2850,
          type: "online",
          pdfTitle: "ملزمة مدرسة الإحياء والبعث والنصوص المتحررة (PDF)",
          pdfUrl: "/files/neo-classicism-literature.pdf",
          homeworkTitle: "واجب الأدب والنصوص المتحررة (مدرسة الإحياء)",
          isFreePreview: false,
        },
      ])
      .returning();

    // 6. Seed Packages & Package Items
    const insertedPackages = await db
      .insert(packages)
      .values([
        {
          title: "باقة الشهر الأول التأسيسية والشاملة",
          subtitle: "تشمل محاضرات الوحدة الأولى والثانية + البلاغة + الملازم والامتحانات",
          description:
            "الباقة الأساسية للشهر الأول، تمنحك وصولاً كاملاً لكورس النحو والبلاغة الشامل مع امتحانات أسبوعية وتصحيح إلكتروني فوري.",
          price: 250,
          originalPrice: 350,
          badge: "مشترك بها حالياً",
          durationLabel: "اشتراك شهر كامل",
          featuresJson: JSON.stringify([
            "فتح جميع محاضرات كورس النحو والبلاغة (الوحدة 1 و 2)",
            "تحميل ملازم الشرح والواجب بصيغة PDF عالية الدقة",
            "دخول الامتحانات الأسبوعية وتفعيل قسم أخطائي",
            "متابعة علمية مستمرة مع فريق المساعدين",
          ]),
          published: true,
        },
        {
          title: "باقة الثلاث شهور الذهبية (توفير 35%)",
          subtitle: "تشمل كورس النحو والبلاغة + الأدب والنصوص + مراجعات السنتر المكثفة",
          description:
            "أفضل قيمة مقابل سعر! تغطي منهج الثلاثة أشهر الأولى بالكامل (نحو، بلاغة، أدب، نصوص، قصة، وورش السنتر) مع كود خصم إضافي للكتب.",
          price: 590,
          originalPrice: 900,
          badge: "الأكثر توفيراً - خصم 35%",
          durationLabel: "اشتراك 3 شهور كاملة",
          featuresJson: JSON.stringify([
            "فتح 3 كورسات كاملة (النحو والبلاغة + الأدب والنصوص + ورش السنتر)",
            "أولوية الرد في الدعم العلمي وتصحيح المقالات",
            "كوبون هدية بقيمة 100 ج.م على كتب المتجر المطبوعة",
            "امتحانات شهرية شاملة بنظام البابل شيت والأسئلة المقالية",
          ]),
          published: true,
        },
        {
          title: "باقة الترم الكامل الشاملة + كتاب كيان هدية",
          subtitle: "وصول غير محدود لكافة كورسات المنصة والسنتر والكتب حتى ليلة الامتحان",
          description:
            "الباقة الملكية لطلاب الصف الثالث الثانوي، تشمل جميع المحاضرات الأونلاين وتسجيلات السنتر ومعسكرات المراجعة النهائية وكتاب مطبوع يصلك لباب المنزل.",
          price: 950,
          originalPrice: 1450,
          badge: "الباقة الملكية VIP",
          durationLabel: "الترم الكامل + المراجعات",
          featuresJson: JSON.stringify([
            "وصول مفتوح لجميع محاضرات المنصة الأونلاين والسنتر طوال الترم",
            "كتاب الشرح والتدريبات المطبوع يصلك مجاناً عبر الشحن السريع",
            "حصص بث مباشر أسبوعية للمراجعة وحل أسئلة الطلاب",
            "تقارير أداء دورية لولي الأمر والامتحانات التجريبية الشاملة",
          ]),
          published: true,
        },
      ])
      .returning();

    const pkg1 = insertedPackages[0];
    const pkg2 = insertedPackages[1];
    const pkg3 = insertedPackages[2];

    await db.insert(packageItems).values([
      {
        packageId: pkg1.id,
        courseId: course1.id,
        lessonId: insertedLessons[0].id,
        itemTitle: insertedLessons[0].title,
        itemType: "lesson",
        orderIndex: 1,
      },
      {
        packageId: pkg1.id,
        courseId: course1.id,
        lessonId: insertedLessons[1].id,
        itemTitle: insertedLessons[1].title,
        itemType: "lesson",
        orderIndex: 2,
      },
      {
        packageId: pkg1.id,
        courseId: course1.id,
        lessonId: insertedLessons[2].id,
        itemTitle: insertedLessons[2].title,
        itemType: "lesson",
        orderIndex: 3,
      },
      {
        packageId: pkg2.id,
        courseId: course1.id,
        lessonId: insertedLessons[0].id,
        itemTitle: "كورس إتقان النحو والبلاغة كاملاً (3 محاضرات)",
        itemType: "course",
        orderIndex: 1,
      },
      {
        packageId: pkg2.id,
        courseId: course2.id,
        lessonId: insertedLessons[3].id,
        itemTitle: "مراجعات السنتر المكثفة وحل 150 سؤال مستويات عليا",
        itemType: "lesson",
        orderIndex: 2,
      },
      {
        packageId: pkg2.id,
        courseId: course4.id,
        lessonId: insertedLessons[6].id,
        itemTitle: "كورس الأدب والنصوص المتحررة وقصة الأيام",
        itemType: "lesson",
        orderIndex: 3,
      },
      {
        packageId: pkg3.id,
        courseId: course1.id,
        lessonId: insertedLessons[0].id,
        itemTitle: "جميع محاضرات النحو والبلاغة (الترم الكامل)",
        itemType: "course",
        orderIndex: 1,
      },
      {
        packageId: pkg3.id,
        courseId: course2.id,
        lessonId: insertedLessons[3].id,
        itemTitle: "جميع معسكرات وورش السنتر المسجلة",
        itemType: "course",
        orderIndex: 2,
      },
      {
        packageId: pkg3.id,
        courseId: course4.id,
        lessonId: insertedLessons[6].id,
        itemTitle: "جميع محاضرات الأدب والنصوص المتحررة والقصة",
        itemType: "course",
        orderIndex: 3,
      },
    ]);

    // 7. Seed Enrollments & Payments (including a pending Direct Transfer for studentSara for Admin Review demo)
    await db.insert(enrollments).values([
      {
        userId: mainStudent.id,
        courseId: course1.id,
        packageId: pkg1.id,
        grantedBy: "payment",
        status: "active",
      },
      {
        userId: mainStudent.id,
        courseId: course3.id,
        packageId: null,
        grantedBy: "free",
        status: "active",
      },
      {
        userId: studentMariam.id,
        courseId: course1.id,
        packageId: pkg2.id,
        grantedBy: "payment",
        status: "active",
      },
      {
        userId: studentMariam.id,
        courseId: course2.id,
        packageId: pkg2.id,
        grantedBy: "payment",
        status: "active",
      },
      {
        userId: studentMariam.id,
        courseId: course4.id,
        packageId: pkg2.id,
        grantedBy: "payment",
        status: "active",
      },
      {
        userId: studentOmar.id,
        courseId: course1.id,
        packageId: pkg1.id,
        grantedBy: "payment",
        status: "active",
      },
    ]);

    await db.insert(payments).values([
      {
        userId: mainStudent.id,
        courseId: course1.id,
        packageId: pkg1.id,
        amount: 250,
        currency: "EGP",
        method: "vodafone_cash",
        status: "paid",
        paymentType: "automated",
        paymobOrderId: "PMB-ORD-90812",
        paymobTransactionId: "TXN-VF-774190",
        hmacVerified: true,
        referenceCode: "01012345678",
      },
      {
        userId: studentMariam.id,
        courseId: course1.id,
        packageId: pkg2.id,
        amount: 590,
        currency: "EGP",
        method: "visa_mastercard",
        status: "paid",
        paymentType: "automated",
        paymobOrderId: "PMB-ORD-90845",
        paymobTransactionId: "TXN-CARD-883219",
        hmacVerified: true,
        referenceCode: "VISA-****-4419",
      },
      {
        userId: studentOmar.id,
        courseId: course1.id,
        packageId: pkg1.id,
        amount: 250,
        currency: "EGP",
        method: "fawry_pay",
        status: "paid",
        paymentType: "automated",
        paymobOrderId: "PMB-ORD-90901",
        paymobTransactionId: "TXN-FWRY-991024",
        hmacVerified: true,
        referenceCode: "FAWRY-94827103",
      },
      // Pending Direct Transfer from studentSara for Admin Review
      {
        userId: studentSara.id,
        courseId: course1.id,
        packageId: null,
        amount: 250,
        currency: "EGP",
        method: "instapay",
        status: "pending",
        paymentType: "direct_transfer",
        paymobOrderId: "DIR-INSTA-448102",
        paymobTransactionId: "TXN-INSTA-9921",
        hmacVerified: false,
        referenceCode: "INSTA-REF-771892",
        senderPhone: "01288776655",
        senderName: "سارة وائل إبراهيم",
        receiptUrl: "https://images.unsplash.com/photo-1554224155-8d04cb21cd6c?w=600&auto=format&fit=crop&q=80",
        transferNote: "تم التحويل بنجاح من حساب InstaPay الخاص بي برجاء تفعيل كورس النحو والبلاغة",
      },
    ]);

    // 8. Seed Progress
    await db.insert(progress).values([
      {
        userId: mainStudent.id,
        lessonId: insertedLessons[0].id,
        courseId: course1.id,
        watchedSeconds: 2700,
        durationSeconds: 2700,
        completed: true,
      },
      {
        userId: mainStudent.id,
        lessonId: insertedLessons[4].id,
        courseId: course3.id,
        watchedSeconds: 1980,
        durationSeconds: 1980,
        completed: true,
      },
      {
        userId: mainStudent.id,
        lessonId: insertedLessons[5].id,
        courseId: course3.id,
        watchedSeconds: 1800,
        durationSeconds: 1800,
        completed: true,
      },
      {
        userId: mainStudent.id,
        lessonId: insertedLessons[1].id,
        courseId: course1.id,
        watchedSeconds: 1945,
        durationSeconds: 3120,
        completed: false,
      },
      {
        userId: mainStudent.id,
        lessonId: insertedLessons[2].id,
        courseId: course1.id,
        watchedSeconds: 820,
        durationSeconds: 2400,
        completed: false,
      },
    ]);

    // 9. Seed Quizzes
    const insertedQuizzes = await db
      .insert(quizzes)
      .values([
        {
          courseId: course1.id,
          lessonId: insertedLessons[0].id,
          title: "الامتحان الأسبوعي الأول: همزة القطع وألف الوصل والهمزات",
          description:
            "اختبار تطبيقي بنظام الثانوية العامة الحديث لقياس إتقان قواعد النطق والإملاء وعلاقات الإعراب.",
          passingScore: 60,
          durationMinutes: 20,
          totalMarks: 20,
          published: true,
        },
        {
          courseId: course1.id,
          lessonId: insertedLessons[1].id,
          title: "الامتحان الأسبوعي الثاني: إعمال المشتقات (اسم الفاعل وصيغ المبالغة)",
          description:
            "اختبار شامل على شروط إعمال المشتقات وإعراب معمول اسم الفاعل وصيغ المبالغة واسم المفعول.",
          passingScore: 60,
          durationMinutes: 25,
          totalMarks: 20,
          published: true,
        },
      ])
      .returning();

    const quiz1 = insertedQuizzes[0];

    const q1List = await db
      .insert(questions)
      .values([
        {
          quizId: quiz1.id,
          questionText:
            "«يجب على المؤمن أن يتقي الله، وإلا يَخسرْ دنياه وآخرته» — ما إعراب الفعل المضارع (يخسر) في العبارة السابقة؟",
          explanation:
            "لأن (إلا) هنا مكونة من (إنْ) الشرطية الجازمة + (لا) النافية، وفعل الشرط محذوف تقديره (وإلا يفعلْ يخسرْ)، فيكون (يخسر) جواب الشرط مجزوماً وعلامة جزمه السكون.",
          points: 10,
          orderIndex: 1,
        },
        {
          quizId: quiz1.id,
          questionText:
            "أي الكلمات الآتية بُدئت بهمزة قطع لأنها مصدر لفعل رباعي؟",
          explanation:
            "كلمة (إكرام) مصدر للفعل الرباعي (أَكْرَمَ - إكرام)، ومصادر الأفعال الرباعية كلها همزتها همزة قطع قياسية.",
          points: 10,
          orderIndex: 2,
        },
      ])
      .returning();

    await db.insert(answers).values([
      {
        questionId: q1List[0].id,
        answerText: "مضارع مرفوع وعلامة رفعه الضمة الظاهرة",
        isCorrect: false,
        orderIndex: 1,
      },
      {
        questionId: q1List[0].id,
        answerText: "مضارع مجزوم في جواب الشرط وعلامة جزمه السكون",
        isCorrect: true,
        orderIndex: 2,
      },
      {
        questionId: q1List[1].id,
        answerText: "استغفار",
        isCorrect: false,
        orderIndex: 1,
      },
      {
        questionId: q1List[1].id,
        answerText: "إكرام",
        isCorrect: true,
        orderIndex: 2,
      },
    ]);

    await db.insert(quizAttempts).values([
      {
        quizId: quiz1.id,
        userId: mainStudent.id,
        score: 20,
        totalMarks: 20,
        percentage: 100,
        passed: true,
        answersJson: JSON.stringify([]),
      },
    ]);

    // 10. Seed Coupons
    await db.insert(coupons).values([
      {
        code: "BAYAN25",
        discountPercent: 25,
        maxUses: 200,
        usedCount: 42,
        active: true,
      },
      {
        code: "GOLD50",
        discountPercent: 50,
        maxUses: 50,
        usedCount: 18,
        active: true,
      },
    ]);

    // 11. Seed Audit Logs
    await db.insert(auditLogs).values([
      {
        adminId: adminUser.id,
        adminName: adminUser.tripleName,
        action: "تهيئة إعدادات الدفع المباشر",
        targetType: "settings",
        targetId: "1",
        details:
          "تم ضبط رقم فودافون كاش (01023316767) ومعرف InstaPay (albayan@instapay) بنجاح.",
        ipAddress: "197.45.112.80",
      },
    ]);
  } catch (err) {
    console.error("Seed error:", err);
  } finally {
    isSeeding = false;
  }
}
