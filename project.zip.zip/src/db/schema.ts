import {
  pgTable,
  serial,
  text,
  integer,
  boolean,
  timestamp,
  uniqueIndex,
} from "drizzle-orm/pg-core";

// 1. Users Table (الطلاب والمسؤولين)
export const users = pgTable(
  "users",
  {
    id: serial("id").primaryKey(),
    tripleName: text("triple_name").notNull(),
    studentPhone: text("student_phone").notNull(),
    guardianPhone: text("guardian_phone").notNull(),
    motherPhone: text("mother_phone").notNull(),
    email: text("email"),
    passwordHash: text("password_hash").notNull(),
    role: text("role").notNull().default("student"), // 'student' | 'admin'
    status: text("status").notNull().default("active"), // 'active' | 'banned'
    gradeLevel: text("grade_level").notNull().default("الصف الثالث الثانوي"),
    walletBalance: integer("wallet_balance").notNull().default(0),
    points: integer("points").notNull().default(150),
    bookGiftCode: text("book_gift_code").notNull().default("GIFT-BAYAN-2026"),
    lastLoginAt: timestamp("last_login_at").defaultNow(),
    createdAt: timestamp("created_at").notNull().defaultNow(),
    updatedAt: timestamp("updated_at").notNull().defaultNow(),
  },
  (table) => [uniqueIndex("users_student_phone_idx").on(table.studentPhone)]
);

// 2. Courses Table (الكورسات والمحاضرات)
export const courses = pgTable("courses", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  slug: text("slug").notNull(),
  description: text("description").notNull(),
  subject: text("subject").notNull().default("اللغة العربية"),
  gradeLevel: text("grade_level").notNull().default("الصف الثالث الثانوي"),
  instructorName: text("instructor_name").notNull().default("أ.د. محمود الشافعي"),
  price: integer("price").notNull().default(0),
  type: text("type").notNull().default("online"), // 'online' | 'center' | 'free'
  thumbnailUrl: text("thumbnail_url"),
  published: boolean("published").notNull().default(true),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

// 3. Sections Table (أقسام الكورس)
export const sections = pgTable("sections", {
  id: serial("id").primaryKey(),
  courseId: integer("course_id")
    .notNull()
    .references(() => courses.id, { onDelete: "cascade" }),
  title: text("title").notNull(),
  orderIndex: integer("order_index").notNull().default(1),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

// 4. Video Assets Table (ملفات الفيديو المحمية عبر Cloudflare R2 / S3)
export const videoAssets = pgTable("video_assets", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  storageKey: text("storage_key").notNull(), // Private key in R2/S3 bucket
  bucketName: text("bucket_name").notNull().default("albayan-private-videos"),
  provider: text("provider").notNull().default("cloudflare_r2"), // 'cloudflare_r2' | 'aws_s3'
  durationSeconds: integer("duration_seconds").notNull().default(2700),
  resolution: text("resolution").notNull().default("1080p Full HD"),
  sampleTopic: text("sample_topic").notNull().default("شرح تفصيلي وتدريبات"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

// 5. Lessons Table (الدروس والمحاضرات الفرعية)
export const lessons = pgTable("lessons", {
  id: serial("id").primaryKey(),
  sectionId: integer("section_id")
    .notNull()
    .references(() => sections.id, { onDelete: "cascade" }),
  courseId: integer("course_id")
    .notNull()
    .references(() => courses.id, { onDelete: "cascade" }),
  videoAssetId: integer("video_asset_id").references(() => videoAssets.id, {
    onDelete: "set null",
  }),
  title: text("title").notNull(),
  description: text("description").notNull(),
  orderIndex: integer("order_index").notNull().default(1),
  durationSeconds: integer("duration_seconds").notNull().default(2700),
  type: text("type").notNull().default("online"), // 'online' | 'center' | 'free'
  pdfTitle: text("pdf_title"),
  pdfUrl: text("pdf_url"),
  homeworkTitle: text("homework_title"),
  isFreePreview: boolean("is_free_preview").notNull().default(false),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

// 6. Packages Table (الباقات الشهرية والموسمية)
export const packages = pgTable("packages", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  subtitle: text("subtitle").notNull(),
  description: text("description").notNull(),
  price: integer("price").notNull(),
  originalPrice: integer("original_price").notNull(),
  badge: text("badge").notNull().default("الأكثر طلباً"),
  durationLabel: text("duration_label").notNull().default("شهر كامل"),
  featuresJson: text("features_json").notNull().default("[]"),
  published: boolean("published").notNull().default(true),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

// 7. Package Items Table (محتويات الباقة من كورسات ودروس)
export const packageItems = pgTable("package_items", {
  id: serial("id").primaryKey(),
  packageId: integer("package_id")
    .notNull()
    .references(() => packages.id, { onDelete: "cascade" }),
  courseId: integer("course_id")
    .notNull()
    .references(() => courses.id, { onDelete: "cascade" }),
  lessonId: integer("lesson_id").references(() => lessons.id, {
    onDelete: "cascade",
  }),
  itemTitle: text("item_title").notNull(),
  itemType: text("item_type").notNull().default("course"), // 'course' | 'lesson' | 'quiz' | 'pdf'
  orderIndex: integer("order_index").notNull().default(1),
});

// 8. Enrollments Table (اشتراكات الطلاب وصلاحيات الوصول)
export const enrollments = pgTable("enrollments", {
  id: serial("id").primaryKey(),
  userId: integer("user_id")
    .notNull()
    .references(() => users.id, { onDelete: "cascade" }),
  courseId: integer("course_id").references(() => courses.id, {
    onDelete: "cascade",
  }),
  packageId: integer("package_id").references(() => packages.id, {
    onDelete: "cascade",
  }),
  grantedBy: text("granted_by").notNull().default("payment"), // 'payment' | 'admin' | 'coupon' | 'free' | 'manual_transfer'
  status: text("status").notNull().default("active"), // 'active' | 'revoked' | 'expired'
  expiresAt: timestamp("expires_at"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

// 9. Payments Table (المدفوعات، التحويل المباشر InstaPay/Vodafone، وبوابات الدفع Paymob)
export const payments = pgTable("payments", {
  id: serial("id").primaryKey(),
  userId: integer("user_id")
    .notNull()
    .references(() => users.id, { onDelete: "cascade" }),
  courseId: integer("course_id").references(() => courses.id, {
    onDelete: "set null",
  }),
  packageId: integer("package_id").references(() => packages.id, {
    onDelete: "set null",
  }),
  amount: integer("amount").notNull(),
  currency: text("currency").notNull().default("EGP"),
  method: text("method").notNull().default("vodafone_cash"), // 'instapay' | 'vodafone_cash' | 'fawry_pay' | 'visa_mastercard' | 'wallet'
  status: text("status").notNull().default("paid"), // 'paid' | 'pending' | 'rejected' | 'failed' | 'refunded'
  paymentType: text("payment_type").notNull().default("automated"), // 'automated' | 'direct_transfer'
  paymobOrderId: text("paymob_order_id").notNull().default(""),
  paymobTransactionId: text("paymob_transaction_id").notNull().default(""),
  hmacVerified: boolean("hmac_verified").notNull().default(true),
  referenceCode: text("reference_code"),
  senderPhone: text("sender_phone"),
  senderName: text("sender_name"),
  receiptUrl: text("receipt_url"), // Image URL or proof data
  transferNote: text("transfer_note"),
  reviewedByAdminId: integer("reviewed_by_admin_id").references(() => users.id, {
    onDelete: "set null",
  }),
  reviewedAt: timestamp("reviewed_at"),
  rejectionReason: text("rejection_reason"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

// 10. Quizzes Table (الاختبارات والامتحانات)
export const quizzes = pgTable("quizzes", {
  id: serial("id").primaryKey(),
  courseId: integer("course_id")
    .notNull()
    .references(() => courses.id, { onDelete: "cascade" }),
  lessonId: integer("lesson_id").references(() => lessons.id, {
    onDelete: "set null",
  }),
  title: text("title").notNull(),
  description: text("description").notNull(),
  passingScore: integer("passing_score").notNull().default(60), // Percentage e.g. 60%
  durationMinutes: integer("duration_minutes").notNull().default(25),
  totalMarks: integer("total_marks").notNull().default(20),
  published: boolean("published").notNull().default(true),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

// 11. Questions Table (أسئلة الاختبارات)
export const questions = pgTable("questions", {
  id: serial("id").primaryKey(),
  quizId: integer("quiz_id")
    .notNull()
    .references(() => quizzes.id, { onDelete: "cascade" }),
  questionText: text("question_text").notNull(),
  explanation: text("explanation").notNull(),
  points: integer("points").notNull().default(5),
  orderIndex: integer("order_index").notNull().default(1),
});

// 12. Answers Table (خيارات الإجابة لكل سؤال)
export const answers = pgTable("answers", {
  id: serial("id").primaryKey(),
  questionId: integer("question_id")
    .notNull()
    .references(() => questions.id, { onDelete: "cascade" }),
  answerText: text("answer_text").notNull(),
  isCorrect: boolean("is_correct").notNull().default(false),
  orderIndex: integer("order_index").notNull().default(1),
});

// 13. Quiz Attempts Table (محاولات ونتائج الامتحانات وأخطاء الطالب)
export const quizAttempts = pgTable("quiz_attempts", {
  id: serial("id").primaryKey(),
  quizId: integer("quiz_id")
    .notNull()
    .references(() => quizzes.id, { onDelete: "cascade" }),
  userId: integer("user_id")
    .notNull()
    .references(() => users.id, { onDelete: "cascade" }),
  score: integer("score").notNull(),
  totalMarks: integer("total_marks").notNull(),
  percentage: integer("percentage").notNull(),
  passed: boolean("passed").notNull().default(false),
  answersJson: text("answers_json").notNull().default("[]"), // Detailed question/answer breakdown for Mistakes Bank
  startedAt: timestamp("started_at").notNull().defaultNow(),
  completedAt: timestamp("completed_at").notNull().defaultNow(),
});

// 14. Progress Table (تقدم مشاهدة الفيديوهات وآخر ثانية)
export const progress = pgTable("progress", {
  id: serial("id").primaryKey(),
  userId: integer("user_id")
    .notNull()
    .references(() => users.id, { onDelete: "cascade" }),
  lessonId: integer("lesson_id")
    .notNull()
    .references(() => lessons.id, { onDelete: "cascade" }),
  courseId: integer("course_id")
    .notNull()
    .references(() => courses.id, { onDelete: "cascade" }),
  watchedSeconds: integer("watched_seconds").notNull().default(0),
  durationSeconds: integer("duration_seconds").notNull().default(2700),
  completed: boolean("completed").notNull().default(false),
  lastWatchedAt: timestamp("last_watched_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

// 15. Coupons Table (كوبونات الخصم والأكواد)
export const coupons = pgTable(
  "coupons",
  {
    id: serial("id").primaryKey(),
    code: text("code").notNull(),
    discountPercent: integer("discount_percent").notNull().default(20),
    maxUses: integer("max_uses").notNull().default(100),
    usedCount: integer("used_count").notNull().default(0),
    courseId: integer("course_id").references(() => courses.id, {
      onDelete: "set null",
    }),
    packageId: integer("package_id").references(() => packages.id, {
      onDelete: "set null",
    }),
    active: boolean("active").notNull().default(true),
    expiresAt: timestamp("expires_at"),
    createdAt: timestamp("created_at").notNull().defaultNow(),
  },
  (table) => [uniqueIndex("coupons_code_idx").on(table.code)]
);

// 16. Coupon Redemptions Table (سجل استخدام الكوبونات)
export const couponRedemptions = pgTable("coupon_redemptions", {
  id: serial("id").primaryKey(),
  couponId: integer("coupon_id")
    .notNull()
    .references(() => coupons.id, { onDelete: "cascade" }),
  userId: integer("user_id")
    .notNull()
    .references(() => users.id, { onDelete: "cascade" }),
  paymentId: integer("payment_id").references(() => payments.id, {
    onDelete: "set null",
  }),
  redeemedAt: timestamp("redeemed_at").notNull().defaultNow(),
});

// 17. Audit Logs Table (سجل العمليات الإدارية)
export const auditLogs = pgTable("audit_logs", {
  id: serial("id").primaryKey(),
  adminId: integer("admin_id").references(() => users.id, {
    onDelete: "set null",
  }),
  adminName: text("admin_name").notNull(),
  action: text("action").notNull(),
  targetType: text("target_type").notNull(), // 'student' | 'course' | 'package' | 'quiz' | 'coupon' | 'enrollment' | 'payment' | 'settings'
  targetId: text("target_id").notNull(),
  details: text("details").notNull(),
  ipAddress: text("ip_address").notNull().default("127.0.0.1"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

// 18. Platform Settings Table (إعدادات التحويل المباشر InstaPay وفودافون كاش والدعم)
export const platformSettings = pgTable("platform_settings", {
  id: serial("id").primaryKey(),
  vodafoneCashNumber: text("vodafone_cash_number").notNull().default("01023316767"),
  instapayAddress: text("instapay_address").notNull().default("albayan@instapay"),
  instapayName: text("instapay_name").notNull().default("أ.د. محمود الشافعي"),
  supportPhone: text("support_phone").notNull().default("01023316767"),
  transferInstructions: text("transfer_instructions")
    .notNull()
    .default(
      "يرجى التحويل على رقم فودافون كاش أو معرف InstaPay الموضحين، ثم كتابة رقم المحفظة المحول منها ورفع صورة الإشعار للموافقة وتفعيل الكورس فوراً."
    ),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});
