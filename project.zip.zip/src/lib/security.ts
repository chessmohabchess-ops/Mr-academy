import crypto from "crypto";
import bcrypt from "bcryptjs";
import { cookies } from "next/headers";

const AUTH_SECRET =
  process.env.AUTH_SECRET ||
  "albayan-super-secret-jwt-hmac-key-2026-production-ready";

const VIDEO_SECRET =
  process.env.VIDEO_STORAGE_SECRET_KEY ||
  "R2_SECRET_ACCESS_KEY_PRIVATE_SIGNING_2026";

const PAYMENT_WEBHOOK_SECRET =
  process.env.PAYMENT_WEBHOOK_SECRET ||
  "paymob_hmac_secret_sha512_webhook_verifier_2026";

export const EGYPTIAN_PHONE_REGEX = /^01[0125][0-9]{8}$/;

export function isValidEgyptianPhone(phone: string): boolean {
  return EGYPTIAN_PHONE_REGEX.test(phone.trim());
}

export function isValidTripleName(name: string): boolean {
  const parts = name
    .trim()
    .split(/\s+/)
    .filter((part) => part.length >= 2);
  return parts.length >= 3;
}

export async function hashPassword(plain: string): Promise<string> {
  const salt = await bcrypt.genSalt(10);
  return bcrypt.hash(plain, salt);
}

export async function verifyPassword(
  plain: string,
  hash: string
): Promise<boolean> {
  return bcrypt.compare(plain, hash);
}

export interface SessionPayload {
  userId: number;
  role: "student" | "admin";
  studentPhone: string;
  exp: number;
}

export function createSessionToken(payload: Omit<SessionPayload, "exp">): string {
  const fullPayload: SessionPayload = {
    ...payload,
    exp: Date.now() + 1000 * 60 * 60 * 24 * 7, // 7 days
  };
  const data = Buffer.from(JSON.stringify(fullPayload)).toString("base64url");
  const signature = crypto
    .createHmac("sha256", AUTH_SECRET)
    .update(data)
    .digest("base64url");
  return `${data}.${signature}`;
}

export function verifySessionToken(token: string): SessionPayload | null {
  try {
    const [data, signature] = token.split(".");
    if (!data || !signature) return null;
    const expectedSig = crypto
      .createHmac("sha256", AUTH_SECRET)
      .update(data)
      .digest("base64url");
    if (signature !== expectedSig) return null;
    const decoded = JSON.parse(
      Buffer.from(data, "base64url").toString("utf-8")
    ) as SessionPayload;
    if (decoded.exp < Date.now()) return null;
    return decoded;
  } catch {
    return null;
  }
}

export async function getServerSession(): Promise<SessionPayload | null> {
  try {
    const cookieStore = await cookies();
    const token = cookieStore.get("albayan_session")?.value;
    if (!token) return null;
    return verifySessionToken(token);
  } catch {
    return null;
  }
}

/**
 * Generates a short-lived Private Storage Signed URL (Cloudflare R2 / AWS S3 SigV4 style)
 * Never exposes permanent storage keys or credentials in client HTML/JS.
 */
export function createSignedVideoStreamUrl(params: {
  userId: number;
  lessonId: number;
  storageKey: string;
  ttlSeconds?: number;
}): {
  signedUrl: string;
  expiresAt: number;
  signature: string;
  provider: string;
} {
  const ttl = params.ttlSeconds ?? 900; // 15 minutes short-lived URL
  const expiresAt = Math.floor(Date.now() / 1000) + ttl;
  const payload = `${params.userId}:${params.lessonId}:${params.storageKey}:${expiresAt}`;
  const signature = crypto
    .createHmac("sha256", VIDEO_SECRET)
    .update(payload)
    .digest("hex");

  const token = Buffer.from(
    JSON.stringify({
      u: params.userId,
      l: params.lessonId,
      exp: expiresAt,
    })
  ).toString("base64url");

  const signedUrl = `/api/videos/stream?X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Credential=R2_PRIVATE%2F2026%2Fauto%2Fs3%2Faws4_request&X-Amz-Expires=${ttl}&token=${token}&X-Amz-Signature=${signature}`;

  return {
    signedUrl,
    expiresAt: expiresAt * 1000,
    signature,
    provider: "Cloudflare R2 Private Storage (Signed S3 URL)",
  };
}

export function verifySignedVideoStreamToken(params: {
  token: string;
  signature: string;
  storageKey: string;
}): { valid: boolean; userId?: number; lessonId?: number; reason?: string } {
  try {
    const decoded = JSON.parse(
      Buffer.from(params.token, "base64url").toString("utf-8")
    ) as { u: number; l: number; exp: number };

    const nowSec = Math.floor(Date.now() / 1000);
    if (decoded.exp < nowSec) {
      return { valid: false, reason: "انتهت صلاحية الرابط المؤقت (Expired Signed URL)" };
    }

    const payload = `${decoded.u}:${decoded.l}:${params.storageKey}:${decoded.exp}`;
    const expectedSig = crypto
      .createHmac("sha256", VIDEO_SECRET)
      .update(payload)
      .digest("hex");

    if (expectedSig !== params.signature) {
      return { valid: false, reason: "توقيع الحماية غير صالح (Invalid HMAC Signature)" };
    }

    return { valid: true, userId: decoded.u, lessonId: decoded.l };
  } catch {
    return { valid: false, reason: "رمز الفيديو غير صالح" };
  }
}

/**
 * Paymob Egyptian Payment Gateway HMAC-SHA512 Verification
 */
export function computePaymobHmac(data: {
  amountCents: number;
  currency: string;
  orderId: string;
  transactionId: string;
  success: boolean;
  userId: number;
}): string {
  const concatenated = `${data.amountCents}${data.currency}${data.orderId}${data.success}${data.transactionId}${data.userId}`;
  return crypto
    .createHmac("sha512", PAYMENT_WEBHOOK_SECRET)
    .update(concatenated)
    .digest("hex");
}

export function verifyPaymobHmac(
  data: {
    amountCents: number;
    currency: string;
    orderId: string;
    transactionId: string;
    success: boolean;
    userId: number;
  },
  receivedHmac: string
): boolean {
  const expected = computePaymobHmac(data);
  return expected === receivedHmac;
}

/**
 * Strips sensitive fields (passwordHash, guardianPhone, motherPhone) for non-admin/public student views
 */
export function sanitizeUserForStudent<
  T extends {
    passwordHash?: string;
    guardianPhone?: string;
    motherPhone?: string;
  }
>(user: T, includeOwnParentPhones = false) {
  const { passwordHash: _pw, guardianPhone, motherPhone, ...safeUser } = user;
  if (includeOwnParentPhones) {
    return {
      ...safeUser,
      guardianPhone,
      motherPhone,
    };
  }
  return safeUser;
}
