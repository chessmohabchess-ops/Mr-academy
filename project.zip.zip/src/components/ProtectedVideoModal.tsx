"use client";

import React, { useEffect, useState, useRef, useCallback } from "react";
import {
  X,
  Play,
  Pause,
  RotateCcw,
  FastForward,
  ShieldCheck,
  CheckCircle2,
  Lock,
  FileText,
  Sparkles,
  Volume2,
} from "lucide-react";

interface ProtectedVideoModalProps {
  lessonId: number | null;
  onClose: () => void;
  onProgressUpdated: () => void;
  onRequestPurchase?: (courseId: number) => void;
}

function formatTime(sec: number): string {
  const s = Math.max(0, Math.floor(sec));
  const mins = Math.floor(s / 60);
  const rem = s % 60;
  return `${String(mins).padStart(2, "0")}:${String(rem).padStart(2, "0")}`;
}

export function ProtectedVideoModal({
  lessonId,
  onClose,
  onProgressUpdated,
}: ProtectedVideoModalProps) {
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [authData, setAuthData] = useState<{
    lessonId: number;
    title: string;
    durationSeconds: number;
    watchedSeconds: number;
    completed: boolean;
    signedStream: {
      url: string;
      expiresAt: number;
      provider: string;
      resolution: string;
    };
    watermark: {
      studentName: string;
      studentPhone: string;
    };
  } | null>(null);

  const [streamVerified, setStreamVerified] = useState(false);
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentSecond, setCurrentSecond] = useState(0);
  const [playbackRate, setPlaybackRate] = useState(1);
  const [savingIndicator, setSavingIndicator] = useState(false);
  const [completedBadge, setCompletedBadge] = useState(false);
  const [watermarkPos, setWatermarkPos] = useState({ top: 18, right: 16 });

  const latestSecRef = useRef(0);
  latestSecRef.current = currentSecond;

  const saveProgressToServer = useCallback(
    async (secToSave: number, forceComplete = false) => {
      if (!lessonId) return;
      try {
        setSavingIndicator(true);
        const res = await fetch("/api/progress", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            lessonId,
            watchedSeconds: secToSave,
            completed: forceComplete,
          }),
        });
        const data = await res.json();
        if (data.success) {
          if (data.progress?.completed) {
            setCompletedBadge(true);
          }
          onProgressUpdated();
        }
      } catch {
        // ignore network hiccup
      } finally {
        setTimeout(() => setSavingIndicator(false), 600);
      }
    },
    [lessonId, onProgressUpdated]
  );

  // Authorize & load signed URL when modal opens
  useEffect(() => {
    if (!lessonId) return;
    let active = true;
    setLoading(true);
    setError(null);

    fetch("/api/videos/authorize", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ lessonId }),
    })
      .then(async (res) => {
        const data = await res.json();
        if (!res.ok) {
          throw new Error(data.error || "غير مصرح بمشاهدة هذا الفيديو");
        }
        return data;
      })
      .then(async (data) => {
        if (!active) return;
        setAuthData(data);
        setCurrentSecond(data.watchedSeconds || 0);
        setCompletedBadge(Boolean(data.completed));

        // Verify temporary signed stream URL token against server
        if (data.signedStream?.url) {
          const verifyRes = await fetch(data.signedStream.url);
          if (verifyRes.ok && active) {
            setStreamVerified(true);
          }
        }
      })
      .catch((err: Error) => {
        if (active) setError(err.message);
      })
      .finally(() => {
        if (active) setLoading(false);
      });

    return () => {
      active = false;
    };
  }, [lessonId]);

  // Playback timer & automatic progress persistence every 4 seconds
  useEffect(() => {
    if (!isPlaying || !authData) return;

    const tickInterval = setInterval(() => {
      setCurrentSecond((prev) => {
        const next = Math.min(
          authData.durationSeconds,
          prev + Math.ceil(playbackRate * 5) // Accelerated educational preview step (5s per tick)
        );
        if (next >= authData.durationSeconds) {
          setIsPlaying(false);
          saveProgressToServer(authData.durationSeconds, true);
        }
        return next;
      });
    }, 1000);

    const heartbeatInterval = setInterval(() => {
      saveProgressToServer(latestSecRef.current, false);
    }, 4000);

    const watermarkInterval = setInterval(() => {
      setWatermarkPos({
        top: Math.floor(15 + Math.random() * 55),
        right: Math.floor(12 + Math.random() * 55),
      });
    }, 5000);

    return () => {
      clearInterval(tickInterval);
      clearInterval(heartbeatInterval);
      clearInterval(watermarkInterval);
    };
  }, [isPlaying, authData, playbackRate, saveProgressToServer]);

  if (!lessonId) return null;

  const handleTogglePlay = () => {
    if (isPlaying) {
      setIsPlaying(false);
      saveProgressToServer(currentSecond, false);
    } else {
      setIsPlaying(true);
    }
  };

  const handleSeek = (newSec: number) => {
    if (!authData) return;
    const clamped = Math.max(0, Math.min(authData.durationSeconds, newSec));
    setCurrentSecond(clamped);
    saveProgressToServer(clamped, false);
  };

  const progressPct = authData
    ? Math.min(
        100,
        Math.round((currentSecond / Math.max(1, authData.durationSeconds)) * 100)
      )
    : 0;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/80 backdrop-blur-sm p-4 overflow-y-auto">
      <div className="bg-white w-full max-w-4xl rounded-2xl shadow-2xl border border-slate-200 overflow-hidden my-auto">
        {/* Top Bar */}
        <div className="bg-[#0F172A] text-white px-6 py-4 flex items-center justify-between border-b border-slate-800">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-[#F59E0B]/20 border border-[#F59E0B]/40 flex items-center justify-center text-[#F59E0B]">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-heading text-base sm:text-lg font-bold text-white line-clamp-1">
                {authData?.title || "مشغل المحاضرات المحمي — منصة البيان"}
              </h3>
              <div className="flex flex-wrap items-center gap-2 text-[11px] text-slate-300">
                <span className="inline-flex items-center gap-1 text-emerald-400 font-semibold">
                  <Lock className="w-3 h-3" />
                  {streamVerified
                    ? "بث محمي وموقع رقمياً (Cloudflare R2 Signed URL)"
                    : "جاري التحقق من توقيع الحماية..."}
                </span>
                {savingIndicator && (
                  <span className="text-amber-300 font-mono-num">
                    • جاري حفظ الثانية {formatTime(currentSecond)} تلقائياً...
                  </span>
                )}
              </div>
            </div>
          </div>

          <button
            onClick={() => {
              if (authData) {
                saveProgressToServer(currentSecond, false);
              }
              onClose();
            }}
            className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body */}
        {loading ? (
          <div className="p-16 flex flex-col items-center justify-center text-center space-y-3">
            <div className="w-12 h-12 rounded-full border-4 border-[#0F172A] border-t-[#F59E0B] animate-spin" />
            <p className="font-heading font-bold text-slate-800">
              جاري التحقق من صلاحية الاشتراك وتوليد الرابط المؤقت الموقع...
            </p>
            <p className="text-xs text-slate-500">
              Server-Side Authorization & Private R2 Storage Signing
            </p>
          </div>
        ) : error ? (
          <div className="p-12 text-center space-y-4">
            <div className="w-16 h-16 rounded-2xl bg-red-50 text-red-600 flex items-center justify-center mx-auto border border-red-200">
              <Lock className="w-8 h-8" />
            </div>
            <h4 className="font-heading text-xl font-bold text-slate-900">
              المحتوى محمي ويتطلب اشتراكاً فعالاً
            </h4>
            <p className="text-sm text-slate-600 max-w-md mx-auto">{error}</p>
            <button
              onClick={onClose}
              className="px-6 py-2.5 rounded-xl bg-[#0F172A] text-white font-bold text-sm hover:bg-slate-800 transition"
            >
              إغلاق والعودة للباقات
            </button>
          </div>
        ) : (
          authData && (
            <div>
              {/* 16:9 Protected Video Viewport */}
              <div className="relative aspect-video bg-gradient-to-br from-[#0B1120] via-[#0F172A] to-[#1E293B] flex flex-col justify-between p-6 select-none overflow-hidden">
                {/* Decorative Academic Chalkboard / Smartboard Content */}
                <div className="flex items-center justify-between z-10">
                  <span className="px-3 py-1 rounded-full bg-slate-900/80 border border-slate-700 text-amber-400 text-xs font-bold">
                    {authData.signedStream.resolution} • حماية DRM مفعلة
                  </span>
                  <span
                    dir="ltr"
                    className="px-3 py-1 rounded-full bg-emerald-950/80 border border-emerald-700/60 text-emerald-300 font-mono-num text-[11px]"
                  >
                    TTL Expires:{" "}
                    {new Date(authData.signedStream.expiresAt).toLocaleTimeString(
                      "en-US",
                      { hour: "2-digit", minute: "2-digit" }
                    )}
                  </span>
                </div>

                {/* Dynamic Anti-Piracy Moving Watermark */}
                <div
                  style={{
                    top: `${watermarkPos.top}%`,
                    right: `${watermarkPos.right}%`,
                  }}
                  className="absolute z-20 pointer-events-none transition-all duration-1000 px-3 py-1.5 rounded-lg bg-black/35 border border-white/10 backdrop-blur-[1px]"
                >
                  <p className="text-[11px] font-bold text-white/65">
                    {authData.watermark.studentName}
                  </p>
                  <p
                    dir="ltr"
                    className="text-[10px] font-mono-num text-amber-300/70"
                  >
                    ID: {authData.watermark.studentPhone}
                  </p>
                </div>

                {/* Center Smartboard Interactive Presentation */}
                <div className="my-auto text-center z-10 max-w-2xl mx-auto space-y-4">
                  <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-amber-500/15 border border-amber-400/30 text-amber-300 text-xs font-bold">
                    <Sparkles className="w-3.5 h-3.5" />
                    السبورة الذكية التفاعلية — أ.د. محمود الشافعي
                  </div>
                  <h2 className="font-heading text-xl sm:text-2xl font-bold text-white leading-relaxed">
                    {authData.title}
                  </h2>
                  <p className="text-xs sm:text-sm text-slate-300">
                    {isPlaying
                      ? "جاري تشغيل الشرح وحفظ تقدم المشاهدة تلقائياً في قاعدة البيانات..."
                      : currentSecond > 0
                      ? `تم استرجاع آخر موضع توقفت عنده تلقائياً (${formatTime(
                          currentSecond
                        )}) — اضغط تشغيل للاستكمال`
                      : "اضغط على زر التشغيل لبدء المحاضرة وحفظ تقدمك ثانية بثانية"}
                  </p>

                  <div className="flex items-center justify-center gap-4 pt-2">
                    <button
                      onClick={() => handleSeek(currentSecond - 60)}
                      className="p-3 rounded-full bg-white/10 hover:bg-white/20 text-white transition"
                      title="رجوع دقيقة"
                    >
                      <RotateCcw className="w-5 h-5" />
                    </button>
                    <button
                      onClick={handleTogglePlay}
                      className="w-16 h-16 rounded-full bg-[#F59E0B] hover:bg-amber-400 text-[#0F172A] flex items-center justify-center shadow-xl shadow-amber-500/30 transition transform hover:scale-105"
                    >
                      {isPlaying ? (
                        <Pause className="w-8 h-8 fill-current" />
                      ) : (
                        <Play className="w-8 h-8 fill-current ml-0.5" />
                      )}
                    </button>
                    <button
                      onClick={() => handleSeek(currentSecond + 120)}
                      className="p-3 rounded-full bg-white/10 hover:bg-white/20 text-white transition"
                      title="تقديم دقيقتين"
                    >
                      <FastForward className="w-5 h-5" />
                    </button>
                  </div>
                </div>

                {/* Bottom Scrubber & Controls inside Video */}
                <div className="z-10 space-y-2 bg-slate-950/75 p-3.5 rounded-xl border border-slate-800">
                  <div className="flex items-center justify-between text-xs font-mono-num text-slate-300">
                    <span>{formatTime(currentSecond)}</span>
                    <span className="text-amber-400 font-sans font-bold">
                      تم إنجاز {progressPct}% من المحاضرة
                    </span>
                    <span>{formatTime(authData.durationSeconds)}</span>
                  </div>

                  <input
                    type="range"
                    min={0}
                    max={authData.durationSeconds}
                    value={currentSecond}
                    onChange={(e) => handleSeek(Number(e.target.value))}
                    className="w-full accent-[#F59E0B] h-2 bg-slate-700 rounded-lg cursor-pointer"
                  />

                  <div className="flex flex-wrap items-center justify-between gap-2 pt-1">
                    <div className="flex items-center gap-2">
                      <Volume2 className="w-4 h-4 text-slate-300" />
                      <span className="text-[11px] text-slate-300">
                        سرعة العرض:
                      </span>
                      {[1, 1.25, 1.5, 2].map((rate) => (
                        <button
                          key={rate}
                          onClick={() => setPlaybackRate(rate)}
                          className={`px-2 py-0.5 rounded text-[11px] font-mono-num font-bold transition ${
                            playbackRate === rate
                              ? "bg-[#F59E0B] text-[#0F172A]"
                              : "bg-slate-800 text-slate-300 hover:bg-slate-700"
                          }`}
                        >
                          {rate}x
                        </button>
                      ))}
                    </div>

                    <div className="flex items-center gap-2">
                      {completedBadge ? (
                        <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-lg bg-emerald-500/20 border border-emerald-500/40 text-emerald-300 text-xs font-bold">
                          <CheckCircle2 className="w-4 h-4" />
                          مكتملة في سجل التقدم
                        </span>
                      ) : (
                        <button
                          onClick={() => {
                            setCurrentSecond(authData.durationSeconds);
                            setIsPlaying(false);
                            saveProgressToServer(
                              authData.durationSeconds,
                              true
                            );
                          }}
                          className="inline-flex items-center gap-1.5 px-3 py-1 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold transition"
                        >
                          <CheckCircle2 className="w-3.5 h-3.5" />
                          إتمام المحاضرة بالكامل (+50 نقطة)
                        </button>
                      )}
                    </div>
                  </div>
                </div>
              </div>

              {/* Technical Security Footnote */}
              <div className="bg-slate-50 px-6 py-3.5 border-t border-slate-200 flex flex-wrap items-center justify-between gap-3 text-xs text-slate-600">
                <div className="flex items-center gap-2">
                  <FileText className="w-4 h-4 text-[#0F172A]" />
                  <span>
                    يتم حفظ آخر ثانية شاهدتها في جدول{" "}
                    <code className="font-mono-num bg-slate-200 px-1.5 py-0.5 rounded text-slate-900">
                      progress
                    </code>{" "}
                    تلقائياً لاستئناف المشاهدة من أي جهاز.
                  </span>
                </div>
                <span
                  dir="ltr"
                  className="font-mono-num text-[11px] text-slate-500 truncate max-w-xs"
                >
                  Signed URL: {authData.signedStream.url.slice(0, 48)}...
                </span>
              </div>
            </div>
          )
        )}
      </div>
    </div>
  );
}
