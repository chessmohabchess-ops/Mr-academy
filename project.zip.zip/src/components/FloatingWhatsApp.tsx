"use client";

import React from "react";
import { MessageCircle, PhoneCall } from "lucide-react";

export function FloatingWhatsApp() {
  return (
    <a
      href="https://wa.me/201023316767?text=%D9%85%D8%B1%D8%AD%D8%A8%D8%A7%D9%8B%D8%8C%20%D8%A3%D8%AD%D8%AA%D8%A7%D8%AC%20%D8%A5%D9%84%D9%89%20%D9%85%D8%B3%D8%A7%D8%B9%D8%AF%D8%A9%20%D9%81%D9%8A%20%D9%85%D9%86%D8%B5%D8%A9%20%D8%A7%D9%84%D8%A8%D9%8A%D8%A7%D9%86%20%D8%A7%D9%84%D8%AA%D8%B9%D9%84%D9%8A%D9%85%D9%8A%D8%A9"
      target="_blank"
      rel="noopener noreferrer"
      aria-label="تواصل مع الدعم الفني عبر واتساب 01023316767"
      className="fixed bottom-6 left-6 z-50 group flex items-center gap-3 bg-emerald-600 hover:bg-emerald-500 text-white px-4 py-3 rounded-full shadow-xl shadow-emerald-600/30 border border-emerald-400/30 transition-all duration-300 hover:scale-105"
    >
      <span className="relative flex h-3 w-3">
        <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-white opacity-75"></span>
        <span className="relative inline-flex rounded-full h-3 w-3 bg-white"></span>
      </span>
      <MessageCircle className="w-5 h-5 fill-white/20" />
      <div className="flex flex-col text-right leading-tight">
        <span className="text-xs font-bold">الدعم الفني المباشر</span>
        <span
          dir="ltr"
          className="text-[11px] font-mono text-emerald-100 flex items-center gap-1"
        >
          <PhoneCall className="w-3 h-3 inline" />
          01023316767
        </span>
      </div>
    </a>
  );
}
