"use client";

import React from "react";
import { CheckCircle2, Clock, CircleDashed, Award, TrendingUp } from "lucide-react";

interface PieChartProps {
  completed: number;
  inProgress: number;
  notStarted: number;
  overallPercent: number;
}

export function LectureCompletionPieChart({
  completed,
  inProgress,
  notStarted,
  overallPercent,
}: PieChartProps) {
  const total = Math.max(1, completed + inProgress + notStarted);
  const radius = 64;
  const circumference = 2 * Math.PI * radius;

  const completedRatio = completed / total;
  const inProgressRatio = inProgress / total;
  const notStartedRatio = notStarted / total;

  const completedDash = completedRatio * circumference;
  const inProgressDash = inProgressRatio * circumference;
  const notStartedDash = notStartedRatio * circumference;

  const completedOffset = 0;
  const inProgressOffset = -completedDash;
  const notStartedOffset = -(completedDash + inProgressDash);

  return (
    <div className="bg-white rounded-2xl border border-slate-200/90 p-6 shadow-sm flex flex-col justify-between">
      <div className="flex items-center justify-between mb-4">
        <div>
          <h3 className="font-heading text-lg font-bold text-[#0F172A]">
            نسبة إنجاز المحاضرات
          </h3>
          <p className="text-xs text-slate-500">
            تحليل دائري لتقدمك في المحاضرات المسجلة والمجانية
          </p>
        </div>
        <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-emerald-50 text-emerald-700 border border-emerald-200">
          <TrendingUp className="w-3.5 h-3.5" />
          معدل الإنجاز {overallPercent}%
        </span>
      </div>

      <div className="flex flex-col sm:flex-row items-center justify-around gap-6 my-2">
        {/* SVG Donut/Pie Chart */}
        <div className="relative w-44 h-44 flex items-center justify-center shrink-0">
          <svg
            className="w-44 h-44 -rotate-90 transform"
            viewBox="0 0 160 160"
          >
            {/* Background Track */}
            <circle
              cx="80"
              cy="80"
              r={radius}
              fill="transparent"
              stroke="#F1F5F9"
              strokeWidth="18"
            />
            {/* Not Started Segment */}
            {notStarted > 0 && (
              <circle
                cx="80"
                cy="80"
                r={radius}
                fill="transparent"
                stroke="#CBD5E1"
                strokeWidth="18"
                strokeDasharray={`${notStartedDash} ${circumference}`}
                strokeDashoffset={notStartedOffset}
                strokeLinecap="butt"
              />
            )}
            {/* In Progress Segment */}
            {inProgress > 0 && (
              <circle
                cx="80"
                cy="80"
                r={radius}
                fill="transparent"
                stroke="#F59E0B"
                strokeWidth="18"
                strokeDasharray={`${inProgressDash} ${circumference}`}
                strokeDashoffset={inProgressOffset}
                strokeLinecap="butt"
              />
            )}
            {/* Completed Segment */}
            {completed > 0 && (
              <circle
                cx="80"
                cy="80"
                r={radius}
                fill="transparent"
                stroke="#10B981"
                strokeWidth="18"
                strokeDasharray={`${completedDash} ${circumference}`}
                strokeDashoffset={completedOffset}
                strokeLinecap="butt"
              />
            )}
          </svg>
          <div className="absolute inset-0 flex flex-col items-center justify-center text-center">
            <span className="font-mono-num text-3xl font-extrabold text-[#0F172A]">
              {overallPercent}%
            </span>
            <span className="text-[11px] font-semibold text-slate-500 mt-0.5">
              إجمالي الإنجاز
            </span>
          </div>
        </div>

        {/* Legend & Breakdown */}
        <div className="w-full space-y-3">
          <div className="flex items-center justify-between p-2.5 rounded-xl bg-emerald-50/60 border border-emerald-100">
            <div className="flex items-center gap-2.5">
              <span className="w-3 h-3 rounded-full bg-emerald-500 shrink-0"></span>
              <CheckCircle2 className="w-4 h-4 text-emerald-600" />
              <span className="text-sm font-semibold text-slate-800">
                محاضرات مكتملة
              </span>
            </div>
            <span className="font-mono-num text-sm font-bold text-emerald-700">
              {completed} محاضرة
            </span>
          </div>

          <div className="flex items-center justify-between p-2.5 rounded-xl bg-amber-50/70 border border-amber-100">
            <div className="flex items-center gap-2.5">
              <span className="w-3 h-3 rounded-full bg-[#F59E0B] shrink-0"></span>
              <Clock className="w-4 h-4 text-amber-600" />
              <span className="text-sm font-semibold text-slate-800">
                قيد المشاهدة حالياً
              </span>
            </div>
            <span className="font-mono-num text-sm font-bold text-amber-700">
              {inProgress} محاضرة
            </span>
          </div>

          <div className="flex items-center justify-between p-2.5 rounded-xl bg-slate-50 border border-slate-200/70">
            <div className="flex items-center gap-2.5">
              <span className="w-3 h-3 rounded-full bg-slate-300 shrink-0"></span>
              <CircleDashed className="w-4 h-4 text-slate-500" />
              <span className="text-sm font-semibold text-slate-700">
                لم تبدأ بعد
              </span>
            </div>
            <span className="font-mono-num text-sm font-bold text-slate-600">
              {notStarted} محاضرة
            </span>
          </div>
        </div>
      </div>
    </div>
  );
}

interface QuizAttemptItem {
  id: number;
  quizTitle: string;
  score: number;
  totalMarks: number;
  percentage: number;
  passed: boolean;
  passingScore?: number;
}

export function ExamScoresBarChart({
  attempts,
}: {
  attempts: QuizAttemptItem[];
}) {
  const chartItems =
    attempts.length > 0
      ? attempts.slice(0, 5).reverse()
      : [
          {
            id: 1,
            quizTitle: "امتحان الوحدة الأولى",
            score: 15,
            totalMarks: 20,
            percentage: 75,
            passed: true,
          },
          {
            id: 2,
            quizTitle: "امتحان إعمال المشتقات",
            score: 18,
            totalMarks: 20,
            percentage: 90,
            passed: true,
          },
        ];

  const avgScore =
    chartItems.length > 0
      ? Math.round(
          chartItems.reduce((acc, c) => acc + c.percentage, 0) /
            chartItems.length
        )
      : 0;

  return (
    <div className="bg-white rounded-2xl border border-slate-200/90 p-6 shadow-sm flex flex-col justify-between">
      <div className="flex items-center justify-between mb-4">
        <div>
          <h3 className="font-heading text-lg font-bold text-[#0F172A]">
            تحليل درجات الامتحانات
          </h3>
          <p className="text-xs text-slate-500">
            مقارنة نتائج اختباراتك السابقة بخط النجاح القياسي (60%)
          </p>
        </div>
        <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-amber-50 text-amber-800 border border-amber-200">
          <Award className="w-3.5 h-3.5 text-[#F59E0B]" />
          المتوسط {avgScore}%
        </span>
      </div>

      <div className="relative pt-6 pb-2 px-2">
        {/* Passing Threshold Line at 60% */}
        <div
          className="absolute inset-x-2 border-t-2 border-dashed border-amber-400/80 z-10 pointer-events-none flex items-center justify-end"
          style={{ bottom: "60%" }}
        >
          <span className="bg-amber-100 text-amber-900 text-[10px] font-bold px-2 py-0.5 rounded-md -mt-5 border border-amber-300">
            درجة النجاح 60%
          </span>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 items-end h-44 pt-4 border-b border-slate-200">
          {chartItems.map((item, idx) => {
            const isTop = item.percentage >= 85;
            const shortTitle =
              item.quizTitle.length > 22
                ? item.quizTitle.slice(0, 22) + "..."
                : item.quizTitle;
            return (
              <div
                key={`${item.id}-${idx}`}
                className="flex flex-col items-center justify-end h-full group"
              >
                <div className="mb-1.5 px-2 py-0.5 rounded-md bg-slate-900 text-white font-mono-num text-xs font-bold shadow-sm">
                  {item.percentage}% ({item.score}/{item.totalMarks})
                </div>
                <div className="w-full max-w-[56px] bg-slate-100 rounded-t-xl h-32 flex items-end overflow-hidden p-0.5">
                  <div
                    className={`w-full rounded-t-lg transition-all duration-500 ${
                      !item.passed
                        ? "bg-red-500"
                        : isTop
                        ? "bg-gradient-to-t from-[#0F172A] to-[#F59E0B]"
                        : "bg-[#0F172A]"
                    }`}
                    style={{ height: `${Math.max(12, item.percentage)}%` }}
                  />
                </div>
                <span
                  title={item.quizTitle}
                  className="text-[11px] font-semibold text-slate-600 mt-2 text-center line-clamp-1"
                >
                  {shortTitle}
                </span>
              </div>
            );
          })}
        </div>
      </div>

      <div className="flex items-center justify-between text-xs text-slate-500 mt-3 pt-2 border-t border-slate-100">
        <div className="flex items-center gap-4">
          <span className="inline-flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded-sm bg-[#0F172A]"></span>
            مجتاز بنجاح
          </span>
          <span className="inline-flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded-sm bg-[#F59E0B]"></span>
            تفوق امتياز (+85%)
          </span>
        </div>
        <span className="font-mono-num font-semibold text-slate-700">
          إجمالي المحاولات: {attempts.length}
        </span>
      </div>
    </div>
  );
}
