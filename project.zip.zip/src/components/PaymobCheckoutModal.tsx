"use client";

import React, { useState, useEffect } from "react";
import {
  X,
  CreditCard,
  Smartphone,
  QrCode,
  Wallet,
  ShieldCheck,
  Tag,
  CheckCircle2,
  Loader2,
  Copy,
  Check,
  Upload,
  AlertCircle,
  FileImage,
  Send,
  Zap,
} from "lucide-react";

interface PaymobCheckoutModalProps {
  item: {
    courseId?: number;
    packageId?: number;
    title: string;
    price: number;
    subtitle?: string;
  } | null;
  walletBalance: number;
  studentPhone: string;
  onClose: () => void;
  onSuccess: (message: string) => void;
}

export function PaymobCheckoutModal({
  item,
  walletBalance,
  studentPhone,
  onClose,
  onSuccess,
}: PaymobCheckoutModalProps) {
  // Main checkout mode: direct_transfer (InstaPay / Manual Vodafone) or automated (Paymob)
  const [checkoutMode, setCheckoutMode] = useState<"direct_transfer" | "automated">(
    "direct_transfer"
  );

  const [method, setMethod] = useState<
    "instapay" | "vodafone_cash" | "fawry_pay" | "visa_mastercard" | "wallet"
  >("instapay");

  const [settings, setSettings] = useState<{
    vodafoneCashNumber: string;
    instapayAddress: string;
    instapayName: string;
    supportPhone: string;
    transferInstructions: string;
  }>({
    vodafoneCashNumber: "01023316767",
    instapayAddress: "albayan@instapay",
    instapayName: "أ.د. محمود الشافعي (البيان التعليمية)",
    supportPhone: "01023316767",
    transferInstructions:
      "يرجى التحويل على رقم فودافون كاش أو معرف InstaPay الموضحين، ثم كتابة رقم المحفظة المحول منها ورفع صورة الإشعار للموافقة وتفعيل الكورس فوراً.",
  });

  // Direct Transfer Fields
  const [senderPhone, setSenderPhone] = useState(studentPhone || "");
  const [senderName, setSenderName] = useState("");
  const [referenceCode, setReferenceCode] = useState("");
  const [transferNote, setTransferNote] = useState("");
  const [receiptUrl, setReceiptUrl] = useState("");
  const [receiptFileName, setReceiptFileName] = useState<string | null>(null);

  // Automated & Coupon state
  const [walletNumber, setWalletNumber] = useState(studentPhone || "01012345678");
  const [couponCode, setCouponCode] = useState("");
  const [appliedDiscount, setAppliedDiscount] = useState<{
    code: string;
    discountPercent: number;
  } | null>(null);
  const [couponMessage, setCouponMessage] = useState<string | null>(null);

  const [copiedInsta, setCopiedInsta] = useState(false);
  const [copiedVoda, setCopiedVoda] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Fetch admin configured settings on mount
  useEffect(() => {
    fetch("/api/admin/settings")
      .then((res) => res.json())
      .then((data) => {
        if (data.settings) setSettings(data.settings);
      })
      .catch(() => {});
  }, []);

  if (!item) return null;

  const finalPrice = appliedDiscount
    ? Math.max(
        0,
        Math.round(item.price * (1 - appliedDiscount.discountPercent / 100))
      )
    : item.price;

  const handleCopy = (text: string, type: "insta" | "voda") => {
    navigator.clipboard.writeText(text);
    if (type === "insta") {
      setCopiedInsta(true);
      setTimeout(() => setCopiedInsta(false), 2000);
    } else {
      setCopiedVoda(true);
      setTimeout(() => setCopiedVoda(false), 2000);
    }
  };

  const handleValidateCoupon = async () => {
    if (!couponCode.trim()) return;
    setCouponMessage(null);
    setError(null);
    try {
      const res = await fetch("/api/payments/checkout", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          action: "validate_coupon",
          couponCode: couponCode.trim(),
        }),
      });
      const data = await res.json();
      if (!res.ok) {
        setAppliedDiscount(null);
        setError(data.error || "الكوبون غير صالح");
      } else {
        setAppliedDiscount(data.coupon);
        setCouponMessage(
          `تم تطبيق كود الخصم (${data.coupon.code}) بنجاح — خصم ${data.coupon.discountPercent}%!`
        );
      }
    } catch {
      setError("تعذر التحقق من الكوبون");
    }
  };

  // Mock receipt image upload handler (converts file to Data URL)
  const handleReceiptFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setReceiptFileName(file.name);
      const reader = new FileReader();
      reader.onload = () => {
        setReceiptUrl(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleCompletePayment = async () => {
    setLoading(true);
    setError(null);

    // Validation for Direct Transfer
    if (checkoutMode === "direct_transfer") {
      if (!senderPhone.trim()) {
        setError("يرجى كتابة رقم الهاتف أو المحفظة التي تم التحويل منها.");
        setLoading(false);
        return;
      }
    }

    try {
      const payload = {
        courseId: item.courseId,
        packageId: item.packageId,
        method: checkoutMode === "direct_transfer" ? method : method,
        paymentType: checkoutMode,
        couponCode: appliedDiscount?.code || "",
        referenceCode:
          checkoutMode === "direct_transfer"
            ? referenceCode || `REF-${Date.now().toString().slice(-6)}`
            : walletNumber,
        senderPhone,
        senderName,
        receiptUrl: receiptUrl || "https://images.unsplash.com/photo-1554224155-8d04cb21cd6c?w=600&auto=format&fit=crop&q=80",
        transferNote,
      };

      const res = await fetch("/api/payments/checkout", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });
      const data = await res.json();
      if (!res.ok) {
        setError(data.error || "فشلت عملية إرسال الطلب");
      } else {
        onSuccess(data.message);
        onClose();
      }
    } catch {
      setError("حدث خطأ أثناء معالجة عملية الدفع");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/80 backdrop-blur-sm p-4 overflow-y-auto">
      <div className="bg-white w-full max-w-xl rounded-2xl shadow-2xl border border-slate-200 overflow-hidden my-auto max-h-[92vh] flex flex-col">
        {/* Header */}
        <div className="bg-[#0F172A] text-white px-6 py-4 flex items-center justify-between shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-[#F59E0B] text-[#0F172A] flex items-center justify-center font-bold">
              <ShieldCheck className="w-6 h-6" />
            </div>
            <div>
              <h3 className="font-heading text-base sm:text-lg font-bold">
                تفعيل الاشتراك والدفع — منصة البيان
              </h3>
              <p className="text-xs text-slate-300">
                تحويل مباشر InstaPay/فودافون كاش أو بوابات الدفع الآلية
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6 space-y-5 overflow-y-auto">
          {/* Item Summary Banner */}
          <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 flex items-center justify-between">
            <div>
              <span className="text-xs font-bold text-[#F59E0B]">
                المحتوى المطلوب تفعيله
              </span>
              <h4 className="font-heading font-bold text-slate-900 text-base mt-0.5">
                {item.title}
              </h4>
              {item.subtitle && (
                <p className="text-xs text-slate-500 mt-0.5">{item.subtitle}</p>
              )}
            </div>
            <div className="text-left">
              {appliedDiscount && (
                <span className="block text-xs line-through text-slate-400 font-mono-num">
                  {item.price} ج.م
                </span>
              )}
              <span className="font-mono-num text-2xl font-extrabold text-[#0F172A]">
                {finalPrice}{" "}
                <span className="text-xs font-sans font-bold text-slate-600">
                  ج.م
                </span>
              </span>
            </div>
          </div>

          {/* Mode Tabs: Direct Transfer vs Automated Gateway */}
          <div className="grid grid-cols-2 bg-slate-100 p-1.5 rounded-xl border border-slate-200">
            <button
              type="button"
              onClick={() => {
                setCheckoutMode("direct_transfer");
                setMethod("instapay");
                setError(null);
              }}
              className={`py-2.5 rounded-lg text-xs font-bold flex items-center justify-center gap-1.5 transition ${
                checkoutMode === "direct_transfer"
                  ? "bg-[#0F172A] text-white shadow"
                  : "text-slate-600 hover:text-slate-900"
              }`}
            >
              <Send className="w-4 h-4 text-[#F59E0B]" />
              <span>تحويل مباشر (InstaPay / كاش)</span>
            </button>
            <button
              type="button"
              onClick={() => {
                setCheckoutMode("automated");
                setMethod("vodafone_cash");
                setError(null);
              }}
              className={`py-2.5 rounded-lg text-xs font-bold flex items-center justify-center gap-1.5 transition ${
                checkoutMode === "automated"
                  ? "bg-[#0F172A] text-white shadow"
                  : "text-slate-600 hover:text-slate-900"
              }`}
            >
              <Zap className="w-4 h-4 text-emerald-400" />
              <span>دفع آلي فوري (Paymob / فيزا)</span>
            </button>
          </div>

          {/* ========================================================
              TAB 1: DIRECT TRANSFER (INSTAPAY & VODAFONE CASH)
             ======================================================== */}
          {checkoutMode === "direct_transfer" && (
            <div className="space-y-4">
              {/* Method choice: InstaPay vs Vodafone Cash */}
              <div className="grid grid-cols-2 gap-3">
                <button
                  type="button"
                  onClick={() => setMethod("instapay")}
                  className={`p-3 rounded-xl border text-right transition flex items-center gap-2.5 ${
                    method === "instapay"
                      ? "border-[#0F172A] bg-purple-50/70 ring-2 ring-purple-600/20"
                      : "border-slate-200 hover:border-slate-300"
                  }`}
                >
                  <div className="w-8 h-8 rounded-lg bg-purple-700 text-white flex items-center justify-center font-bold text-xs shrink-0">
                    IPA
                  </div>
                  <div>
                    <div className="text-xs font-bold text-slate-900">
                      تحويل InstaPay
                    </div>
                    <div className="text-[10px] text-purple-700 font-semibold">
                      تطبيق إنستاباي
                    </div>
                  </div>
                </button>

                <button
                  type="button"
                  onClick={() => setMethod("vodafone_cash")}
                  className={`p-3 rounded-xl border text-right transition flex items-center gap-2.5 ${
                    method === "vodafone_cash"
                      ? "border-[#0F172A] bg-red-50/70 ring-2 ring-red-600/20"
                      : "border-slate-200 hover:border-slate-300"
                  }`}
                >
                  <div className="w-8 h-8 rounded-lg bg-red-600 text-white flex items-center justify-center shrink-0">
                    <Smartphone className="w-4 h-4" />
                  </div>
                  <div>
                    <div className="text-xs font-bold text-slate-900">
                      محفظة فودافون كاش
                    </div>
                    <div className="text-[10px] text-red-600 font-semibold">
                      Vodafone / المحافظ
                    </div>
                  </div>
                </button>
              </div>

              {/* Transfer Target Card with Copy Buttons */}
              {method === "instapay" ? (
                <div className="p-4 rounded-xl bg-purple-50/60 border border-purple-200 space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-purple-950">
                      عنوان الدفع اللحظي (InstaPay Address):
                    </span>
                    <button
                      type="button"
                      onClick={() => handleCopy(settings.instapayAddress, "insta")}
                      className="px-2.5 py-1 rounded-lg bg-purple-700 hover:bg-purple-800 text-white text-[11px] font-bold flex items-center gap-1 transition"
                    >
                      {copiedInsta ? (
                        <>
                          <Check className="w-3.5 h-3.5" /> تم النسخ
                        </>
                      ) : (
                        <>
                          <Copy className="w-3.5 h-3.5" /> نسخ المعرف
                        </>
                      )}
                    </button>
                  </div>
                  <div
                    dir="ltr"
                    className="p-2.5 rounded-lg bg-white border border-purple-200 font-mono-num text-sm font-extrabold text-purple-950 text-center tracking-wide"
                  >
                    {settings.instapayAddress}
                  </div>
                  <p className="text-[11px] text-purple-800 font-medium">
                    الاسم المسجل: <strong>{settings.instapayName}</strong>
                  </p>
                </div>
              ) : (
                <div className="p-4 rounded-xl bg-red-50/60 border border-red-200 space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-red-950">
                      رقم محفظة فودافون كاش للتحويل:
                    </span>
                    <button
                      type="button"
                      onClick={() =>
                        handleCopy(settings.vodafoneCashNumber, "voda")
                      }
                      className="px-2.5 py-1 rounded-lg bg-red-600 hover:bg-red-700 text-white text-[11px] font-bold flex items-center gap-1 transition"
                    >
                      {copiedVoda ? (
                        <>
                          <Check className="w-3.5 h-3.5" /> تم النسخ
                        </>
                      ) : (
                        <>
                          <Copy className="w-3.5 h-3.5" /> نسخ الرقم
                        </>
                      )}
                    </button>
                  </div>
                  <div
                    dir="ltr"
                    className="p-2.5 rounded-lg bg-white border border-red-200 font-mono-num text-base font-extrabold text-red-950 text-center tracking-wider"
                  >
                    {settings.vodafoneCashNumber}
                  </div>
                  <p className="text-[11px] text-red-800 font-medium">
                    حوّل المبلغ بالضبط (<strong>{finalPrice} ج.م</strong>) ثم املأ
                    البيانات بالأسفل.
                  </p>
                </div>
              )}

              {/* Inputs for sender details and screenshot */}
              <div className="space-y-3">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-bold text-slate-800 mb-1">
                      رقم الهاتف / المحفظة المحول منها{" "}
                      <span className="text-red-600">*</span>
                    </label>
                    <input
                      type="text"
                      dir="ltr"
                      required
                      value={senderPhone}
                      onChange={(e) => setSenderPhone(e.target.value)}
                      placeholder="010XXXXXXXX"
                      className="w-full px-3 py-2 rounded-xl border border-slate-300 font-mono-num text-xs"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-slate-800 mb-1">
                      اسم صاحب الحساب المحول منه
                    </label>
                    <input
                      type="text"
                      value={senderName}
                      onChange={(e) => setSenderName(e.target.value)}
                      placeholder="مثال: يوسف طارق"
                      className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-800 mb-1">
                    رقم العملية أو كود المعاملة المرجعي (اختياري)
                  </label>
                  <input
                    type="text"
                    dir="ltr"
                    value={referenceCode}
                    onChange={(e) => setReferenceCode(e.target.value)}
                    placeholder="Ref No. (مثال: 4490182)"
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 font-mono-num text-xs"
                  />
                </div>

                {/* Proof screenshot upload */}
                <div>
                  <label className="block text-xs font-bold text-slate-800 mb-1">
                    صورة إشعار التحويل (سكرين شوت من إنستاباي أو الرسالة)
                  </label>
                  <label className="border-2 border-dashed border-slate-300 hover:border-[#0F172A] rounded-xl p-3 flex items-center justify-center gap-2 cursor-pointer bg-slate-50 transition">
                    <input
                      type="file"
                      accept="image/*"
                      onChange={handleReceiptFileChange}
                      className="hidden"
                    />
                    <Upload className="w-4 h-4 text-slate-600" />
                    <span className="text-xs font-bold text-slate-700">
                      {receiptFileName ? (
                        <span className="text-emerald-700 flex items-center gap-1">
                          <FileImage className="w-4 h-4" /> تم إرفاق:{" "}
                          {receiptFileName}
                        </span>
                      ) : (
                        "اضغط هنا لاختيار صورة إشعار التحويل"
                      )}
                    </span>
                  </label>
                </div>
              </div>
            </div>
          )}

          {/* ========================================================
              TAB 2: AUTOMATED GATEWAY (PAYMOB VISA / FAWRY / WALLET)
             ======================================================== */}
          {checkoutMode === "automated" && (
            <div className="space-y-4">
              <label className="block text-xs font-bold text-slate-700">
                اختر وسيلة الدفع الآلية:
              </label>
              <div className="grid grid-cols-2 gap-3">
                <button
                  type="button"
                  onClick={() => setMethod("vodafone_cash")}
                  className={`p-3 rounded-xl border text-right transition flex items-center gap-2.5 ${
                    method === "vodafone_cash"
                      ? "border-[#0F172A] bg-slate-900/5 ring-2 ring-[#0F172A]/15"
                      : "border-slate-200 hover:border-slate-300"
                  }`}
                >
                  <div className="w-8 h-8 rounded-lg bg-red-600 text-white flex items-center justify-center shrink-0">
                    <Smartphone className="w-4 h-4" />
                  </div>
                  <div>
                    <div className="text-xs font-bold text-slate-900">
                      فودافون كاش
                    </div>
                    <div className="text-[10px] text-slate-500">OTP آلي</div>
                  </div>
                </button>

                <button
                  type="button"
                  onClick={() => setMethod("fawry_pay")}
                  className={`p-3 rounded-xl border text-right transition flex items-center gap-2.5 ${
                    method === "fawry_pay"
                      ? "border-[#0F172A] bg-slate-900/5 ring-2 ring-[#0F172A]/15"
                      : "border-slate-200 hover:border-slate-300"
                  }`}
                >
                  <div className="w-8 h-8 rounded-lg bg-amber-500 text-slate-950 flex items-center justify-center shrink-0">
                    <QrCode className="w-4 h-4" />
                  </div>
                  <div>
                    <div className="text-xs font-bold text-slate-900">
                      فوري باي
                    </div>
                    <div className="text-[10px] text-slate-500">كود فوري</div>
                  </div>
                </button>

                <button
                  type="button"
                  onClick={() => setMethod("visa_mastercard")}
                  className={`p-3 rounded-xl border text-right transition flex items-center gap-2.5 ${
                    method === "visa_mastercard"
                      ? "border-[#0F172A] bg-slate-900/5 ring-2 ring-[#0F172A]/15"
                      : "border-slate-200 hover:border-slate-300"
                  }`}
                >
                  <div className="w-8 h-8 rounded-lg bg-blue-700 text-white flex items-center justify-center shrink-0">
                    <CreditCard className="w-4 h-4" />
                  </div>
                  <div>
                    <div className="text-xs font-bold text-slate-900">
                      فيزا / ماستركارد
                    </div>
                    <div className="text-[10px] text-slate-500">Visa / ميزة</div>
                  </div>
                </button>

                <button
                  type="button"
                  onClick={() => setMethod("wallet")}
                  className={`p-3 rounded-xl border text-right transition flex items-center gap-2.5 ${
                    method === "wallet"
                      ? "border-[#0F172A] bg-slate-900/5 ring-2 ring-[#0F172A]/15"
                      : "border-slate-200 hover:border-slate-300"
                  }`}
                >
                  <div className="w-8 h-8 rounded-lg bg-emerald-600 text-white flex items-center justify-center shrink-0">
                    <Wallet className="w-4 h-4" />
                  </div>
                  <div>
                    <div className="text-xs font-bold text-slate-900">
                      رصيد المحفظة
                    </div>
                    <div className="text-[10px] text-emerald-700 font-bold">
                      متاح: {walletBalance} ج.م
                    </div>
                  </div>
                </button>
              </div>

              {method === "vodafone_cash" && (
                <div className="p-3.5 rounded-xl bg-red-50/50 border border-red-100 space-y-1.5">
                  <label className="block text-xs font-bold text-slate-800">
                    رقم محفظتك الإلكترونية لاستقبال طلب الخصم:
                  </label>
                  <input
                    type="text"
                    dir="ltr"
                    value={walletNumber}
                    onChange={(e) => setWalletNumber(e.target.value)}
                    placeholder="01012345678"
                    className="w-full px-3 py-2 rounded-xl bg-white border border-slate-300 font-mono-num text-xs"
                  />
                </div>
              )}
            </div>
          )}

          {/* Coupon Input Section */}
          <div className="space-y-1.5 pt-2 border-t border-slate-100">
            <label className="block text-xs font-bold text-slate-700">
              كوبون خصم (جرّب كود:{" "}
              <button
                type="button"
                onClick={() => setCouponCode("BAYAN25")}
                className="font-mono-num text-[#F59E0B] underline font-bold"
              >
                BAYAN25
              </button>
              )
            </label>
            <div className="flex gap-2">
              <div className="relative flex-1">
                <Tag className="w-4 h-4 text-slate-400 absolute right-3 top-2.5" />
                <input
                  type="text"
                  dir="ltr"
                  value={couponCode}
                  onChange={(e) => setCouponCode(e.target.value.toUpperCase())}
                  placeholder="BAYAN25"
                  className="w-full pr-9 pl-3 py-1.5 rounded-xl border border-slate-300 font-mono-num text-xs uppercase"
                />
              </div>
              <button
                type="button"
                onClick={handleValidateCoupon}
                className="px-3.5 py-1.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold transition"
              >
                تطبيق
              </button>
            </div>
            {couponMessage && (
              <p className="text-xs font-bold text-emerald-600 flex items-center gap-1">
                <CheckCircle2 className="w-3.5 h-3.5" />
                {couponMessage}
              </p>
            )}
          </div>

          {error && (
            <div className="p-3 rounded-xl bg-red-50 border border-red-200 text-xs font-bold text-red-700 flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{error}</span>
            </div>
          )}

          {/* Submit Action */}
          <button
            type="button"
            disabled={loading}
            onClick={handleCompletePayment}
            className="w-full py-3.5 rounded-xl bg-[#F59E0B] hover:bg-amber-400 text-[#0F172A] font-heading font-bold text-xs sm:text-sm shadow-lg shadow-amber-500/20 transition flex items-center justify-center gap-2 disabled:opacity-60"
          >
            {loading ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin" />
                جاري إرسال بيانات الدفع...
              </>
            ) : checkoutMode === "direct_transfer" ? (
              <>
                <Send className="w-4 h-4" />
                إرسال إشعار التحويل المباشر ({finalPrice} ج.م) للمراجعة والتفعيل
              </>
            ) : (
              <>
                <ShieldCheck className="w-4 h-4" />
                تأكيد الدفع الفوري ({finalPrice} ج.م) عبر Paymob
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
}
