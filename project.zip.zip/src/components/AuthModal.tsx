"use client";

import React, { useState } from "react";
import {
  X,
  UserPlus,
  LogIn,
  ShieldCheck,
  Phone,
  Lock,
  Mail,
  User,
  CheckCircle2,
  AlertCircle,
  Loader2,
} from "lucide-react";

interface AuthModalProps {
  isOpen: boolean;
  initialMode?: "login" | "register";
  onClose: () => void;
  onAuthSuccess: () => void;
}

const EGYPT_PHONE_REGEX = /^01[0125][0-9]{8}$/;

export function AuthModal({
  isOpen,
  initialMode = "register",
  onClose,
  onAuthSuccess,
}: AuthModalProps) {
  const [mode, setMode] = useState<"login" | "register">(initialMode);
  const [tripleName, setTripleName] = useState("");
  const [studentPhone, setStudentPhone] = useState("");
  const [guardianPhone, setGuardianPhone] = useState("");
  const [motherPhone, setMotherPhone] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [gradeLevel, setGradeLevel] = useState(
    "الصف الثالث الثانوي - علمي علوم"
  );

  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  if (!isOpen) return null;

  const isTripleValid =
    tripleName
      .trim()
      .split(/\s+/)
      .filter((w) => w.length >= 2).length >= 3;
  const isStudentPhoneValid = EGYPT_PHONE_REGEX.test(studentPhone.trim());
  const isGuardianPhoneValid = EGYPT_PHONE_REGEX.test(guardianPhone.trim());
  const isMotherPhoneValid = EGYPT_PHONE_REGEX.test(motherPhone.trim());

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setLoading(true);

    try {
      const payload =
        mode === "register"
          ? {
              action: "register",
              tripleName,
              studentPhone,
              guardianPhone,
              motherPhone,
              email,
              password,
              gradeLevel,
            }
          : {
              action: "login",
              studentPhone,
              password,
            };

      const res = await fetch("/api/auth", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });
      const data = await res.json();
      if (!res.ok) {
        setError(data.error || "تعذر إتمام العملية");
      } else {
        onAuthSuccess();
        onClose();
      }
    } catch {
      setError("حدث خطأ في الاتصال بالخادم");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/75 backdrop-blur-sm p-4 overflow-y-auto">
      <div className="bg-white w-full max-w-xl rounded-2xl shadow-2xl border border-slate-200 overflow-hidden my-auto">
        {/* Header */}
        <div className="bg-[#0F172A] text-white px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-[#F59E0B] text-[#0F172A] flex items-center justify-center">
              {mode === "register" ? (
                <UserPlus className="w-5 h-5" />
              ) : (
                <LogIn className="w-5 h-5" />
              )}
            </div>
            <div>
              <h3 className="font-heading text-lg font-bold">
                {mode === "register"
                  ? "تسجيل حساب طالب جديد — حماية مشددة"
                  : "تسجيل الدخول إلى منصة البيان"}
              </h3>
              <p className="text-xs text-slate-300">
                تشفير Bcrypt وعزل تام لبيانات أولياء الأمور
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Mode Switcher */}
        <div className="grid grid-cols-2 bg-slate-100 p-1.5 m-6 mb-0 rounded-xl border border-slate-200">
          <button
            type="button"
            onClick={() => {
              setMode("register");
              setError(null);
            }}
            className={`py-2.5 rounded-lg text-xs font-bold transition ${
              mode === "register"
                ? "bg-[#0F172A] text-white shadow"
                : "text-slate-600 hover:text-slate-900"
            }`}
          >
            إنشاء حساب طالب جديد
          </button>
          <button
            type="button"
            onClick={() => {
              setMode("login");
              setError(null);
            }}
            className={`py-2.5 rounded-lg text-xs font-bold transition ${
              mode === "login"
                ? "bg-[#0F172A] text-white shadow"
                : "text-slate-600 hover:text-slate-900"
            }`}
          >
            تسجيل الدخول بحساب حالي
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          {mode === "register" && (
            <>
              {/* 1. Triple Name */}
              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="text-xs font-bold text-slate-800">
                    1. الاسم الثلاثي للطالب{" "}
                    <span className="text-red-600">* (إلزامي)</span>
                  </label>
                  {tripleName && (
                    <span
                      className={`text-[11px] font-bold flex items-center gap-1 ${
                        isTripleValid ? "text-emerald-600" : "text-amber-600"
                      }`}
                    >
                      {isTripleValid ? (
                        <>
                          <CheckCircle2 className="w-3.5 h-3.5" /> اسم ثلاثي صحيح
                        </>
                      ) : (
                        "أدخل 3 أسماء على الأقل"
                      )}
                    </span>
                  )}
                </div>
                <div className="relative">
                  <User className="w-4 h-4 text-slate-400 absolute right-3.5 top-3" />
                  <input
                    type="text"
                    required
                    value={tripleName}
                    onChange={(e) => setTripleName(e.target.value)}
                    placeholder="مثال: عبد الرحمن طارق الشافعي"
                    className="w-full pr-10 pl-3 py-2.5 rounded-xl border border-slate-300 text-sm focus:outline-none focus:ring-2 focus:ring-[#0F172A]"
                  />
                </div>
              </div>
            </>
          )}

          {/* 2. Student Phone */}
          <div>
            <div className="flex items-center justify-between mb-1">
              <label className="text-xs font-bold text-slate-800">
                {mode === "register" ? "2. " : ""}رقم هاتف الطالب{" "}
                <span className="text-red-600">* (إلزامي - غير مكرر)</span>
              </label>
              {studentPhone && (
                <span
                  className={`text-[11px] font-bold flex items-center gap-1 ${
                    isStudentPhoneValid ? "text-emerald-600" : "text-red-600"
                  }`}
                >
                  {isStudentPhoneValid
                    ? "رقم مصري صحيح"
                    : "صيغة مصرية (010/011/012/015 + 8 أرقام)"}
                </span>
              )}
            </div>
            <div className="relative">
              <Phone className="w-4 h-4 text-slate-400 absolute right-3.5 top-3" />
              <input
                type="tel"
                dir="ltr"
                required
                maxLength={11}
                value={studentPhone}
                onChange={(e) =>
                  setStudentPhone(e.target.value.replace(/\D/g, ""))
                }
                placeholder="01012345678"
                className="w-full pr-10 pl-3 py-2.5 rounded-xl border border-slate-300 font-mono-num text-sm focus:outline-none focus:ring-2 focus:ring-[#0F172A]"
              />
            </div>
          </div>

          {mode === "register" && (
            <>
              {/* 3 & 4. Guardian & Mother Phones */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <div className="flex items-center justify-between mb-1">
                    <label className="text-xs font-bold text-slate-800">
                      3. رقم هاتف ولي الأمر{" "}
                      <span className="text-red-600">*</span>
                    </label>
                    {guardianPhone && (
                      <span
                        className={`text-[10px] font-bold ${
                          isGuardianPhoneValid
                            ? "text-emerald-600"
                            : "text-red-600"
                        }`}
                      >
                        {isGuardianPhoneValid ? "صحيح" : "غير صحيح"}
                      </span>
                    )}
                  </div>
                  <input
                    type="tel"
                    dir="ltr"
                    required
                    maxLength={11}
                    value={guardianPhone}
                    onChange={(e) =>
                      setGuardianPhone(e.target.value.replace(/\D/g, ""))
                    }
                    placeholder="01123456789"
                    className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 font-mono-num text-sm focus:outline-none focus:ring-2 focus:ring-[#0F172A]"
                  />
                </div>

                <div>
                  <div className="flex items-center justify-between mb-1">
                    <label className="text-xs font-bold text-slate-800">
                      4. رقم هاتف الأم <span className="text-red-600">*</span>
                    </label>
                    {motherPhone && (
                      <span
                        className={`text-[10px] font-bold ${
                          isMotherPhoneValid
                            ? "text-emerald-600"
                            : "text-red-600"
                        }`}
                      >
                        {isMotherPhoneValid ? "صحيح" : "غير صحيح"}
                      </span>
                    )}
                  </div>
                  <input
                    type="tel"
                    dir="ltr"
                    required
                    maxLength={11}
                    value={motherPhone}
                    onChange={(e) =>
                      setMotherPhone(e.target.value.replace(/\D/g, ""))
                    }
                    placeholder="01234567890"
                    className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 font-mono-num text-sm focus:outline-none focus:ring-2 focus:ring-[#0F172A]"
                  />
                </div>
              </div>

              {/* 5. Optional Email & Grade */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    5. البريد الإلكتروني{" "}
                    <span className="text-slate-400">(اختياري)</span>
                  </label>
                  <div className="relative">
                    <Mail className="w-4 h-4 text-slate-400 absolute right-3.5 top-3" />
                    <input
                      type="email"
                      dir="ltr"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      placeholder="student@albayan.eg"
                      className="w-full pr-10 pl-3 py-2.5 rounded-xl border border-slate-300 font-mono-num text-sm focus:outline-none focus:ring-2 focus:ring-[#0F172A]"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    الصف الدراسي والشعبة
                  </label>
                  <select
                    value={gradeLevel}
                    onChange={(e) => setGradeLevel(e.target.value)}
                    className="w-full px-3 py-2.5 rounded-xl border border-slate-300 text-sm bg-white focus:outline-none focus:ring-2 focus:ring-[#0F172A]"
                  >
                    <option value="الصف الثالث الثانوي - علمي علوم">
                      الصف الثالث الثانوي - علمي علوم
                    </option>
                    <option value="الصف الثالث الثانوي - علمي رياضة">
                      الصف الثالث الثانوي - علمي رياضة
                    </option>
                    <option value="الصف الثالث الثانوي - أدبي">
                      الصف الثالث الثانوي - أدبي
                    </option>
                    <option value="الصف الثاني الثانوي">
                      الصف الثاني الثانوي
                    </option>
                    <option value="الصف الأول الثانوي">
                      الصف الأول الثانوي
                    </option>
                  </select>
                </div>
              </div>
            </>
          )}

          {/* 6. Password */}
          <div>
            <label className="block text-xs font-bold text-slate-800 mb-1">
              {mode === "register" ? "6. " : ""}كلمة المرور{" "}
              <span className="text-red-600">* (تشفير Bcrypt)</span>
            </label>
            <div className="relative">
              <Lock className="w-4 h-4 text-slate-400 absolute right-3.5 top-3" />
              <input
                type="password"
                dir="ltr"
                required
                minLength={6}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
                className="w-full pr-10 pl-3 py-2.5 rounded-xl border border-slate-300 text-sm focus:outline-none focus:ring-2 focus:ring-[#0F172A]"
              />
            </div>
          </div>

          {/* Privacy Notice */}
          {mode === "register" && (
            <div className="p-3 rounded-xl bg-slate-50 border border-slate-200 text-[11px] text-slate-600 flex items-start gap-2">
              <ShieldCheck className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
              <span>
                يتم حفظ أرقام هاتف ولي الأمر والأم بتشفير وعزل كامل في قاعدة
                البيانات، ولا تظهر لأي طالب آخر إطلاقاً، وتقتصر رؤيتها على الإدارة
                الأكاديمية فقط.
              </span>
            </div>
          )}

          {error && (
            <div className="p-3 rounded-xl bg-red-50 border border-red-200 text-xs font-bold text-red-700 flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{error}</span>
            </div>
          )}

          <button
            type="submit"
            disabled={loading}
            className="w-full py-3 rounded-xl bg-[#0F172A] hover:bg-slate-800 text-white font-heading font-bold text-sm shadow-lg transition flex items-center justify-center gap-2 disabled:opacity-60"
          >
            {loading ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin" />
                جاري المعالجة والتشفير...
              </>
            ) : mode === "register" ? (
              "إنشاء الحساب والبدء فوراً (هدية 100 ج.م بالمحفظة)"
            ) : (
              "تسجيل الدخول إلى المنصة"
            )}
          </button>
        </form>
      </div>
    </div>
  );
}
