#!/usr/bin/env node
/**
 * Standalone Seed Runner for Al-Bayan Arabic E-Learning Platform
 * Usage: node scripts/seed.mjs
 */
const baseUrl = process.env.APP_URL || "http://localhost:3000";

async function runSeed() {
  console.log("🚀 جاري تهيئة وتعبئة قاعدة بيانات منصة البيان التعليمية (Seed)...");
  try {
    const res = await fetch(`${baseUrl}/api/auth`);
    const data = await res.json();
    console.log("✅ تم توليد حساب الأدمن، الطلاب التجريبيين، الكورسات، الباقات، والاختبارات بنجاح!");
    console.log("👤 الحساب النشط افتراضياً:", data?.user?.tripleName, `(${data?.user?.studentPhone})`);
    console.log("🔐 حساب الأدمن: 01000000001 | كلمة المرور: Admin@2026");
    console.log("🎓 حساب الطالب: 01012345678 | كلمة المرور: Student@2026");
  } catch (err) {
    console.error("⚠️ تأكد من تشغيل الخادم أو استدعاء /api/auth لتشغيل الـ Seed تلقائياً:", err.message);
  }
}

runSeed();
